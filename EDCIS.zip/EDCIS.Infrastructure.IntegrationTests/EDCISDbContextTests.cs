﻿using EDCIS.Domain.Entities;
using EDCIS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Shouldly;

namespace EDCIS.Infrastructure.IntegrationTests
{
    public class EDCISDbContextTests
    {
        private readonly EDCISContext _EDCISContext;
        private readonly string _StudyName;

        public EDCISDbContextTests()
        {
            var dbContextOptions = new DbContextOptionsBuilder<EDCISContext>().UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
            _EDCISContext = new EDCISContext(dbContextOptions);
            _StudyName = "Test Study";
        }

        [Fact]
        public async Task Save_SetCreatedByProperty()
        {
            var log = new HistoryLog() { Id = 1, StudyName = "Test Study" ,ConfigName="TestConfig"};
            _EDCISContext.HistoryLog.Add(log);
            await _EDCISContext.SaveChangesAsync();
            log.StudyName.ShouldBe(_StudyName);

        }
    }
}
