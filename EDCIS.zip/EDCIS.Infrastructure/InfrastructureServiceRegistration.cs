﻿using EDCIS.Application.Persistence;
using EDCIS.Infrastructure.Persistence;
using EDCIS.Infrastructure.Repository;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace EDCIS.Infrastructure
{
    public static class InfrastructureServiceRegistration
    {
        public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration
          , bool isDevelopment)
        {

            var isDBLoggingEnabled = Convert.ToBoolean(configuration["DBLoggng:IsEnabled"]);
            services.AddScoped(_ => new CTMSReplicaContext(configuration.GetConnectionString("CTMSReplicaConnectionString"), isDBLoggingEnabled)); 
            services.AddScoped(typeof(IAsyncRepository<>), typeof(RepositoryBase<>));
            services.AddScoped(typeof(IAsyncCTMS_RDBRepository<>), typeof(CTMS_RDBRepositoryBase<>));

            services.AddDbContext<EDCISContext>(options =>
            {
                options.UseSqlServer(configuration.GetConnectionString("EDCISConnectionString"), sqlOptions =>
                {
                    // see https://docs.microsoft.com/en-us/ef/core/miscellaneous/connection-resiliency    
                    sqlOptions.EnableRetryOnFailure();
                });      
               
                if (isDevelopment)
                {
                    options.EnableSensitiveDataLogging();
                }
            });

            return services;
        }
    }
}
