﻿using EDCIS.Application.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using EDCIS.Infrastructure.Persistence;
using System.Linq.Expressions;

namespace EDCIS.Infrastructure.Repository
{
    public class CTMS_RDBRepositoryBase<T> : IDisposable, IAsyncCTMS_RDBRepository<T> where T : class
    {
        protected readonly CTMSReplicaContext _dbContext;
        private readonly ILogger _logger;
        private readonly DbSet<T> _dbset;
        public CTMS_RDBRepositoryBase(CTMSReplicaContext dbContext, ILogger<T> logger)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _logger = logger;
            _dbset = _dbContext.Set<T>();
        }

        public async Task<IReadOnlyList<T>> GetAllAsync()
        {
            return await _dbset.ToListAsync();
        }

        public async Task<IReadOnlyList<T>> GetAsync(Expression<Func<T, bool>> predicate)
        {
            return await _dbset.Where(predicate).ToListAsync();
        }

        public async Task<IReadOnlyList<T>> GetAsync(Expression<Func<T, bool>>? predicate = null, Func<IQueryable<T>, IOrderedQueryable<T>>? orderBy = null, string? includeString = null, bool disableTracking = true)
        {
            IQueryable<T> query = _dbset;
            if (disableTracking) query = query.AsNoTracking();

            if (includeString != null)
            {
                foreach (var includeProperty in includeString.Split
                (new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProperty);
                }
            }
            // if (!string.IsNullOrWhiteSpace(includeString)) query = query.Include(includeString);

            if (predicate != null) query = query.Where(predicate);

            if (orderBy != null)
                return await orderBy(query).ToListAsync();
            return await query.ToListAsync();
        }

        public async Task<IReadOnlyList<T>> GetAsync(Expression<Func<T, bool>>? predicate = null, Func<IQueryable<T>, IOrderedQueryable<T>>? orderBy = null, List<Expression<Func<T, object>>>? includes = null, bool disableTracking = true)
        {
            IQueryable<T> query = _dbset;
            if (disableTracking) query = query.AsNoTracking();

            if (includes != null) query = includes.Aggregate(query, (current, include) => current.Include(include));

            if (predicate != null) query = query.Where(predicate);

            if (orderBy != null)
                return await orderBy(query).ToListAsync();
            return await query.ToListAsync();
        }

        public virtual async Task<T?> GetByIdAsync(object key)
        {
            return await _dbset.FindAsync(key);
        }

        #region Dispose
        public void Dispose()
        {
            _dbContext.Dispose();
        }
        #endregion
    }
}
