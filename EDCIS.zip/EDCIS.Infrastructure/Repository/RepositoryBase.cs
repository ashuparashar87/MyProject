﻿using EDCIS.Application.Persistence;
using EDCIS.Domain.Entities;
using EDCIS.Infrastructure.Persistence;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Data;
using System.Linq.Expressions;
using System.Numerics;

namespace EDCIS.Infrastructure.Repository
{
    public class RepositoryBase<T> : IDisposable, IAsyncRepository<T> where T : class
    {
        protected readonly EDCISContext _dbContext;
        private readonly ILogger _logger;
        private DbSet<T> _dbset;
        public RepositoryBase(EDCISContext dbContext, ILogger<T> logger)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _logger = logger;
            _dbset = _dbContext.Set<T>();
        }

        public async Task<IReadOnlyList<T>> GetAllAsync()
        {
            try
            {
                return await _dbset.ToListAsync();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex.InnerException);
            }
        }

        public async Task<IReadOnlyList<T>> GetAsync(Expression<Func<T, bool>> predicate)
        {
            return await _dbset.Where(predicate).ToListAsync();
        }

        public async Task<IReadOnlyList<T>> GetAsync(Expression<Func<T, bool>>? predicate = null, Func<IQueryable<T>, IOrderedQueryable<T>>? orderBy = null, string? includeString = null, bool disableTracking = true)
        {
            IQueryable<T> query = _dbset;
            if (disableTracking) query = query.AsNoTracking();

            if (includeString != null)
            {
                foreach (var includeProperty in includeString.Split
                (new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProperty);
                }
            }
            // if (!string.IsNullOrWhiteSpace(includeString)) query = query.Include(includeString);

            if (predicate != null) query = query.Where(predicate);

            if (orderBy != null)
                return await orderBy(query).ToListAsync();
            return await query.ToListAsync();
        }

        public async Task<IReadOnlyList<T>> GetAsync(Expression<Func<T, bool>>? predicate = null, Func<IQueryable<T>, IOrderedQueryable<T>>? orderBy = null, List<Expression<Func<T, object>>>? includes = null, bool disableTracking = true)
        {
            IQueryable<T> query = _dbset;
            if (disableTracking) query = query.AsNoTracking();

            if (includes != null) query = includes.Aggregate(query, (current, include) => current.Include(include));

            if (predicate != null) query = query.Where(predicate);

            if (orderBy != null)
                return await orderBy(query).ToListAsync();
            return await query.ToListAsync();
        }

        public virtual async Task<T?> GetByIdAsync(object key)
        {
            try
            {
                return await _dbset.FindAsync(key);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex.InnerException);
            }
        }

        public async virtual Task<IReadOnlyList<T>> GetPagedReponseAsync(int page, int size)
        {
            return await _dbset.Skip((page - 1) * size).Take(size).AsNoTracking().ToListAsync();
        }
        public async Task<T> AddAsync(T entity)
        {
            _dbset.Add(entity);
            try
            {
                await _dbContext.SaveChangesAsync();

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex.InnerException);
            }
            _logger.LogDebug("Entity Added:{entity}", JsonConvert.SerializeObject(entity, Formatting.Indented, new JsonSerializerSettings
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            }));
            return entity;
        }

        public async Task UpdateAsync(T entity)
        {
            _dbContext.Entry(entity).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
            _logger.LogDebug("Entity Updated:{entity}", JsonConvert.SerializeObject(entity, Formatting.Indented, new JsonSerializerSettings
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            }));
        }
        public async Task DeleteAsync(T entity)
        {
            _dbset.Remove(entity);
            await _dbContext.SaveChangesAsync();
            _dbContext.ChangeTracker.Clear();
            _logger.LogDebug("Entity Deleted:{entity}", JsonConvert.SerializeObject(entity, Formatting.Indented, new JsonSerializerSettings
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            }));
        }
        // Call the stored procedure using SqlQueryRaw
        public async Task<List<AutomationReportResult>> GetRowSQLAsync(DateTime? fromDate, DateTime? toDate, long? studyId, string? initiatedBy, bool groupByStudy, bool groupByInitiated)
        {
            try
            {
                var results = await _dbContext.Database
                    .SqlQuery<AutomationReportResult>($"EXEC GetAutomationReport @fromDate = {fromDate}, @toDate = {toDate},@studyId={studyId},@initiatedBy={initiatedBy},@groupByStudy={groupByStudy},@groupByInitiated={groupByInitiated}")
                    .ToListAsync();
                return results;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex.InnerException);
            }
        }
        #region Dispose
        public void Dispose()
        {
            _dbContext.Dispose();
        }
       
        #endregion
    }
}
