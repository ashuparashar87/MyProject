﻿using EDCIS.Domain.Entities;
using EDCIS.Domain.Enum;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
namespace EDCIS.Infrastructure.Configuration
{
    public class HistoryLogConfiguration : IEntityTypeConfiguration<HistoryLog>
    {
        public void Configure(EntityTypeBuilder<HistoryLog> builder)
        {
            builder
                .HasKey(e => e.Id);

            builder
                .Property(e => e.StudyID);

            builder
              .Property(e => e.ConfigName)
              .HasMaxLength(500);

            builder
              .Property(e => e.TimeStamp);

            builder.Property(_ => _.Process).HasColumnName("Process").IsRequired();

            builder.Property(e => e.Process)
               .HasConversion(e => e.ToString(),
                e => (ProcessType)Enum.Parse(typeof(ProcessType), e));

            builder
            .Property(e => e.LogDetails);
        }
    }
}
