﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using EDCIS.Domain.Enum;
using EDCIS.Domain.Entities;

namespace EDCIS.Infrastructure.Configuration
{
    internal class ResourceConfiguration : IEntityTypeConfiguration<Resource>
    {
        public void Configure(EntityTypeBuilder<Resource> builder)
        {
            builder.ToTable("Resource");

            builder.HasKey(e => e.Id);

            builder.Property(e => e.FirstName)
                .IsRequired()
                .HasMaxLength(100);

            builder.Property(e => e.LastName)
              .HasMaxLength(100);

            builder.Property(e => e.EmailAddress)
                .HasMaxLength(200);

            builder.HasIndex(e => e.EmailAddress, "IX_ResourceEmail")
                .IsUnique();

            builder.Property(_ => _.Role).HasColumnName("Role").IsRequired();

            builder.Property(e => e.Role)
                .HasConversion(e => e.ToString(), // to converter
                 e => (ResourceRole)Enum.Parse(typeof(ResourceRole), e));// from converter
        }
    }
}