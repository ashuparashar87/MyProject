﻿using Microsoft.EntityFrameworkCore;
using EDCIS.Domain.Entities;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using EDCIS.Domain.Enum;

namespace EDCIS.Infrastructure.Configuration
{
    public class SASAutomationConfiguration : BaseEntityConfiguration<SASAutomationConfig>
    {
        public override void Configure(EntityTypeBuilder<SASAutomationConfig> builder)
        {
            base.Configure(builder);
            builder.ToTable("SASAutomationConfig")
           .HasIndex(entity => new { entity.ConfigName }, "UniqueConfigName").IsUnique(true);

            builder.HasKey(e => e.Id);

            builder
                .Property(e => e.StudyID)
                .IsRequired();

            builder
             .Property(e => e.ConfigName)
             .IsRequired()
             .HasMaxLength(100);

            builder
              .Property(e => e.FileName)
              .HasMaxLength(500);

            builder
             .Property(e => e.ErrorEmailRecipients)
             .HasMaxLength(4000);


            builder
                .Property(e => e.SourceFileProtocol)                 
                .HasMaxLength(10);


            builder.Property(_ => _.SourceFileProtocol).HasColumnName("SourceFileProtocol");

            builder.Property(e => e.SourceFileProtocol)
                .HasConversion(e => e.ToString(),
                 e => (FileProtocol)Enum.Parse(typeof(FileProtocol), e!));
                     
            builder.Property(e => e.SourceEncryption)
                .HasConversion(e => e.ToString(),
                 e => (EncryptionMode)EncryptionMode.Parse(typeof(EncryptionMode), e!));


            builder
                .Property(e => e.SourceHostName)               
                .HasMaxLength(100);

            builder.Property(e => e.SourcePortNumber);

            builder
                .Property(e => e.SourceUserName)               
                .HasMaxLength(100);

            builder
                .Property(e => e.SourcePassword)               
                .HasMaxLength(100);

            builder
             .Property(e => e.SourceFileName)             
            .HasMaxLength(100);

            builder
               .Property(e => e.SourceZipPassword)
               .HasMaxLength(100);

            builder
                .Property(e => e.SourceFolderPath)               
                .HasMaxLength(10000);

            builder
               .Property(e => e.IsDeleteFileAfterTransfer);


            builder.Property(_ => _.DestFileProtocol).HasColumnName("DestFileProtocol");

            builder.Property(e => e.DestFileProtocol)
                .HasConversion(e => e.ToString(),
                 e => (FileProtocol)Enum.Parse(typeof(FileProtocol), e!));

            builder.Property(e => e.ConfigurationType)
                .HasConversion(e => e.ToString(),
                 e => (ConfigurationTypeValue)Enum.Parse(typeof(ConfigurationTypeValue), e!));


            builder.Property(e => e.DestEncryption)
              .HasConversion(e => e.ToString(),
               e => (EncryptionMode)Enum.Parse(typeof(EncryptionMode), e!));

            builder.Property(e => e.IsEDCActive);

            builder
              .Property(e => e.DestFileProtocol)               
              .HasMaxLength(100);

            builder
               .Property(e => e.DestEncryption)
               .HasMaxLength(10);

            builder
                .Property(e => e.DestHostName)                
                .HasMaxLength(100);

           builder.Property(e => e.DestPortNumber);

            builder
               .Property(e => e.DestUserName)              
               .HasMaxLength(100);

            builder
                .Property(e => e.DestPassword)
                .HasMaxLength(100);

            builder
                .Property(e => e.ArchiveDestFolderPath)                
                .HasMaxLength(1000);

            builder.Property(e => e.CurrentDestFolderPath)                
               .HasMaxLength(1000);

            builder.Property(e => e.TransferDate);

            builder.Property(e => e.WeekDays).HasMaxLength(50000);

            builder.Property(e => e.TimeSlot).HasMaxLength(30);
            builder.Property(e => e.IsErrorInLastExecution).HasDefaultValue(false);
            builder.Property(e => e.SuccessEmailRecipients).HasMaxLength(4000);
            builder.Property(e => e.ErrorEmailRecipients).HasMaxLength(4000);
            builder.Property(e => e.CanRunStatistician).HasDefaultValue(false);
            builder.Property(e => e.CanDMRUN).HasDefaultValue(false);
            builder.Property(e => e.LastSASLaunchDateTime);
            builder.Property(e => e.LastErrorDateTime);
            builder.Property(e => e.LastError).HasMaxLength(4000);
            builder.Property(e => e.ExecuteProgramAfterTransfer) .HasDefaultValue(false);
            builder.Property(e => e.Description).HasMaxLength(300);           
            builder.Property(e => e.Path).HasMaxLength(300);         
            builder.Property(e => e.TimeoutInSeconds);
            builder.Property(e => e.LastSASLogFile).HasMaxLength(300);
            builder.Property(e => e.ConfigurationType).HasMaxLength(30);

        }
    }
}


