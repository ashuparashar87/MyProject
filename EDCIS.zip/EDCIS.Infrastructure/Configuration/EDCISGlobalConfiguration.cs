﻿using EDCIS.Domain.Entities;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;

namespace EDCIS.Infrastructure.Configuration
{
    internal class EDCISGlobalConfiguration : IEntityTypeConfiguration<EDCISConfiguration>
    {
        public void Configure(EntityTypeBuilder<EDCISConfiguration> builder)
        {
            builder.ToTable("EDCISConfiguration");
            builder.HasKey(e => e.Id);
            builder.HasData(
            new EDCISConfiguration { Id = 1, Key = "IsSASAutomationJobRunning", Value = "0", Description = "If any issue occurs while the SAS Automation process is ongoing and needs to be retriggered. Value “1” indicates job is still running, replace it with “0” to reset the flag.", CreatedBy = "SystemUser@advancedgroup.com", CreatedDate = DateTime.UtcNow });
        }
    }
}