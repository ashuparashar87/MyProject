﻿using Microsoft.EntityFrameworkCore;
using EDCIS.Domain.Entities;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using EDCIS.Domain.Enum;

namespace EDCIS.Infrastructure.Configuration
{
    public class FTPSiteConfiguration : BaseEntityConfiguration<FTPSiteConfig>
    {
        public override void Configure(EntityTypeBuilder<FTPSiteConfig> builder)
        {
            base.Configure(builder);
            builder.ToTable("FTPSiteConfig")
           .HasIndex(entity => new { entity.FTPSite }, "UniqueFTPSite").IsUnique(true);

            builder
                .HasKey(e => e.Id);

            builder
              .Property(e => e.FTPSite)
              .HasMaxLength(100);

            builder
                .Property(e => e.FileProtocol)
                 .IsRequired()
                .HasMaxLength(10);


            builder.Property(_ => _.FileProtocol).HasColumnName("FileProtocol").IsRequired();

            builder.Property(e => e.FileProtocol)
                .HasConversion(e => e.ToString(),
                 e => (FileProtocol)Enum.Parse(typeof(FileProtocol), e!));

            builder.Property(_ => _.Encryption).HasColumnName("Encryption").IsRequired();

            builder.Property(e => e.Encryption)
                .HasConversion(e => e.ToString(),
                 e => (EncryptionMode)Enum.Parse(typeof(EncryptionMode), e!));

            builder
                .Property(e => e.HostName)
                .IsRequired()
                .HasMaxLength(100);
            builder
                .Property(e => e.PortNumber);

            builder
                .Property(e => e.UserName)
                .IsRequired()
                .HasMaxLength(100);

            builder
                .Property(e => e.Password)
                .IsRequired()
                .HasMaxLength(100);
        }
    }
}


