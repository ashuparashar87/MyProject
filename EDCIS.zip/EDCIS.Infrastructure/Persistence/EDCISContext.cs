﻿using EDCIS.Application.ClientInfrastructure.Dtos;
using EDCIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace EDCIS.Infrastructure.Persistence
{
    public class EDCISContext : DbContext
    {
        public EDCISContext(DbContextOptions<EDCISContext> options) :
            base(options)
        {

        }
        //read only expression valued proparties//means:we are going to call the set function anything we need a Dbset
        // public DbSet<Study> Study =>Set<Study>();

        public DbSet<EDCToSASConfig> EDCToSASConfig { get; set; } = null!;
        public DbSet<EDCISConfiguration> EDCISConfiguration { get; set; } = null!;
        public DbSet<FTPSiteConfig> FTPSiteConfig { get; set; } = null!;
        public DbSet<HistoryLog> HistoryLog { get; set; } = null!;
        public DbSet<Resource> Resource { get; set; } = null!;
        public DbSet<SASAutomationConfig> SASAutomationConfig { get; set; } = null!;


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {            
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(EDCISContext).Assembly);
        }

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = new CancellationToken())
        {
            foreach (var entry in ChangeTracker.Entries<EntityBase>())
            {
                switch (entry.State)
                {
                    case EntityState.Added:
                        entry.Entity.CreatedDate = DateTime.UtcNow;
                        entry.Entity.CreatedBy = SD.UserId ?? "SystemUser@advancedgroup.com";
                        break;
                    case EntityState.Modified:
                        entry.Entity.LastModifiedDate = DateTime.UtcNow;
                        entry.Entity.LastModifiedBy = SD.UserId ?? "SystemUser@advancedgroup.com";
                        break;
                }
            }
            return base.SaveChangesAsync(cancellationToken);
        }
    }
}
