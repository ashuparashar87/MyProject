﻿using EDCIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
namespace EDCIS.Infrastructure.Persistence
{
    public class CTMSReplicaContext : DbContext
    {
        private readonly string? _connectionString;
        private readonly bool _useConsoleLogger;
        private static readonly ILoggerFactory _loggerFactory = LoggerFactory.Create(builder => builder
                                                         .AddFilter((category, level) => category == DbLoggerCategory.Database.Command.Name && level == LogLevel.Information));
        //.AddConsole());
        private static readonly ILoggerFactory _emptyloggerFactory = LoggerFactory.Create(builder => builder
                                                              .AddFilter((_, _) => false));

        public CTMSReplicaContext(string? connectionString, bool useConsoleLogger)
        {
            _connectionString = connectionString;
            _useConsoleLogger = useConsoleLogger;
        }
        public DbSet<EDCISStudyView> EDCISStudyView { get; set; }
       


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<EDCISStudyView>()
             .HasNoKey()
             .ToView(nameof(EDCISStudyView));

            base.OnModelCreating(modelBuilder);
            modelBuilder.ApplyConfigurationsFromAssembly(
               typeof(CTMSReplicaContext).Assembly
           );
        }

        public override int SaveChanges()
        {
            // Throw if they try to call this
            throw new InvalidOperationException("This context is read-only.");
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_connectionString,
                options => options.EnableRetryOnFailure());  // see https://docs.microsoft.com/en-us/ef/core/miscellaneous/connection-resiliency    

            if (_useConsoleLogger)
            {
                optionsBuilder
                .UseLoggerFactory(_loggerFactory)
                .EnableSensitiveDataLogging();
            }
            else
            {
                optionsBuilder
                .UseLoggerFactory(_emptyloggerFactory);
            }
        }
    }
}
