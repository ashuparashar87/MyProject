﻿using EDCIS.Domain.Entities;
using EDCIS.Domain.Enum;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace EDCIS.Infrastructure.Persistence
{
    public class EDCISContextSeed
    {
        public static async Task SeedAsync(EDCISContext edcContext, ILogger<EDCISContextSeed>? logger, bool seedDemoData = false)
        {
            if (!edcContext.FTPSiteConfig.Any())
                edcContext.FTPSiteConfig.AddRange(GetPreconfiguredFTPSiteConfig());
            await edcContext.SaveChangesAsync();
            logger?.LogInformation("Seed database associated with context {DbContextName}", typeof(EDCISContext).Name);

         
            if (!edcContext.EDCToSASConfig.Any())
                edcContext.EDCToSASConfig.AddRange(GetPreconfiguredEDCToSASConfig());
            await edcContext.SaveChangesAsync();
            logger?.LogInformation("Seed database associated with context {DbContextName}", typeof(EDCISContext).Name);


            if (seedDemoData)
            {
                if (!edcContext.Resource.Any())
                    edcContext.Resource.AddRange(GetPreconfiguredResorces());
                await edcContext.SaveChangesAsync();
                logger?.LogInformation("Seed database associated with context {DbContextName}", typeof(EDCISContext).Name);
            }
        }

        private static IEnumerable<FTPSiteConfig> GetPreconfiguredFTPSiteConfig()
        {

            return new List<FTPSiteConfig>
                        {
                        new FTPSiteConfig()
                        {
                        FTPSite="AC SAS Test",
                        FileProtocol = FileProtocol.SFTP,
                        Encryption = EncryptionMode.None,
                        HostName = "ftp.acrxs.com",
                        PortNumber = 22,
                        UserName = "prdsftpsas",
                        Password = "==ol!ver@Twest66==",
                        },
                        new FTPSiteConfig()
                        {
                        FTPSite="AC Public",
                        FileProtocol = FileProtocol.SFTP,
                        Encryption = EncryptionMode.None,
                        HostName = "ftp.acrxs.com",
                        PortNumber = 22,
                        UserName = "acsas",
                        Password = "Timely22Wiggles&",
                        },
                        new FTPSiteConfig()
                        {
                        FTPSite="DEV FTP",
                        FileProtocol = FileProtocol.FTP,
                        Encryption = EncryptionMode.None,
                        HostName = "autotesting01.eastus.cloudapp.azure.com",
                        PortNumber = 21,
                       UserName = "autotester",
                        Password = "@utoTester01!",
                        },
                       new FTPSiteConfig()
                        {
                        FTPSite="DEV SFTP",
                        FileProtocol = FileProtocol.SFTP,
                        Encryption = EncryptionMode.None,
                        HostName = "autotesting01.eastus.cloudapp.azure.com",
                        PortNumber = 22,
                       UserName = "autotester",
                        Password = "@utoTester01!",
                        },

                        new FTPSiteConfig()
                        {
                        FTPSite="Medidata",
                        FileProtocol = FileProtocol.FTP,
                        Encryption = EncryptionMode.Implicit,
                        HostName = "ftp01.ftp.mdsol.com",
                        PortNumber = 990,
                        UserName = "advancedclinical.sasondemand",
                        Password = "98)67G34b347",
                        },
                    };
        }
        private static IEnumerable<SASAutomationConfig> GetPreconfiguredSASAutomationConfig()
        {
            return new List<SASAutomationConfig>
            {
                new SASAutomationConfig()
                {
                    StudyID = 14355223812246160,
                    ConfigName="AC SAS Test Config",
                    SourceFTPSite="AC SAS Test",
                    SourceFileProtocol = FileProtocol.SFTP,
                    SourceEncryption = EncryptionMode.None,
                    SourceHostName = "ftp.acrxs.com",
                    SourcePortNumber = 22,
                    SourceUserName = "prdsftpsas",
                    SourcePassword = "==ol!ver@Twest66==",
                    SourceFileName = "RakestTest.zip",
                    IsEDCActive = true,
                    SourceFolderPath = "/AVA/CLFT218-1901/Source/",
                    DestFTPSite="AC SAS Test",
                    DestFileProtocol = FileProtocol.SFTP,
                    DestEncryption = EncryptionMode.None,
                    DestPortNumber = 22,
                    DestHostName = "ftp.acrxs.com",
                    DestUserName = "prdsftpsas",
                    DestPassword = "==ol!ver@Twest66==",
                    ArchiveDestFolderPath = "/AVA/CLFT218-1901/Archive/",
                    CurrentDestFolderPath = "/AVA/CLFT218-1901/Current/",
                    WeekDays = "Monday,Tuesday,Wednesday,Thursday,Friday",
                    TimeSlot="2:30 AM",
                    IsDeleteFileAfterTransfer = false,
                    IsErrorInLastExecution= false,
                },

                new SASAutomationConfig()
                {
                    StudyID = 14355223812248457,
                    ConfigName="config4",
                    SourceFTPSite= "AC Public",
                    SourceFileProtocol = FileProtocol.SFTP,
                    SourceEncryption = EncryptionMode.None,
                    SourceHostName = "ftp.acrxs.com",
                    SourcePortNumber = 22,
                    SourceUserName = "acsas",
                    SourcePassword = "Timely22Wiggles&",
                    SourceFileName = "eCOS_DataExport_SAS_RM-493-022.zip",
                    IsEDCActive = true,
                    SourceFolderPath = "/acsasftp/Rhythm/RM-493-022/EDC/",
                    DestFTPSite="DEV FTP",
                    DestFileProtocol = FileProtocol.FTP,
                    DestEncryption = EncryptionMode.None,
                    DestPortNumber = 21,
                    DestHostName = "autotesting01.eastus.cloudapp.azure.com",
                    DestUserName = "autotester",
                    DestPassword = "@utoTester01!",
                    ArchiveDestFolderPath = "/ArchiveDestination/",
                    CurrentDestFolderPath = "/Destination/",
                    WeekDays = "Monday,Friday",
                    TimeSlot="2:30 AM",
                    IsDeleteFileAfterTransfer = false,
                    
                },

                //Test Connection
                //new EDCConfig()
                //{
                //    StudyID = 14355223812243458,
                //    ConfigName="config1",
                //    SourceFileProtocol = SourceFileProtocol.FTP,
                //    SourceEncryption = EncryptionMode.Explicit,
                //    SourceHostName = "ftp01.ftp.mdsol.com",
                //    SourcePortNumber = 21,
                //    SourceUserName = "advancedclinical.sasondemand",
                //    SourcePassword = "98)67G34b347",
                //    SourceFileName = "woodscd1_GALDERMA_START__ACNE_VULGARIS__362",
                //    IsEDCActive = true,
                //    SourceZipPassword = "galderma1914",
                //    SourceFolderPath = "/galderma-ac.mdsol.com/sasondemand/",
                //    DestFileProtocol = DestFileProtocol.SFTP,
                //    DestEncryption = EncryptionMode.None,
                //    DestPortNumber = 22,
                //    DestHostName = "ftp.acrxs.com",
                //    DestUserName = "acsas",
                //    DestPassword = "Timely22Wiggles&",
                //    ArchiveDestFolderPath = "/ArchiveDestination/",
                //    CurrentDestFolderPath = "/Destination/",
                //    WeekDays = "Monday,Wednesday,Friday",
                //    TimeSlot="2:30 AM",
                //    IsDeleteFileAfterTransfer = false,
                //},
                //new EDCConfig()
                //{
                //    StudyID = 14355223812243560,
                //    ConfigName="config2",
                //    SourceFileProtocol = SourceFileProtocol.FTP,
                //    SourceEncryption = EncryptionMode.Explicit,
                //    SourceHostName = "ftp01.ftp.mdsol.com",
                //    SourcePortNumber = 21,
                //    SourceUserName = "advancedclinical.sasondemand",
                //    SourcePassword = "98)67G34b347",
                //    SourceFileName = "woodscd1_ALD_104_499",
                //    IsEDCActive = true,
                //    SourceZipPassword = "bluebird104",
                //    SourceFolderPath = "/bluebird-ac.mdsol.com/sasondemand/",
                //    DestFileProtocol = DestFileProtocol.SFTP,
                //    DestEncryption = EncryptionMode.None,
                //    DestPortNumber = 22,
                //    DestHostName = "ftp.acrxs.com",
                //    DestUserName = "advancedclinical.sasondemand",
                //    DestPassword = "98)67G34b347",
                //    ArchiveDestFolderPath = "/ArchiveDestination/",
                //    CurrentDestFolderPath = "/Destination/",
                //    WeekDays = "Tuseday,Friday",
                //    TimeSlot="2:30 AM",
                //   IsDeleteFileAfterTransfer = false,
                //},
                //new EDCConfig()
                //{
                //    StudyID = 14355223812249059,
                //    ConfigName="config3",
                //    SourceFileProtocol = SourceFileProtocol.FTP,
                //    SourceEncryption = EncryptionMode.Explicit,
                //    SourceHostName = "ftp01.ftp.mdsol.com",
                //    SourcePortNumber = 21,
                //    SourceUserName = "advancedclinical.sasondemand",
                //    SourcePassword = "98)67G34b347",
                //    SourceFileName = "woodscd1_CLFT218_1901_22",
                //    IsEDCActive = true,
                //    SourceZipPassword = "avadel1901",
                //    SourceFolderPath = "/avadel-ac.mdsol.com/sasondemand/",
                //   DestFileProtocol = DestFileProtocol.SFTP,
                //    DestEncryption = EncryptionMode.None,
                //    DestPortNumber = 22,
                //    DestHostName = "ftp.acrxs.com",
                //    DestUserName = "advancedclinical.sasondemand",
                //    DestPassword = "98)67G34b347",
                //    ArchiveDestFolderPath = "/ArchiveDestination/",
                //    CurrentDestFolderPath = "/Destination/",
                //    WeekDays = "Wednesday,Saturday",
                //    TimeSlot="2:30 AM",
                //    IsDeleteFileAfterTransfer = false,

                //},
                //new EDCConfig()
                //{
                //    StudyID = 14355223812248457,
                //    ConfigName="config4",
                //    SourceFileProtocol = SourceFileProtocol.SFTP,
                //    SourceEncryption = EncryptionMode.None,
                //    SourceHostName = "ftp.acrxs.com",
                //    SourcePortNumber = 22,
                //    SourceUserName = "acsas",
                //    SourcePassword = "Timely22Wiggles&",
                //    SourceFileName = "eCOS_DataExport_SAS_RM-493-022",
                //    IsEDCActive = true,
                //    SourceFolderPath = "/acsasftp/Rhythm/RM-493-022/EDC/",
                //    DestFileProtocol = DestFileProtocol.SFTP,
                //    DestEncryption = EncryptionMode.None,
                //    DestPortNumber = 22,
                //    DestHostName = "ftp.acrxs.com",
                //    DestUserName = "advancedclinical.sasondemand",
                //    DestPassword = "Timely22Wiggles&",
                //    ArchiveDestFolderPath = "/ArchiveDestination/",
                //    CurrentDestFolderPath = "/Destination/",
                //    WeekDays = "Monday,Friday",
                //    TimeSlot="2:30 AM",
                //    IsDeleteFileAfterTransfer = false,
                //},

                //FileTransfer

                //new EDCConfig()
                //{
                //    StudyID = 14355223812243661,
                //    ConfigName="configTest",
                //    SourceFileProtocol = SourceFileProtocol.FTP,
                //    SourceEncryption = EncryptionMode.Implicit,
                //    SourceHostName = "ftp01.ftp.mdsol.com",
                //    SourcePortNumber = 990,
                //    SourceUserName = "advancedclinical.sasondemand",
                //    SourcePassword = "98)67G34b347",
                //    SourceFileName = "woodscd1_GALDERMA_START__ACNE_VULGARIS__362_*.zip",
                //    IsEDCActive = true,
                //    SourceZipPassword = "galderma1914",
                //    SourceFolderPath = "/galderma-ac.mdsol.com/sasondemand/",
                //    DestFileProtocol = DestFileProtocol.FTP,
                //    DestEncryption = EncryptionMode.None,
                //    DestPortNumber = 21,
                //    DestHostName = "autotesting01.eastus.cloudapp.azure.com",
                //    DestUserName = "autotester",
                //    DestPassword = "@utoTester01!",
                //    ArchiveDestFolderPath = "/ArchiveDestination/",
                //    CurrentDestFolderPath = "/Destination/",
                //    WeekDays = "Monday,Tuesday,Wednesday,Thursday,Friday",
                //    TimeSlot="2:30 AM",
                //    IsDeleteFileAfterTransfer = false,
                //},
                //new EDCConfig()
                //{
                //    StudyID = 14355223812244057,
                //    ConfigName="config057",
                //    SourceFileProtocol = SourceFileProtocol.FTP,
                //    SourceEncryption = EncryptionMode.Implicit,
                //    SourceHostName = "ftp01.ftp.mdsol.com",
                //    SourcePortNumber = 990,
                //    SourceUserName = "advancedclinical.sasondemand",
                //    SourcePassword = "98)67G34b347",
                //    SourceFileName = "woodscd1_ALD_104_499_*.zip",
                //    IsEDCActive = true,
                //    SourceZipPassword = "bluebird104",
                //    SourceFolderPath = "/bluebird-ac.mdsol.com/sasondemand/",
                //    DestFileProtocol = DestFileProtocol.FTP,
                //    DestEncryption = EncryptionMode.None,
                //    DestPortNumber = 21,
                //    DestHostName = "autotesting01.eastus.cloudapp.azure.com",
                //    DestUserName = "autotester",
                //    DestPassword = "@utoTester01!",
                //    ArchiveDestFolderPath = "/ArchiveDestination/",
                //    CurrentDestFolderPath = "/Destination/",
                //    WeekDays = "Monday,Tuesday,Wednesday,Thursday,Friday",
                //    TimeSlot="2:30 AM",
                //   IsDeleteFileAfterTransfer = false,
                //},
                //new EDCConfig()
                //{
                //    StudyID = 14355223812244858,
                //    ConfigName="config858",
                //    SourceFileProtocol = SourceFileProtocol.FTP,
                //    SourceEncryption = EncryptionMode.Implicit,
                //    SourceHostName = "ftp01.ftp.mdsol.com",
                //    SourcePortNumber = 990,
                //    SourceUserName = "advancedclinical.sasondemand",
                //    SourcePassword = "98)67G34b347",
                //    SourceFileName = "woodscd1_CLFT218_1901_22_*.zip",
                //    IsEDCActive = true,
                //    SourceZipPassword = "avadel1901",
                //    SourceFolderPath = "/avadel-ac.mdsol.com/sasondemand/",
                //    DestFileProtocol = DestFileProtocol.FTP,
                //    DestEncryption = EncryptionMode.None,
                //    DestPortNumber = 21,
                //    DestHostName = "autotesting01.eastus.cloudapp.azure.com",
                //    DestUserName = "autotester",
                //    DestPassword = "@utoTester01!",
                //    ArchiveDestFolderPath = "/ArchiveDestination/",
                //    CurrentDestFolderPath = "/Destination/",
                //     WeekDays = "Monday,Tuesday,Wednesday,Thursday,Friday",
                //    TimeSlot="2:30 AM",
                //    IsDeleteFileAfterTransfer = false,

                //},
                //new EDCConfig()
                //{
                //    StudyID = 14355223812246164,
                //    ConfigName="config164",
                //    SourceFileProtocol = SourceFileProtocol.SFTP,
                //    SourceEncryption = EncryptionMode.None,
                //    SourceHostName = "ftp.acrxs.com",
                //    SourcePortNumber = 22,
                //    SourceUserName = "acsas",
                //    SourcePassword = "Timely22Wiggles&",
                //    SourceFileName = "eCOS_DataExport_SAS_RM-493-022_*.zip",
                //    IsEDCActive = true,
                //    SourceFolderPath = "/acsasftp/Rhythm/RM-493-022/EDC/",
                //    DestFileProtocol = DestFileProtocol.FTP,
                //    DestEncryption = EncryptionMode.None,
                //    DestPortNumber = 21,
                //    DestHostName = "autotesting01.eastus.cloudapp.azure.com",
                //    DestUserName = "autotester",
                //    DestPassword = "@utoTester01!",
                //    ArchiveDestFolderPath = "/ArchiveDestination/",
                //    CurrentDestFolderPath = "/Destination/",
                //    WeekDays = "Monday,Tuesday,Wednesday,Thursday,Friday",
                //    TimeSlot="2:30 AM",
                //    IsDeleteFileAfterTransfer = false,
                //},

                //new EDCConfig()
                //{
                //    StudyID = 14355223812246160,
                //    ConfigName="config5",
                //    SourceFTPSite="Site4",
                //    SourceFileProtocol = FileProtocol.FTP,
                //    SourceEncryption = EncryptionMode.None,
                //    SourceHostName = "autotesting01.eastus.cloudapp.azure.com",
                //    SourcePortNumber = 21,
                //    SourceUserName = "autotester",
                //    SourcePassword = "@utoTester01!",
                //    SourceFileName = "Test.zip",
                //    IsEDCActive = true,
                //    SourceFolderPath = "/SponsorA/",
                //    DestFTPSite="Site1",
                //    DestFileProtocol = FileProtocol.SFTP,
                //    DestEncryption = EncryptionMode.None,
                //    DestPortNumber = 22,
                //    DestHostName = "ftp.acrxs.com",
                //    DestUserName = "prdsftpsas",
                //    DestPassword = "==ol!ver@Twest66==",
                //    ArchiveDestFolderPath = "/AVA/CLFT218-1901/Archive/",
                //    CurrentDestFolderPath = "/AVA/CLFT218-1901/Current/",
                //    WeekDays = "Monday,Tuesday,Wednesday,Thursday,Friday",
                //    TimeSlot="2:30 AM",
                //    IsDeleteFileAfterTransfer = false,
                //},
            };
        }

        private static IEnumerable<Resource> GetPreconfiguredResorces()
        {
            return new List<Resource>
            {
                new Resource() {FirstName = "Steve", LastName = "Guidos",EmailAddress="sguidos@advancedgroup.com", IsActive=true, Role=ResourceRole.ITAdmin },
                new Resource() {FirstName = "Christopher", LastName = "Woods",EmailAddress="cwoods@advancedclinical.com", IsActive=true, Role=ResourceRole.Admin },
                new Resource() {FirstName = "Eric", LastName = "Kaurs",EmailAddress="ekaurs@advancedclinical.com", IsActive=true, Role=ResourceRole.Admin }
                //new Resource() {FirstName = "Abhishek", LastName = "Sharma",EmailAddress="asharma@advancedgroup.com", IsActive=true, Role=ResourceRole.ReadOnly},
                //new Resource() {FirstName = "Asutosh", LastName = "Sharma",EmailAddress="akumar@advancedgroup.com", IsActive=true, Role=ResourceRole.Admin },
                //new Resource() {FirstName = "Rakesh", LastName = "Patel",EmailAddress="rkpatel@advancedgroup.com", IsActive=true, Role=ResourceRole.ITAdmin }
            };
        }

        private static IEnumerable<EDCToSASConfig> GetPreconfiguredEDCToSASConfig()
        {
            return new List<EDCToSASConfig>
            {
                new EDCToSASConfig() { DestArchivePurgePeriod = 30, HistoryPurgePeriod = 30,SupportEmail="DigHealthAppDevs@advancedgroup.com", IsAutomationActive=true},
            };
        }

        public static (string response, bool IsSucess) UpdateDatabase(EDCISContext edcisContext, ILogger<EDCISContextSeed> logger, bool _IsDatabaseCreated)
        {
            try
            {
                logger.LogInformation("Database updates started.");

                if (!_IsDatabaseCreated)
                {
                    //var IsInMaintenanceMode = edcisContext.EDCISConfiguration.Where(x => x.Key == MessagesConstants.IsInMaintenanceMode).FirstOrDefault();
                    //if (IsInMaintenanceMode != null)
                    //{
                    //    IsInMaintenanceMode.Value = "1";
                    //    edcisContext.EDCISConfiguration.Update(IsInMaintenanceMode);
                    //    edcisContext.SaveChanges();
                    //}

                    string[] filePaths = Directory.GetFiles(@".\MigrationScript\");
                    if (filePaths.Count() > 0)
                    {
                        string filefullName = filePaths.Where(x => x.Contains("Current_Release")).First();
                        string query = File.ReadAllText(filefullName);
                        if (query.Length > 0)
                        {
                            edcisContext.Database.ExecuteSqlRaw(query);
                            logger.LogInformation("Database updates completed.");
                        }

                    }

                    //if (IsInMaintenanceMode != null)
                    //{
                    //    IsInMaintenanceMode.Value = "0";
                    //    edcisContext.EDCISConfiguration.Update(IsInMaintenanceMode);
                    //    edcisContext.SaveChanges();
                    //}
                }
                return ("Database updates completed.", true);
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message);
                return (ex.Message, false);
            }
        }

    }
}
