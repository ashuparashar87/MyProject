﻿using EDCIS.Application.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDCIS.Application.Interface
{
    public interface IRemoteFileSystemContext : IFileSystem, IDisposable
    {
        bool DirectoryExists(string directoryPath);
        void DeleteDirectory(string directoryPath);
        bool IsConnected();
        void Connect();
        void Disconnect();

        void SetWorkingDirectory(string path);
        void SetRootAsWorkingDirectory();

        bool UploadFile(MemoryStream ms, string remoteFilePath);
        bool UnZipFile(MemoryStream ms, string remoteFilePath, string? zipPassword, out int unzippedfilesCount);

        MemoryStream DownloadFile(string remoteFilePath);
        FileDetail GetListingDirectory(string sourceFolderPath, string sourceFileName);
        string ServerDetails();

        List<FileDetail> GetPurgingFile(string sourceFolderPath);
        List<FileDetail> GetPurgingDirectory(string sourceFolderPath);
        void DeleteFileIfExists(string filePath);
    }
}
