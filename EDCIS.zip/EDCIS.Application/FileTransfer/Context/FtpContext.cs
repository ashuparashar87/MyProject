﻿using EDCIS.Application.ClientInfrastructure.Dtos;
using EDCIS.Application.Interface;
using FluentFTP;
using SharpCompress.Archives;
using SharpCompress.Readers;


namespace EDCIS.Application.Context
{
    public abstract class FtpContext : IRemoteFileSystemContext
    {
        static long totalUnCompressedSize;
        protected IFtpClient FtpClient { get; set; } = null!;
        string? FileSizeRestriction = SD.FileSizeRestriction;
       

        public void Connect()
        {
            FtpClient.Connect();
        }

        public void Disconnect()
        {
            FtpClient.Disconnect();
        }

        public void Dispose()
        {
            if (FtpClient != null && !FtpClient.IsDisposed)
            {
                FtpClient.Dispose();
            }
        }

        /*actions*/
        public bool FileExists(string filePath)
        {
            return FtpClient.FileExists(filePath);
        }

        public void DeleteFileIfExists(string filePath)
        {
            if (FileExists(filePath))
            {
                FtpClient.DeleteFile(filePath);
            }
        }

        public bool UploadFile(MemoryStream ms, string remoteFilePath)
        {
            var result = true;
            byte[] fileData = ms.ToArray();
            totalUnCompressedSize = fileData.Length;
            if (totalUnCompressedSize <= Convert.ToInt64(FileSizeRestriction))
            {
                FtpClient.UploadStream(ms, remoteFilePath);
                return result;
            }
            else
            {
               return result = false;               
            }
        }

        public bool UnZipFile(MemoryStream ms, string remotezipPath, string? zipPassword, out int unzippedfilesCount)
        {
            var result = true;
            unzippedfilesCount = 0;
            if (!string.IsNullOrEmpty(zipPassword))
            {
                ms.Seek(0, SeekOrigin.Begin);               
                using (var zip = ArchiveFactory.Open(ms, new ReaderOptions { Password = zipPassword }))
                {                   
                    unzippedfilesCount = zip.Entries.Count();
                    foreach (var e in zip.Entries)
                    {
                        long unCompressedSize = e.Size;
                        totalUnCompressedSize += unCompressedSize;
                    }

                    if (totalUnCompressedSize <= Convert.ToInt64(FileSizeRestriction))
                    {
                        foreach (var entry in zip.Entries)
                        {
                            using (Stream stream = entry.OpenEntryStream())
                            {
                                FtpClient.UploadStream(stream, remotezipPath + entry.Key, FtpRemoteExists.Overwrite, createRemoteDir: true);
                            }
                        }
                        return result;
                    }
                    else
                    {
                       return result = false;                
                    }
                }
            }
            else
            {
                ms.Seek(0, SeekOrigin.Begin);
                using (var zip = ArchiveFactory.Open(ms))
                {
                    unzippedfilesCount = zip.Entries.Count();

                    foreach (var e in zip.Entries)
                    {
                        long unCompressedSize = e.Size;
                        totalUnCompressedSize += unCompressedSize;
                    }

                    if (totalUnCompressedSize <= Convert.ToInt64(FileSizeRestriction))
                    {
                        foreach (var entry in zip.Entries)
                        {
                            using (Stream stream = entry.OpenEntryStream())
                            {
                                FtpClient.UploadStream(stream, remotezipPath + entry.Key, FtpRemoteExists.Overwrite, createRemoteDir: true);
                            }
                        }
                        return result;
                    }
                    else
                    {
                       return result = false;                       
                    }

                }
            }
        }

        public bool DirectoryExists(string directoryPath)
        {
            return FtpClient.DirectoryExists(directoryPath);
        }

        public void CreateDirectoryIfNotExists(string directoryPath)
        {
            if (!DirectoryExists(directoryPath))
            {
                FtpClient.CreateDirectory(directoryPath);
            }
        }

        public MemoryStream DownloadFile(string remoteFilePath)
        {
            MemoryStream ms = new MemoryStream();
            FtpClient.DownloadStream(ms, remoteFilePath);
            return ms;
        }

        public bool IsConnected()
        {
            return FtpClient.IsConnected;
        }

        public void SetWorkingDirectory(string directoryPath)
        {
            FtpClient.SetWorkingDirectory(directoryPath);
        }

        public void SetRootAsWorkingDirectory()
        {
            SetWorkingDirectory("");
        }

        public FileDetail GetListingDirectory(string sourceFolderPath, string sourceFileName)
        {
            List<FileDetail> fileDetails = new List<FileDetail>();
            // get a recursive listing of the files & folders in a specific folder
            foreach (var item in FtpClient.GetListing(sourceFolderPath, FtpListOption.Auto))
            {
                FileDetail fileDetail = new FileDetail();

                switch (item.Type)
                {

                    case FtpObjectType.Directory:
                        // Console.WriteLine("Directory!  " + item.FullName);
                        //Console.WriteLine("Modified date:  " + FtpClient.GetModifiedTime(item.FullName));
                        break;

                    case FtpObjectType.File:
                        // Console.WriteLine("File!  " + item.FullName);
                        fileDetail.FileFullName = item.FullName;
                        fileDetail.FileName = item.Name;
                        fileDetail.FileLastWriteTimeUtc = FtpClient.GetModifiedTime(item.FullName);
                        fileDetails.Add(fileDetail);
                        //Console.WriteLine("File size:  " + FtpClient.GetFileSize(item.FullName));
                        //Console.WriteLine("Modified date:  " + FtpClient.GetModifiedTime(item.FullName));
                        //Console.WriteLine("Chmod:  " + FtpClient.GetChmod(item.FullName));
                        break;

                    case FtpObjectType.Link:
                        break;
                }
            }
            var searchFileName = sourceFolderPath + sourceFileName;
            var fileExtension = searchFileName.Split(".").Last();
            string FileNameOnly = String.Empty;
            if (sourceFileName.Contains("*"))
            {
                FileNameOnly = sourceFileName.Substring(0, sourceFileName.LastIndexOf("*"));
            }
            else
            {
                FileNameOnly = sourceFileName.Substring(0, sourceFileName.LastIndexOf("."));
            }
            return fileDetails.Where(x => x.FileName!.Contains(FileNameOnly) && x.FileName.Split(".").Last() == fileExtension).OrderByDescending(x => x.FileLastWriteTimeUtc).FirstOrDefault()!;
        }

        public List<FileDetail> GetPurgingFile(string sourceFolderPath)
        {
            List<FileDetail> fileDetails = new List<FileDetail>();
            // get a recursive listing of the files & folders in a specific folder
            foreach (var item in FtpClient.GetListing(sourceFolderPath, FtpListOption.Recursive))
            {
                FileDetail fileDetail = new FileDetail();

                switch (item.Type)
                {

                    case FtpObjectType.File:

                        //Console.WriteLine("File!  " + item.FullName);
                        fileDetail.FileFullName = item.FullName;
                        fileDetail.FileName = item.Name;
                        fileDetail.FileLastWriteTimeUtc = FtpClient.GetModifiedTime(item.FullName);
                        // Console.WriteLine("File size:  " + FtpClient.GetFileSize(item.FullName));
                        //Console.WriteLine("Modified date:  " + FtpClient.GetModifiedTime(item.FullName));
                        //Console.WriteLine("Chmod:  " + FtpClient.GetChmod(item.FullName));
                        fileDetails.Add(fileDetail);
                        break;

                    case FtpObjectType.Link:
                        break;
                }
            }
            return fileDetails;
        }

        public List<FileDetail> GetPurgingDirectory(string sourceFolderPath)
        {
            List<FileDetail> directoryDetails = new List<FileDetail>();
            // get a recursive listing of the files & folders in a specific folder
            foreach (var item in FtpClient.GetListing(sourceFolderPath, FtpListOption.Recursive))
            {
                FileDetail fileDetail = new FileDetail();

                switch (item.Type)
                {

                    case FtpObjectType.Directory:

                        fileDetail.FileFullName = item.FullName;
                        fileDetail.FileName = item.Name;
                        fileDetail.FileLastWriteTimeUtc = FtpClient.GetModifiedTime(item.FullName);
                        directoryDetails.Add(fileDetail);
                        //Console.WriteLine("Directory!  " + item.FullName);
                        //Console.WriteLine("Modified date:  " + FtpClient.GetModifiedTime(item.FullName));
                        break;

                    case FtpObjectType.Link:
                        break;
                }
            }
            return directoryDetails;
        }
        public abstract string ServerDetails();

        public void DeleteDirectory(string directoryPath)
        {
            FtpClient.DeleteDirectory(directoryPath);
        }
    }
}
