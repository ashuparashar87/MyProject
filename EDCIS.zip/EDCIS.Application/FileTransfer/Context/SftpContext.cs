﻿using EDCIS.Application.ClientInfrastructure.Dtos;
using EDCIS.Application.Interface;
using Renci.SshNet;
using Renci.SshNet.Common;
using Renci.SshNet.Sftp;
using SharpCompress.Archives;
using SharpCompress.Readers;

namespace EDCIS.Application.Context
{
    public abstract class SftpContext : IRemoteFileSystemContext
    {
        static long totalUnCompressedSize;
        protected SftpClient SftpClient { get; set; } = null!;
        string? FileSizeRestriction = SD.FileSizeRestriction;


        public void Connect()
        {
            SftpClient.Connect();
        }

        public void Disconnect()
        {
            SftpClient.Disconnect();
        }

        public void Dispose()
        {
            if (SftpClient != null)
            {
                SftpClient.Dispose();
            }
        }

        /*actions*/
        public bool FileExists(string filePath)
        {
            return SftpClient.Exists(filePath);
        }

        public void DeleteFileIfExists(string filePath)
        {
            if (FileExists(filePath))
            {
                SftpClient.DeleteFile(filePath);
            }
        }

        public bool UnZipFile(MemoryStream ms, string remoteFilePath, string? zipPassword, out int unzippedfilesCount)
        {
            var result = true;
            unzippedfilesCount = 0;          
             if (!string.IsNullOrEmpty(zipPassword))
            {
                ms.Seek(0, SeekOrigin.Begin);
                using (var zip = ArchiveFactory.Open(ms, new ReaderOptions { Password = zipPassword }))
                {                   
                    unzippedfilesCount = zip.Entries.Count();

                    foreach (var e in zip.Entries)
                    {
                        long unCompressedSize = e.Size;
                        totalUnCompressedSize += unCompressedSize;
                    }

                    if (totalUnCompressedSize <= Convert.ToInt64(FileSizeRestriction))
                    {
                        foreach (var entry in zip.Entries)
                        {
                            using (Stream stream = entry.OpenEntryStream())
                            {
                                if (entry.Key != null)
                                {
                                    if (entry.Key.Contains('/'))
                                    {
                                        int lastIndex = entry.Key.LastIndexOf('/');
                                        string path = remoteFilePath + entry.Key.Substring(0, lastIndex);
                                        CreateDirectoryRecursively(SftpClient, path);
                                    }
                                    if (!entry.IsDirectory)
                                    {
                                        SftpClient.UploadFile(stream, remoteFilePath + entry.Key);
                                    }
                                }
                            }
                        }
                        return result;
                    }
                    else
                    {
                       return result = false;
                    }
                }
            }
            else
            {
                ms.Seek(0, SeekOrigin.Begin);
                using (var zip = ArchiveFactory.Open(ms))
                {
                    unzippedfilesCount = zip.Entries.Count();

                    foreach (var e in zip.Entries)
                    {
                        long unCompressedSize = e.Size;
                        totalUnCompressedSize += unCompressedSize;
                    }

                    if (totalUnCompressedSize <= Convert.ToInt64(FileSizeRestriction))
                    {
                        foreach (var entry in zip.Entries)
                        {
                            using (Stream stream = entry.OpenEntryStream())
                            {
                                if (entry.Key != null)
                                {
                                    if (entry.Key.Contains('/'))
                                    {
                                        int lastIndex = entry.Key.LastIndexOf('/');
                                        string path = remoteFilePath + entry.Key.Substring(0, lastIndex);
                                        CreateDirectoryRecursively(SftpClient, path);
                                    }
                                    if (!entry.IsDirectory)
                                    {
                                        SftpClient.UploadFile(stream, remoteFilePath + entry.Key);
                                    }
                                }
                            }
                        }
                        return result;
                    }
                    else
                    {
                       return result = false;                        
                    }
                }
            }
        }

        public void CreateDirectoryRecursively(SftpClient client, string path)
        {
            string current = "";

            if (path[0] == '/')
            {
                path = path.Substring(1);
            }

            while (!string.IsNullOrEmpty(path))
            {
                int p = path.IndexOf('/');
                current += '/';
                if (p >= 0)
                {
                    current += path.Substring(0, p);
                    path = path.Substring(p + 1);
                }
                else
                {
                    current += path;
                    path = "";
                }

                try
                {
                    SftpFileAttributes attrs = client.GetAttributes(current);
                    if (!attrs.IsDirectory)
                    {
                        throw new Exception("not directory");
                    }
                }
                catch (SftpPathNotFoundException)
                {
                    client.CreateDirectory(current);
                }
            }
        }
        public bool UploadFile(MemoryStream ms, string remoteFilePath)
        {
            ms.Position = 0;
            var result = true;           
            byte[] fileData = ms.ToArray();
            totalUnCompressedSize = fileData.Length;
            if (totalUnCompressedSize <= Convert.ToInt64(FileSizeRestriction))
            {
                SftpClient.UploadFile(ms, remoteFilePath);
                return result;
            }
            else
            {
               return result = false;              
            }
        }

        public bool DirectoryExists(string directoryPath)
        {
            return SftpClient.Exists(directoryPath);
        }

        public void CreateDirectoryIfNotExists(string directoryPath)
        {
            if (!DirectoryExists(directoryPath))
            {
                SftpClient.CreateDirectory(directoryPath);
            }
        }

        public MemoryStream DownloadFile(string remoteFilePath)
        {
            MemoryStream ms = new MemoryStream();
            SftpClient.DownloadFile(remoteFilePath, ms);
            return ms;
        }

        public bool IsConnected()
        {
            return SftpClient.IsConnected;
        }

        public void SetWorkingDirectory(string directoryPath)
        {
            SftpClient.ChangeDirectory(directoryPath);
        }

        public void SetRootAsWorkingDirectory()
        {
            SetWorkingDirectory("");
        }
        public FileDetail GetListingDirectory(string sourceFolderPath, string sourceFileName)
        {
            var fileDetails = new List<FileDetail>();
            ListFile(SftpClient, sourceFolderPath, ref fileDetails);
            var searchFileName = sourceFolderPath + sourceFileName;

            var fileExtension = searchFileName.Split(".").Last();
            string FileNameOnly = String.Empty;
            if (sourceFileName.Contains("*"))
            {
                FileNameOnly = sourceFileName.Substring(0, sourceFileName.LastIndexOf("*"));
            }
            else
            {
                FileNameOnly = sourceFileName.Substring(0, sourceFileName.LastIndexOf("."));
            }
            return fileDetails.Where(x => x.FileName!.Contains(FileNameOnly) && x.FileName.Split(".").Last() == fileExtension).OrderByDescending(x => x.FileLastWriteTimeUtc).FirstOrDefault()!;
        }

        public List<FileDetail> GetPurgingFile(string sourceFolderPath)
        {
            var fileDetails = new List<FileDetail>();
            ListFile(SftpClient, sourceFolderPath, ref fileDetails);
            return fileDetails;
        }
        public List<FileDetail> GetPurgingDirectory(string sourceFolderPath)
        {
            var fileDetails = new List<FileDetail>();
            ListDirectory(SftpClient, sourceFolderPath, ref fileDetails);
            return fileDetails;
        }
        void ListDirectory(SftpClient client, String dirName, ref List<FileDetail> files, int depth = 0)
        {
            foreach (var entry in client.ListDirectory(dirName))
            {

                if (entry.IsDirectory)
                {
                    if (!entry.Name.StartsWith("."))
                    {
                        var filedetail = new FileDetail();
                        filedetail.FileFullName = entry.FullName;
                        filedetail.FileName = entry.Name;
                        filedetail.FileLastWriteTimeUtc = entry.LastWriteTimeUtc;
                        filedetail.Depth = depth;
                        files.Add(filedetail);
                        ListDirectory(client, entry.FullName, ref files, depth + 1);
                    }
                }

            }
        }

        void ListFile(SftpClient client, String dirName, ref List<FileDetail> files)
        {
            foreach (var entry in client.ListDirectory(dirName))
            {

                if (entry.IsDirectory)
                {
                    if (!entry.Name.StartsWith("."))
                    {
                        ListFile(client, entry.FullName, ref files);
                    }
                }

                else
                {
                    var filedetail = new FileDetail();
                    filedetail.FileFullName = entry.FullName;
                    filedetail.FileName = entry.Name;
                    filedetail.FileLastWriteTimeUtc = entry.LastWriteTimeUtc;
                    files.Add(filedetail);
                }
            }
        }

        public void DeleteDirectory(string directoryPath)
        {
            SftpClient.DeleteDirectory(directoryPath);
        }
        public abstract string ServerDetails();
    }
}
