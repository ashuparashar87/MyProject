﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDCIS.Application.Context
{
    public class FileDetail
    {
        public string? FileName { get; set; }
        public string? FileFullName { get; set; }
        public DateTime FileLastWriteTimeUtc { get; set; }

        public int Depth { get; set; }
    }
}
