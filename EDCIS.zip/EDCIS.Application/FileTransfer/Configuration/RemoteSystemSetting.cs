﻿namespace EDCIS.Application.Configuration
{
    public class RemoteSystemSetting
    {
        public string Host { get; set; } = null!;
        public int Port { get; set; }     
        public string UserName { get; set; } = null!;
        public string Password { get; set; } = null!;
        public string Type { get; set; } = null!;
        public string Encryption { get; set; } = null!;
    }
}
