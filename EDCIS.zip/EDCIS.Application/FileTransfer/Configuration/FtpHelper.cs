﻿namespace EDCIS.Application.Configuration
{
    public class FtpHelper
    {
        public static string ServerDetails
            (string host, string port, string userName, string encryption, string type = "FTP")
        {
            return String.Format("Type: '{3}' Host:'{0}' Port:'{1}' User: '{2}'", host, port, userName, type);
        }
    }
}
