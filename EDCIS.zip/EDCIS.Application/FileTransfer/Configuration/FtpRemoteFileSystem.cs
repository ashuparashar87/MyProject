﻿using EDCIS.Application.Context;
using EDCIS.Domain.Enum;
using FluentFTP;

namespace EDCIS.Application.Configuration
{
    public class FtpRemoteFileSystem : FtpContext
    {
        private string _serverDetails;

        public FtpRemoteFileSystem(RemoteSystemSetting setting)
        {
            _serverDetails = FtpHelper.ServerDetails(setting.Host, setting.Port.ToString(), setting.UserName, setting.Encryption, setting.Type);
            FtpClient = new FtpClient(setting.Host);
            FtpClient.Credentials = new System.Net.NetworkCredential(setting.UserName, setting.Password);
            FtpClient.Port = setting.Port;
            if (setting.Encryption == EncryptionMode.Explicit.ToString())
            {
                FtpClient.Config.EncryptionMode = FtpEncryptionMode.Explicit;
                FtpClient.Config.ValidateAnyCertificate = true;
            }
            else if (setting.Encryption == EncryptionMode.Implicit.ToString())
            {
                FtpClient.Config.EncryptionMode = FtpEncryptionMode.Implicit;
            }
        }

        public override string ServerDetails()
        {
            return _serverDetails;
        }
    }
}
