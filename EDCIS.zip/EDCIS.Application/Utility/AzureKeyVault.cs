﻿using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using EDCIS.Application.ClientInfrastructure.Dtos;
using EDCIS.Application.Utility.Constant;
using Microsoft.Extensions.Caching.Memory;
using System.Security.Cryptography.X509Certificates;
namespace EDCIS.Application.Utility
{
    public static class AzureKeyVault
    {
        private static readonly MemoryCache _cache = new MemoryCache(new MemoryCacheOptions());

        public static X509Certificate2 GetKeyVaultCertificate()
        {
            var cachedKey = CacheKeys.CachedCertificate;
            if (_cache.TryGetValue(cachedKey, out X509Certificate2? cachedCertificate))
            {
                return cachedCertificate!;
            }
            else
            {
                var defaultCreds = new DefaultAzureCredential();
                var uri = new System.Uri(SD.AzureKeyVaultUri);
                var client = new SecretClient(uri, defaultCreds);
                KeyVaultSecret secret = client.GetSecret(SD.AzureKeyVaultCertName);
                var flags = X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.EphemeralKeySet;
                var cert = new X509Certificate2(Convert.FromBase64String(secret.Value), string.Empty, flags);
                _cache.Set(cachedKey, cert, TimeSpan.FromHours(SD.TokenCacheTime));
                return cert;
            }
        }
    }
}
