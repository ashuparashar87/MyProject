﻿using System.Security.Claims;

namespace EDCIS.Application.Utility
{
    public static class Extensions
    {
        public static string? GetClaim(this List<Claim> claims, string name)
        {
            return claims.FirstOrDefault(c => c.Type == name)?.Value;
        }
    }
    public static class DateTimeExtensionMethods
    {
        public static string GetAdvancedDateFormat(this DateTime? dt, string nullDisplay = "")
        => dt == null ? nullDisplay : ((DateTime)dt).ToString("dd-MMM-yyyy");


        #region "DateTime Shifting (Utc to Local / Local to Utc)"

        //PART II: The DateTime?s (nullable):
        public static DateTime? ShiftUtcToLocal(this DateTime? dt, string timezoneOffsetMinutesString)
        {
            return ShiftUtcToLocal(dt, GetTimezoneOffsetFromString(timezoneOffsetMinutesString));
        }
        public static DateTime? ShiftUtcToLocal(this DateTime? dt, int timezoneOffsetMinutes)
        {
            if (!dt.HasValue) return dt;
            return Convert.ToDateTime(dt).AddMinutes(-timezoneOffsetMinutes);
        }
        public static DateTime? ShiftLocalToUtc(this DateTime? dt, string timezoneOffsetMinutesString)
        {
            return ShiftLocalToUtc(dt, GetTimezoneOffsetFromString(timezoneOffsetMinutesString));
        }
        public static DateTime? ShiftLocalToUtc(this DateTime? dt, int timezoneOffsetMinutes)
        {
            if (!dt.HasValue) return dt;
            return Convert.ToDateTime(dt).AddMinutes(+timezoneOffsetMinutes);
        }

        //PART II: The DateTimes (non-nullable):

        public static DateTime ShiftUtcToLocal(this DateTime dt, string timezoneOffsetMinutesString)
        {
            return ShiftUtcToLocal(dt, GetTimezoneOffsetFromString(timezoneOffsetMinutesString));
        }
        public static DateTime ShiftUtcToLocal(this DateTime dt, int timezoneOffsetMinutes)
        {
            return Convert.ToDateTime(dt).AddMinutes(-timezoneOffsetMinutes);
        }
        public static DateTime ShiftLocalToUtc(this DateTime dt, string timezoneOffsetMinutesString)
        {
            return ShiftLocalToUtc(dt, GetTimezoneOffsetFromString(timezoneOffsetMinutesString));
        }
        public static DateTime ShiftLocalToUtc(this DateTime dt, int timezoneOffsetMinutes)
        {
            return Convert.ToDateTime(dt).AddMinutes(+timezoneOffsetMinutes);
        }
        private static int GetTimezoneOffsetFromString(string timezoneOffsetMinutesString)
        {
            int timezoneOffsetMinutes = 0;
            try
            {
                timezoneOffsetMinutes = int.Parse(timezoneOffsetMinutesString);
            }
            catch
            {
                //               throw new ApplicationException("The timezoneOffsetMinutesString of " + timezoneOffsetMinutesString + " can't be converted to a valid integer.");
                //2022-08-11 RMcQ: $FINISH$/$IMPROVE$: Currently playing VERY safe by just avoiding any possible runtime errors
                //due to lack of TimezoneOffset (cookie): if anything's wrong, revert to using UTC.
                //ALSO note that there is currently no logging to see if anything went wrong:
                timezoneOffsetMinutes = 0;
            }
            return timezoneOffsetMinutes;
        }

        #endregion
    }
}
