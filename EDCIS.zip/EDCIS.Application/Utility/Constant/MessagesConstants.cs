﻿using EDCIS.Application.ClientInfrastructure.Dtos;

namespace EDCIS.Application.Utility.Constant
{
    public static class MessagesConstants
    {
        public const string SaveSuccessMessage = "Saved Successfully!";
        public const string DeleteSASAutomationMessage = "Unable to delete this FTP Site because it is being used by an existing EDC SAS Automation Configuration";

        public const string WebJobManuallyTriggered = "EDCIS WebJob Manually triggered";

        public static string SASAutomationStartedMessage(string configName)
        {
            return $"Started SAS Automation {configName}-Start Stopwatch";
        }
        public static string StudyStausClosedMessage(string configName)
        {
            return $"Study status is closed in CTMS for {configName}";
        }
        public static string WebJobStartedMessage()
        {
            return $"Started EDCIS WebJob Run-Start Stopwatch";
        }
        // public const string WebJobStartedMessage = "Started EDCIS WebJob Run";
        public const string WebJobAlreadyRunningMessage = "EDCIS WebJob Already Running, Exiting";
        public static string SASAutomationstoRunCountMessage(int count)
        {
            return $"SAS Automations to Run:{count}";
        }
        public static string SASAutomationSkippingRumMessage(string configName)
        {
            return $"Skipping record {configName} due to previous error";
        }
        //public const string WebJobEndedMessage = "Finished EDCIS WebJob Run";
        public static string WebJobEndedMessage(string timeTaken)
        {
            return $"Finished EDCIS WebJob Run-{timeTaken}";
        }


        public const string LatestFileTransferMessage = "Latest File is already transferred to destination";

        public static string FTPConnectedSuccessMessage(string protocolNumber, string hostName, int? portNumber)
        {
            return $"Successfully Connected to Server {"[" + protocolNumber + "]"}:{"[" + hostName + "]"}:{"[" + portNumber + "]"}";
        }
        public static string FTPConnectedFailureMessage(string protocolNumber, string hostName, int? portNumber, string errorMessage)
        {
            return $"Error Connecting to Server {"[" + protocolNumber + "]"}:{"[" + hostName + "]"}:{"[" + portNumber + "]"}-Error={"[" + errorMessage + "]"}";
        }
        public static string SourceConnectedSuccessMessage(string protocolNumber, string hostName, int? portNumber)
        {
            return $"Successfully Connected to Source {"[" + protocolNumber + "]"}:{"[" + hostName + "]"}:{"[" + portNumber + "]"}";
        }
        public static string SourceConnectedFailureMessage(string protocolNumber, string hostName, int portNumber, string errorMessage)
        {
            return $"Error Connecting to Source {"[" + protocolNumber + "]"}:{"[" + hostName + "]"}:{"[" + portNumber + "]"}-Error={"[" + errorMessage + "]"}";
        }

        public static string MatchingFileFoundMessage(string fileName, string folderName)
        {
            return $"New Matching File Found: {"[" + fileName + "]"} in Source Folder {"[" + folderName + "]"}";
        }
        public static string MatchingFileNotFoundMessage(string folderName)
        {
            return $"No New Matching File Found in Source Folder {"[" + folderName + "]"}";
        }
        public static string MatchingDirectoryNotFoundMessage(string folderName)
        {
            return $"No Matching Directory Found in  Folder {"[" + folderName + "]"}";
        }
        public static string SourceFileNotFoundMessage(string folderName)
        {
            return $"No Matching File Found in Source Folder {"[" + folderName + "]"}";
        }
        public static string DestinationFileNotFoundMessage(string folderName)
        {
            return $"No Matching File Found in Destination Folder {"[" + folderName + "]"}";
        }
        public static string SASAutomationEndedMessage(string configName, string timeTaken)
        {
            return $"Finished SAS Automation {"[" + configName + "]"}-{timeTaken}";
        }
        public static string DestinationConnectedSuccessMessage(string protocolNumber, string hostName, int portNumber)
        {
            return $"Successfully Connected to Destination {"[" + protocolNumber + "]"}:{"[" + hostName + "]"}:{"[" + portNumber + "]"}";
        }
        public static string DestinationConnectedFailureMessage(string protocolNumber, string hostName, int portNumber, string errorMessage)
        {
            return $"Error Connecting to Destination {"[" + protocolNumber + "]"}:{"[" + hostName + "]"}:{"[" + portNumber + "]"}-Error={"[" + errorMessage + "]"}";
        }
        public static string CleanedFolderSuccessMessage(string folderName)
        {
            return $"Successfully Cleaned Current Folder {"[" + folderName + "]"}";
        }

        public static string CleanedFolderFailureMessage(string folderName, string errorMessage)
        {
            return $"Error Cleaning Current Folder {"[" + folderName + "]"} - Error={"[" + errorMessage + "]"}";
        }

        public static string CopyToArchiveStartedMessage(string fileName, string folderName)
        {
            return $"Starting Copy of {"[" + fileName + "]"} to Archive Folder {"[" + folderName + "]"}";
        }
        public static string CopyToArchiveSuccessMessage(string fileName, string folderName)
        {
            return $"Successfully Copied {"[" + fileName + "]"} to Archive Folder {"[" + folderName + "]"}";
        }
        public static string CopyToArchiveFailureMessage(string fileName, string folderName, string errorMessage)
        {

            return $"Error Copying {"[" + fileName + "]"} to Archive Folder {"[" + folderName + "]"} - Error={"[" + errorMessage + "]"}";
        }

        public static string UnzipingStartedMessage(string fileName, string folderName)
        {
            return $"Starting Unzip of {"[" + fileName + "]"} to Current Folder {"[" + folderName + "]"}";
        }
        public static string UnzipingSuccessMessage(string fileName, string folderName, int unzippedfilesCount)
        {
            return $"Successfully Unzipped {"[" + fileName + "]"} to Current Folder {"[" + folderName + "]"} with Unzipped file count {"[" + unzippedfilesCount + "]"}";
        }
        public static string UnzipingFailureMessage(string fileName, string folderName, string errorMessage)
        {
            return $"Error Unzipping {"[" + fileName + "]"} to Current Folder {"[" + folderName + "]"} - Error={"[" + errorMessage + "]"}";
        }

        public static string CopyToDestinationStratedMessage(string fileName, string folderName)
        {
            return $"Starting Copy of {"[" + fileName + "]"} to Current Folder {"[" + folderName + "]"}";
        }
        public static string CopyToDestinationSuccessMessage(string fileName, string folderName)
        {
            return $"Successfully Copied {"[" + fileName + "]"} to Current Folder {"[" + folderName + "]"}";
        }
        public static string CopyToDestinationFailureMessage(string fileName, string folderName, string errorMessage)
        {
            return $"Error Copying {"[" + fileName + "]"} to Current Folder {"[" + folderName + "]"}- Error={"[" + errorMessage + "]"}";
        }
        public static string SourceFileDeletionConfiguredMessage(string folderName)
        {
            return $"Source Deletion Not Configured for Source Folder {"[" + folderName + "]"}";
        }
        public static string SourceFileDeletedSuccessMessage(string fileName, string folderName)
        {
            return $"Successfully Deleted Source File {"[" + fileName + "]"} in Folder {"[" + folderName + "]"}";
        }
        public static string SourceFileDeletedFailureMessage(string fileName, string folderName, string errorMessage)
        {
            return $"Error Deleting Source File {"[" + fileName + "]"} in Folder {"[" + folderName + "]"}- Error={"[" + errorMessage + "]"}";
        }
        public static string DestinationArchivePurgeFolderStartedMessage(string folderName)
        {
            return $"Starting Purge of Destination Archive Folder {"[" + folderName + "]"}";
        }

        public static string DestinationArchivePurgeFolderSuccessMessage(string folderName)
        {
            return $"Successfully Purged Destination Archive Folder {"[" + folderName + "]"}";
        }
        public static string DestinationArchivePurgeFolderFailureMessage(string folderName, string errorMessage)
        {
            return $"Error Purging Destination Archive Folder {"[" + folderName + "]"}- Error={"[" + errorMessage + "]"}";
        }
        public static string UISourceConnectedSuccessMessage(string hostName, string SourceFolderPath)
        {
            return $"Successfully Connected to Source Host {"[" + hostName + "]"}. Source Folder {"[" + SourceFolderPath + "]"} Exists!";
        }
        public static string UISourceConnectedFailureMessage(string hostName, string SourceFolderPath)
        {
            return $"Successfully Connected to Source Host {"[" + hostName + "]"}. Source Folder {"[" + SourceFolderPath + "]"} Does Not Exist!";
        }
        public static string UIDestConnectedArchiveFailureMessage(string hostName, string ArchiveDestFolderPath, string CurrentDestFolderPath)
        {
            return $"Successfully Connected to Destination Host {"[" + hostName + "]"}. Archive Destination Folder {"[" + ArchiveDestFolderPath + "]"} Does Not Exist! Current Destination Folder {"[" + CurrentDestFolderPath + "]"} Exists!";
        }
        public static string UIDestConnectedFailureMessage(string hostName, string ArchiveDestFolderPath, string CurrentDestFolderPath)
        {
            return $"Successfully Connected to Destination Host {"[" + hostName + "]"}. Archive Destination Folder {"[" + ArchiveDestFolderPath + "]"} Exists! Current Destination Folder {"[" + CurrentDestFolderPath + "]"} Does Not Exist!";
        }
        public static string UIArchieveDestConnectedFailureMessage(string hostName, string ArchiveDestFolderPath, string CurrentDestFolderPath)
        {
            return $"Successfully Connected to Destination Host {"[" + hostName + "]"}. Archive Destination Folder {"[" + ArchiveDestFolderPath + "]"} Does Not Exist! Current Destination Folder {"[" + CurrentDestFolderPath + "]"} Does Not Exist!";
        }
        public static string UIDestConnectedSuccessMessage(string hostName, string ArchiveDestFolderPath, string CurrentDestFolderPath)
        {
            return $"Successfully Connected to Destination Host {"[" + hostName + "]"}. Archive Destination Folder {"[" + ArchiveDestFolderPath + "]"} Exists! Current Destination Folder {"[" + CurrentDestFolderPath + "]"} Exists!";
        }
        public static string HistoryLogSuccessMessage()
        {
            return $"Successfully Purged History Logs";
        }
        public static string DuplicateErrorMsgFTPSite = "FTP Site with same name already exists.";
        public static string DuplicateErrorMsgSASConfig = "SAS Config with same name already exists.";
        public static string HistoryLogStartedMessage()
        {
            return $"Started Purging of History Logs";
        }

        public static string HistoryLogFailureMessage(string errorMessage)
        {
            return $"Error while Purging History Log -Error={"[" + errorMessage + "]"}";
        }

        public static string EmailFailureMessage(string errorMessage)
        {
            return $"Error while sending Email-Error={"[" + errorMessage + "]"}";
        }

        public static string FileSizeErrorMessage()
        {
            return "File size exceeds the maximum limit of " + Convert.ToInt64(SD.FileSizeRestriction).ToString("N0") + " bytes";
        }
        public static string SASProgramLaunchingMessage(string configName)
        {
           return $"SASProgramLaunching-Launching SAS Program{"[" + configName + "]"}";
        }
        public static string SASProgramLaunchedMessage(string configName)
        {
            return $"SASProgramLaunched-Successfully Launched SAS Program{"[" + configName + "]"}";
        }
        public static string SASProgramLaunchErrorMessage(string configName,string errorMessage)
        {
            return $"Error Launching SAS Program {"[" + configName + "]"}-Error={"[" + errorMessage + "]"}";
        }

        public const string UnknownError = "Unknown Error";

        public const string IsInMaintenanceMode = "IsInMaintenanceMode";
        public class RoleList
        {
            public int Precedence { get; set; }
            public string? Role { get; set; }
        }
        public const string SystemUserEmail = "SystemUser@advancedgroup.com";
        public const string SystemUserFName = "System User";


    }
    public static class CacheKeys
    {
        public static string CachedCertificate = "Certificate";
    }

}

