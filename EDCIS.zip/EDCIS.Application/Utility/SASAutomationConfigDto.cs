﻿using EDCIS.Domain.Entities;
using EDCIS.Domain.Enum;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDCIS.Application.Utility
{
    public class SASAutomationConfigDto
    {
        public int Id { get; set; }
        public string StudyID { get; set; } = null!;

        [Display(Name = "Last File Transferred")]
        public string? FileName { get; set; }

        [Display(Name = "Config Name")]
        public string ConfigName { get; set; } = null!;

        [Display(Name = "File Protocol")]
        public string? SourceFileProtocol { get; set; }

        [Display(Name = "Encryption")]
        public string? SourceEncryption { get; set; }

        [Display(Name = "Host Name")]
        public string? SourceHostName { get; set; }

        [Display(Name = "Port Number")]
        public int? SourcePortNumber { get; set; }

        [Display(Name = "User Name")]
        public string? SourceUserName { get; set; }

        [Display(Name = "Password")]
        public string? SourcePassword { get; set; }

        [Display(Name = "File Name")]
        public string SourceFileName { get; set; } = null!;

        [Display(Name = "Zip Password")]
        public string? SourceZipPassword { get; set; }

        [Display(Name = "Folder Path")]
        public string SourceFolderPath { get; set; } = null!;

        [Display(Name = "Delete Source File After Transfer")]
        public bool? IsDeleteFileAfterTransfer { get; set; } = false;

        [Display(Name = "File Protocol")]
        public string? DestFileProtocol { get; set; }

        [Display(Name = "Encryption")]
        public string? DestEncryption { get; set; }

        [Display(Name = "Host Name")]
        public string? DestHostName { get; set; }

        [Display(Name = "Port Number")]
        public int? DestPortNumber { get; set; }

        [Display(Name = "User Name")]
        public string? DestUserName { get; set; }
        [Display(Name = "Password")]
        public string? DestPassword { get; set; }
        [Display(Name = "Archive Destination Folder")]
        public string ArchiveDestFolderPath { get; set; } = null!;
        [Display(Name = "Current Destination Folder")]
        public string CurrentDestFolderPath { get; set; } = null!;

        [Display(Name = "Last Run")]
        public DateTime? TransferDate { get; set; }

        [Display(Name = "Daily")]
        public bool IsDaily { get; set; }

        [Display(Name = "Is Active")]
        public bool IsEDCActive { get; set; }
        public string? WeekDays { get; set; }

        [Display(Name = "Time Slot (local time)")]
        public string? TimeSlot { get; set; }
        [Display(Name = "Last SAS Launch DateTime")]
        public string? LastSASLaunchDateTime { get; set; }
        [Display(Name = "Last Error Date Time")]
        public string? LastErrorDateTime { get; set; }
        [Display(Name = "Last Error")]
        public string? LastError { get; set; }
        [Display(Name = "Execute Program After Transfer")]
        public bool? ExecuteProgramAfterTransfer { get; set; } = false;
        [Display(Name = "Description")]
        public string? Description { get; set; }
        [Display(Name = "File")]
        public string? File { get; set; }
        [Display(Name = "Path")]
        public string? Path { get; set; }
        [Display(Name = "Arguments")]
        public string? Arguments { get; set; }
        [Display(Name = "Timeout In Seconds")]
        public int? TimeoutInSeconds { get; set; } = 60;

        [Display(Name = "HasError")]
        public bool HasError { get; set; }
        [Display(Name = "Configuration Type")]
        public string? ConfigurationType { get; set; }

        public string? CreatedBy { get; set; } = string.Empty;
        public string? CreatedDate { get; set; }
        public string? LastModifiedBy { get; set; }
        public string? LastModifiedDate { get; set; }
    }
}
