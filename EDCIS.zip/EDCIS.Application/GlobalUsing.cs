﻿global using Microsoft.Extensions.DependencyInjection;
global using MediatR;
global using EDCIS.Application.Contracts.HandlerInterfaces;
global using EDCIS.Application.Handler;
global using AutoMapper;
