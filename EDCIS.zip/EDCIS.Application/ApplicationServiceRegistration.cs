﻿using EDCIS.Application.Client;
using EDCIS.Application.ClientInfrastructure.Dtos;
using EDCIS.Application.Utility;
using Microsoft.Extensions.Configuration;
using System.Reflection;

namespace EDCIS.Application
{
    public static class ApplicationServiceRegistration
    {
        public static IServiceCollection AddApplicationServices(this IServiceCollection services, IConfiguration configuration)
        {
          
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
            services.AddScoped(typeof(IEDCRequestHandler<>), typeof(EDCRequestHandler<>));
            services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly()));
            var emailConfig = configuration
                .GetSection("EmailConfiguration")
                .Get<EmailConfiguration>();
            services.AddSingleton(emailConfig!);

            services.AddHttpClient<ISASAgentService, SASAgentService>(c =>
            {
                c.BaseAddress = new Uri(SD.EdcSasAgentUrl);
                c.Timeout = new TimeSpan(0, 0, 60);
                c.DefaultRequestHeaders.Clear();

            });
            SD.CriticalErrorEmail_ToEmail = configuration["CriticalErrorEmail:ToEmail"];
            SD.CriticalErrorEmail_Subject = configuration["CriticalErrorEmail:Subject"];
            SD.CriticalErrorEmail_BodyTemplate = configuration["CriticalErrorEmail:BodyTemplate"];

            SD.WebJobAlreadyRunning_ToEmail = configuration["WebJobAlreadyRunningEmail:ToEmail"];
            SD.WebJobAlreadyRunning_Subject = configuration["WebJobAlreadyRunningEmail:Subject"];
            SD.WebJobAlreadyRunning_BodyTemplate = configuration["WebJobAlreadyRunningEmail:BodyTemplate"];

            SD.SuccessEmail_Subject = configuration["SuccessEmail:Subject"];
            SD.SuccessEmail_BodyTemplate = configuration["SuccessEmail:BodyTemplate"];
            SD.FileSizeRestriction = configuration["FileSizeRestriction"];
            SD.EdcSasAgentUrl= configuration["EdcSasAgent:EdcSasAgentUrl"];

            SD.Admin = configuration["AdGroups:Admin"];
            SD.ITAdmin = configuration["AdGroups:ITAdmin"];
            SD.DataManager = configuration["AdGroups:DataManager"];
            SD.Statistician = configuration["AdGroups:Statistician"];
            SD.ReadOnly = configuration["AdGroups:Readonly"];


            SetAzureKeyVaultParam(configuration);
            SetSharePointParam(configuration);
            SetEmailParam(configuration);
            return services;
        }

        private static void SetAzureKeyVaultParam(IConfiguration configuration)
        {
            SD.AzureKeyVaultUri = configuration["AzureKeyVault:AzureKeyVaultUri"]!;
            SD.AzureKeyVaultCertName = configuration["AzureKeyVault:AzureKeyVaultCertName"]!;
            SD.TokenCacheTime = Convert.ToDouble(configuration["AzureKeyVault:TokenCacheTime"]);
        }
        private static void SetSharePointParam(IConfiguration configuration)
        {
            SD.SharePointClientId = configuration["SharePointConfig:SharePointClientId"]!;
            SD.SharePointTenantId = configuration["SharePointConfig:SharePointTenantId"]!;
        }
        private static void SetEmailParam(IConfiguration configuration)
        {
            SD.EmailFrom = configuration["EmailConfiguration:From"]!;
            SD.EmailPort = configuration["EmailConfiguration:Port"]!;
            SD.EmailSmtpServer = configuration["EmailConfiguration:SmtpServer"]!;
            SD.EmailUsername = configuration["EmailConfiguration:Username"]!;
            SD.OfficeURL = configuration["EmailConfiguration:OfficeURL"]!;
        }
    }
}