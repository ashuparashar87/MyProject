﻿namespace EDCIS.Application.ClientInfrastructure.Dtos
{

    public class ResponseDto
    {
        public bool IsSuccess { get; set; } = true;

        public object? value { get; set; }
        public object? error { get; set; }
        public int code { get; set; }
        public string? message { get; set; }

    }

    public static class SD
    {
        public static string? Admin { get; set; }
        public static string? ITAdmin { get; set; }
        public static string? Statistician { get; set; }
        public static string? DataManager { get; set; }
        public static string? ReadOnly { get; set; }
        public static string? OktaApiToken { get; set; }
        public static bool AuthenticationFeatureToggle { get; set; }


        public static string? UserName { get; set; }
        public static string? Password { get; set; }
        public static string? UserId { get; set; }

        public static string SASAutomationWebJobUrl { get; set; } = null!;
        public static string SASAutomationWebJobUserName { get; set; } = null!;
        public static string SASAutomationWebJobPassword { get; set; } = null!;
        public static string? CriticalErrorEmail_ToEmail { get; set; }
        public static string? Error_ToEmail { get; set; }
        public static string? CriticalErrorEmail_Subject { get; set; }
        public static string? CriticalErrorEmail_BodyTemplate { get; set; }
        public static string? WebJobAlreadyRunning_BodyTemplate { get; set; }
        public static string? WebJobAlreadyRunning_ToEmail { get; set; }
        public static string? WebJobAlreadyRunning_Subject { get; set; }
   
        public static string? SuccessEmail_Subject { get; set; }
        public static string? SuccessEmail_BodyTemplate { get; set; }
        public enum ApiType
        {
            GET,
            POST,
            PUT,
            DELETE
        }
        public static string? FileSizeRestriction { get; set; }
        public static string? EdcSasAgentUrl { get; set; }

        public static double TokenCacheTime { get; set; }
        public static double ApiCacheTime { get; set; }
        //Share Point configuration Params
        public static string SharePointClientId { get; set; } = null!;
        public static string SharePointTenantId { get; set; } = null!;

        //Azure KeyVault configuration Params
        public static string AzureKeyVaultUri { get; set; } = null!;
        public static string AzureKeyVaultCertName { get; set; } = null!;
        //Email configuration Params
        public static string EmailFrom { get; set; } = null!;
        public static string EmailSmtpServer { get; set; } = null!;
        public static string EmailPort { get; set; } = null!;
        public static string EmailUsername { get; set; } = null!;
        public static string OfficeURL { get; set; } = null!;
    }
    public class AgentCommand
    {
        public string Description = string.Empty;
        public string File = string.Empty;
        public string Path = string.Empty;
        public int Timeout = 60000;
        public string Args = string.Empty;
    }
    public class ApiResponse
    {
        public bool LaunchSuccess = false;
        public int ResultCode = 0;
        public string Message = string.Empty;
        public string ExceptionMsg = string.Empty;
        public string LogFile = string.Empty;
    }
}
