﻿using EDCIS.Application.ClientInfrastructure.Dtos;

namespace EDCIS.Application.Client
{
    public interface ISASAgentService
    {
        Task<HttpResponseMessage> PingAgentService();
        Task<ApiResponse> RunAgentService(AgentCommand agentCommand);
    }
}
