﻿using System;
using System.Net.Http.Headers;
using System.Text;
using EDCIS.Application.ClientInfrastructure.Dtos;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace EDCIS.Application.Client
{
    public class SASAgentService : ISASAgentService
    {
        private HttpClient _client;
        private IConfiguration _config;
        public SASAgentService(HttpClient client, IConfiguration config)
        {
            _client = client;
            _config = config;
        }
        public async Task<HttpResponseMessage> PingAgentService()
        {
            var request = new HttpRequestMessage(
                   HttpMethod.Get,
                   "get");
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            request.Headers.Add("XApiKey", _config["EdcSasAgent:XApiKey"]);
            using (var response = await _client.SendAsync(request,
               HttpCompletionOption.ResponseHeadersRead))
            {
                var apiContent = await response.Content.ReadAsStringAsync();
                return response.EnsureSuccessStatusCode();
            }
        }

        public async Task<ApiResponse> RunAgentService(AgentCommand agentCommand)
        {
            var request = new HttpRequestMessage(
                  HttpMethod.Post,
                  "Run");

            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            request.Headers.Add("XApiKey", _config["EdcSasAgent:XApiKey"]);
            var jsonContent = JsonConvert.SerializeObject(agentCommand);
            var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");
            request.Content = content;
            using (var response = await _client.SendAsync(request,
               HttpCompletionOption.ResponseHeadersRead))
            {
                try
                {
                    var apiContent = await response.Content.ReadAsStringAsync();

                    response.EnsureSuccessStatusCode();
                    return JsonConvert.DeserializeObject<ApiResponse>(apiContent)!;
                }
                catch (Exception ex)
                {
                    ApiResponse apiResponse = new();
                    apiResponse.LaunchSuccess = false;
                    apiResponse.Message = ex.Message;
                    return apiResponse!;
                }
            }
        }
    }
}
