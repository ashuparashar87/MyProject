﻿using EDCIS.Domain.Entities;
using System.Linq.Expressions;
namespace EDCIS.Application.Persistence
{
    public interface IAsyncRepository<T> where T : class
    {
        Task<IReadOnlyList<T>> GetPagedReponseAsync(int page, int size);
        Task<IReadOnlyList<T>> GetAllAsync();
        Task<IReadOnlyList<T>> GetAsync(Expression<Func<T, bool>> predicate);
        Task<IReadOnlyList<T>> GetAsync(Expression<Func<T, bool>>? predicate = null,
        Func<IQueryable<T>, IOrderedQueryable<T>>? orderBy = null,
        string? includeString = null,
        bool disableTracking = true);

        Task<T?> GetByIdAsync(object key);
        Task<T> AddAsync(T entity);
        Task UpdateAsync(T entity);
        Task DeleteAsync(T entity);
        Task<List<AutomationReportResult>> GetRowSQLAsync(DateTime? fromDate, DateTime? toDate, long? studyId, string? initiatedBy, bool groupByStudy, bool groupByInitiated);
    }
}
