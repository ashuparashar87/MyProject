﻿using EDCIS.Application.Persistence;
using EDCIS.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDCIS.Application.Handler
{
    public record GetResourceListCommandQuery() : IRequest<List<Resource>>;
   
    internal class GetResourceQueryHandler : IRequestHandler<GetResourceListCommandQuery, List<Resource>>
    {
        private readonly IAsyncRepository<Resource> _resourceRepository;
        public GetResourceQueryHandler(IAsyncRepository<Resource> resourceRepository)
        {
            _resourceRepository = resourceRepository;
        }

        public async Task<List<Resource>> Handle(GetResourceListCommandQuery request, CancellationToken cancellationToken)
        {
            var resourceList =  await _resourceRepository.GetAllAsync();
            return resourceList.ToList();
        }
    }

    public record GetResourceByIdQuery(long id) : IRequest<Resource?>;

    internal class GetResourceByIdQueryHandler : IRequestHandler<GetResourceByIdQuery, Resource?>
    {
        private readonly IAsyncRepository<Resource> _resourceRepository;
        public GetResourceByIdQueryHandler(IAsyncRepository<Resource> resourceRepository)
        {
            _resourceRepository = resourceRepository;
        }

        public async Task<Resource?> Handle(GetResourceByIdQuery request, CancellationToken cancellationToken)
        {
            return await _resourceRepository.GetByIdAsync(request.id);
           
        }
    }

    public record GetResourceByEmailIdQuery(string email) : IRequest<Resource?>;

    internal class GetResourceByEmailQueryHandler : IRequestHandler<GetResourceByEmailIdQuery, Resource?>
    {
        private readonly IAsyncRepository<Resource> _resourceRepository;
        public GetResourceByEmailQueryHandler(IAsyncRepository<Resource> resourceRepository)
        {
            _resourceRepository = resourceRepository;
        }

        public async Task<Resource?> Handle(GetResourceByEmailIdQuery request, CancellationToken cancellationToken)
        {
            return (await _resourceRepository.GetAsync(x=>x.EmailAddress== request.email && x.IsActive)).SingleOrDefault();
        }
    }
}
