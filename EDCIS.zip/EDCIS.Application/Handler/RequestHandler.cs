﻿using EDCIS.Application.Persistence;
using System.Linq.Expressions;

namespace EDCIS.Application.Handler
{
    public class EDCRequestHandler<T> : IEDCRequestHandler<T> where T : class
    {
        private readonly IAsyncRepository<T> _repository;

        public EDCRequestHandler(IAsyncRepository<T> repository)
        {
            _repository = repository;
        }

        public async Task<T> AddRequestAsync(T entity)
        {
            await _repository.AddAsync(entity);
            return entity;
        }
        public async Task UpdateRequestAsync(T entity)
        {
            await _repository.UpdateAsync(entity);
        }
        public async Task DeleteRequestAsync(T entity)
        {
            await _repository.DeleteAsync(entity);
        }

        public async Task<IEnumerable<T>> GetAllAsync()
        {
            var entity = await _repository.GetAllAsync();
            return entity;
        }

        public async Task<T?> GetRequestByIdAsync(object key)
        {
            var entity = await _repository.GetByIdAsync(key);
            return entity;
        }

        public async Task<IEnumerable<T>> GetAsync(Expression<Func<T, bool>>? predicate = null, Func<IQueryable<T>, IOrderedQueryable<T>>? orderBy = null, string? includeString = null, bool disableTracking = true)
        {
            var entity = await _repository.GetAsync(predicate, orderBy, includeString, disableTracking);
            return entity;
        }
    }
}
