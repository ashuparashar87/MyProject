﻿using EDCIS.Application.Persistence;
using EDCIS.Domain.Entities;

namespace EDCIS.Application.Handler
{
    public record CreateFTPSiteConfigCommand(FTPSiteConfig model) : IRequest<Unit>;
    public class CreateFTPSiteConfigCommandHandler : IRequestHandler<CreateFTPSiteConfigCommand, Unit>
    {
        private readonly IAsyncRepository<FTPSiteConfig> _ftpSiteConfigRepository;

        public CreateFTPSiteConfigCommandHandler(IAsyncRepository<FTPSiteConfig> EDCConfigRepository, IAsyncRepository<FTPSiteConfig> ftpSiteConfigRepository)
        {
            _ftpSiteConfigRepository = ftpSiteConfigRepository;
        }

        public async Task<Unit> Handle(CreateFTPSiteConfigCommand request, CancellationToken cancellationToken)
        {
            var existRecord = await _ftpSiteConfigRepository.GetAsync(x => x.Id == request.model.Id);

            if (existRecord.Count == 0)
            {
                await _ftpSiteConfigRepository.AddAsync(request.model);
            }
            else
            {
                var updatedRecord = existRecord.SingleOrDefault();
                if (updatedRecord != null)
                {
                    updatedRecord.FTPSite = request.model.FTPSite;
                    updatedRecord.FileProtocol = request.model.FileProtocol;
                    updatedRecord.Encryption = request.model.Encryption;
                    updatedRecord.HostName = request.model.HostName;
                    updatedRecord.PortNumber = request.model.PortNumber;
                    updatedRecord.UserName = request.model.UserName;
                    updatedRecord.Password = request.model.Password;
                    await _ftpSiteConfigRepository.UpdateAsync(updatedRecord);
                }
            }
            return Unit.Value;
        }
    }
}
