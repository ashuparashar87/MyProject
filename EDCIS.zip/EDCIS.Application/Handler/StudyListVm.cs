﻿namespace EDCIS.Application.Handler
{
    public class StudyListVm
    {
        public string StudyID { get; set; } = null!;
        public string? StudyName { get; set; }
        public string? ProtocolNumber { get; set; }
        public string? StudyStatus { get; set; }
        public long SponsorId { get; set; }
        public long TherapeuticId { get; set; }
        public string? TherapeuticArea { get; set; }
        public long IndicationId { get; set; }
        public string? Indication { get; set; }
        public string? ProjectNumber { get; set; }
        public string? SponsorName { get; set; }
        public string? MedidataStudyId { get; set; }
        public string Url { get; set; } = null!;
        public string? Username { get; set; }
        public string? SASAutomation { get; set; }
        public bool HasError { get; set; } = false;
    }

    public class SponsorListVm
    {
        public string? SponsorCode { get; set; }
        public string? SponsorName { get; set; }
    }
    public class TitleDetails
    {
        public string? StudyName { get; set; }
        public string? ProtocolNumber { get; set; }
        public string? SponsorName { get; set; }
        public string? StudyStatus { get; set; }
    }
}
