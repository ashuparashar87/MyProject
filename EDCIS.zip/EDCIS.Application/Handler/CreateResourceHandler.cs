﻿using EDCIS.Application.Persistence;
using EDCIS.Domain.Entities;

namespace EDCIS.Application.Handler
{
    public record CreateResourceCommand(Resource model) : IRequest<Unit>;
    public class CreateResourceHandler : IRequestHandler<CreateResourceCommand, Unit>
    {
        private readonly IAsyncRepository<Resource> _resourceRepository;
        private readonly IMapper _mapper;
        public CreateResourceHandler(IMapper mapper, IAsyncRepository<Resource> resourceRepository)
        {
            _resourceRepository = resourceRepository;
            _mapper = mapper;
        }

        public async Task<Unit> Handle(CreateResourceCommand request, CancellationToken cancellationToken)
        {
            await _resourceRepository.AddAsync(request.model);
            return Unit.Value;
        }
    }
}
