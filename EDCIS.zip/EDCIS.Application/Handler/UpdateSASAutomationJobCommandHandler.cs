﻿using EDCIS.Application.Persistence;
using EDCIS.Domain.Entities;

namespace EDCIS.Application.Handler
{
    public record UpdateSASAutomationJobCommand(int configId, string fileName) : IRequest<Unit>;
    public class UpdateSASAutomationJobCommandHandler : IRequestHandler<UpdateSASAutomationJobCommand, Unit>
    {
        private readonly IAsyncRepository<SASAutomationConfig> _SASAutomationConfigRepository;
        public UpdateSASAutomationJobCommandHandler(IAsyncRepository<SASAutomationConfig> SASAutomationConfigRepository)
        {
            _SASAutomationConfigRepository = SASAutomationConfigRepository;
        }
        public async Task<Unit> Handle(UpdateSASAutomationJobCommand request, CancellationToken cancellationToken)
        {
            var existRecord = await _SASAutomationConfigRepository.GetAsync(x => x.Id == request.configId);
            if (existRecord != null)
            {
                var updatedRecord = existRecord.SingleOrDefault();
                if (updatedRecord != null)
                {
                    updatedRecord.FileName = request.fileName;
                    updatedRecord.TransferDate = DateTime.UtcNow;
                    updatedRecord.IsErrorInLastExecution = false;
                    await _SASAutomationConfigRepository.UpdateAsync(updatedRecord);
                }
            }
            return Unit.Value;
        }
    }

    public record UpdateErrorInLastExecutionCommand(int configId, bool IsErrorInLastExecution = false) : IRequest<Unit>;
    public class UpdateErrorInLastExecutionCommandHandler : IRequestHandler<UpdateErrorInLastExecutionCommand, Unit>
    {
        private readonly IAsyncRepository<SASAutomationConfig> _SASAutomationConfigRepository;
        public UpdateErrorInLastExecutionCommandHandler(IAsyncRepository<SASAutomationConfig> SASAutomationConfigRepository)
        {
            _SASAutomationConfigRepository = SASAutomationConfigRepository;
        }
        public async Task<Unit> Handle(UpdateErrorInLastExecutionCommand request, CancellationToken cancellationToken)
        {
            var existRecord = await _SASAutomationConfigRepository.GetAsync(x => x.Id == request.configId);
            if (existRecord != null)
            {
                var updatedRecord = existRecord.SingleOrDefault();
                if (updatedRecord != null)
                {
                    updatedRecord.IsErrorInLastExecution = request.IsErrorInLastExecution;
                    await _SASAutomationConfigRepository.UpdateAsync(updatedRecord);
                }
            }
            return Unit.Value;
        }
    }
}
