﻿using EDCIS.Application.Persistence;
using EDCIS.Domain.Entities;

namespace EDCIS.Application.Handler
{
    public record UpdateEDCISConfigurationCommand(EDCISConfiguration model) : IRequest<Unit>;
    public class UpdateEDCISConfigurationHandler : IRequestHandler<UpdateEDCISConfigurationCommand, Unit>
    {
        private readonly IAsyncRepository<EDCISConfiguration> _EDCConfigRepository;
        private readonly IMapper _mapper;
        public UpdateEDCISConfigurationHandler(IMapper mapper, IAsyncRepository<EDCISConfiguration> EDCConfigRepository)
        {
            _EDCConfigRepository = EDCConfigRepository;
            _mapper = mapper;
        }

        public async Task<Unit> Handle(UpdateEDCISConfigurationCommand request, CancellationToken cancellationToken)
        {
            var existRecord = await _EDCConfigRepository.GetAsync(x => x.Id == request.model.Id);
            if (existRecord != null)
            {
                var updatedRecord = existRecord.SingleOrDefault();
                if (updatedRecord != null)
                {
                    updatedRecord.Value = request.model.Value;
                    updatedRecord.Description = request.model.Description;
                    await _EDCConfigRepository.UpdateAsync(updatedRecord);
                }
            }
            return Unit.Value;
        }
    }

    public record UpdateAutomationAfterSASLaunchCommand(SASAutomationConfig model) : IRequest<Unit>;
    public class UpdateAutomationAfterSASLaunchCommandHandler : IRequestHandler<UpdateAutomationAfterSASLaunchCommand, Unit>
    {
        private readonly IAsyncRepository<SASAutomationConfig> _SASAutomationConfigRepository;
        public UpdateAutomationAfterSASLaunchCommandHandler(IMapper mapper, IAsyncRepository<SASAutomationConfig> SASConfigRepository)
        {
            _SASAutomationConfigRepository = SASConfigRepository;
        }

        public async Task<Unit> Handle(UpdateAutomationAfterSASLaunchCommand request, CancellationToken cancellationToken)
        {
             await _SASAutomationConfigRepository.UpdateAsync(request.model);
            return Unit.Value;
        }
    }
}
