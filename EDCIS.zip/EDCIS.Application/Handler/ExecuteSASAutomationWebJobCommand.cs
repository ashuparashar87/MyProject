﻿using Azure;
using EDCIS.Application.Client;
using EDCIS.Application.ClientInfrastructure.Dtos;
using EDCIS.Application.Configuration;
using EDCIS.Application.Context;
using EDCIS.Application.Interface;
using EDCIS.Application.Utility.Constant;
using EDCIS.Domain.Entities;
using EDCIS.Domain.Enum;
using Renci.SshNet.Messages;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace EDCIS.Application.Handler
{
    public record ExecuteSASAutomationWebJobCommand(long? configId = null) : IRequest<Response>;
    public class Response
    {
        public bool IsSuccess { get; set; }
        public string? Message { get; set; }
    }

    public class ExecuteSASAutomationWebJobCommandHandler : IRequestHandler<ExecuteSASAutomationWebJobCommand, Response> 
    {
        private readonly IMediator _mediator;
        private readonly ISASAgentService _agentService;
        private HashSet<SourceDestFTPSite> _failedRecords = new HashSet<SourceDestFTPSite>(); // To track records that failed
        private int _successCount = 0;
        private int _ignoreCount = 0;
        private int _errorCount = 0; // Total errors encountered

        public ExecuteSASAutomationWebJobCommandHandler(IMediator mediator, ISASAgentService agentService)
        {
            _mediator = mediator;
            _agentService = agentService;
        }

        public async Task<Response> Handle(ExecuteSASAutomationWebJobCommand request, CancellationToken cancellationToken)
        {
            string message = string.Empty;
            bool isSuccess=true;
            var timer = new Stopwatch();
            Console.WriteLine(MessagesConstants.WebJobStartedMessage());
            await LogMessageAsync(ProcessType.WebJob, MessagesConstants.WebJobStartedMessage(), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
            var config = (await _mediator.Send(new GetEDCISConfigurationByKeyQuery("IsSASAutomationJobRunning"))).SingleOrDefault();
            if (config != null && config?.Value == "0")
            {
                try
                {
                    config.Value = "1";
                    await _mediator.Send(new UpdateEDCISConfigurationCommand(config));

                    List<SASAutomationConfig>? edcDetails;
                    if (request.configId != null && request.configId != 0)
                    {
                        edcDetails = await _mediator.Send(new GetSASAutomationConfigQuery(request.configId));
                        if (edcDetails.Count > 0)
                        {
                            timer.Start();
                            await LogMessageAsync(edcDetails.Single(), ProcessType.WebJob, MessagesConstants.WebJobManuallyTriggered, string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                            var resp = await RunAutomationJob(edcDetails.Single(), timer, edcDetails.Count, edcDetails.Count);
                            isSuccess = resp.Item1;
                            message = resp.Item2;
                            timer.Stop();
                            TimeSpan timeSpan = timer.Elapsed;
                            var ConfigtimeTaken = $"Time taken:{(int)timeSpan.TotalMinutes}M:{timeSpan.Seconds:00}S";
                            Console.WriteLine(ProcessType.WebJob + "" + MessagesConstants.WebJobEndedMessage(ConfigtimeTaken));
                            await LogMessageAsync(edcDetails.Single(), ProcessType.WebJob, MessagesConstants.WebJobEndedMessage(ConfigtimeTaken), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                        }
                    }
                    else
                    {
                        var edcList = await _mediator.Send(new GetSASAutomationConfigQuery());
                        // edcDetails = edcList.ToList();//While run on local host use this code
                        edcDetails = edcList.Where(x => (x.TimeSlot == DateTime.UtcNow.ToString("t") && string.IsNullOrEmpty(x.WeekDays))
                                                  || x.IsErrorInLastExecution == true
                                                  || (x.TimeSlot == DateTime.UtcNow.ToString("t") && (!string.IsNullOrEmpty(x.WeekDays))
                                                   && x.WeekDays.Contains(DateTime.Now.DayOfWeek.ToString()))).ToList();


                        if (edcDetails != null && edcDetails.Count > 0)
                        {
                            int jobCount = 0;
                            foreach (var edc in edcDetails)
                            {
                                edc.ConfigurationType = edc.ConfigurationType == null ? ConfigurationTypeValue.FileTransfer : edc.ConfigurationType;
                                if (edc.ConfigurationType == ConfigurationTypeValue.FileTransfer)
                                {
                                    if (edc.IsEDCActive)
                                    {
                                        // Method to check if any pair in the HashSet contains a specific string
                                        bool ContainsString(HashSet<SourceDestFTPSite> pairs, string target)
                                        {
                                            return pairs.Any(pair => pair.SourceFTPSite == target || pair.DestFTPSite == target);
                                        }
                                        if (ContainsString(_failedRecords, edc.SourceFTPSite == null ? "" : edc.SourceFTPSite))
                                        {
                                            await LogMessageAsync(edc!, ProcessType.SASAutomation, MessagesConstants.SASAutomationSkippingRumMessage(edc.ConfigName), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                                            continue;
                                        }
                                        if (ContainsString(_failedRecords, edc.DestFTPSite == null ? "" : edc.DestFTPSite))
                                        {
                                            await LogMessageAsync(edc!, ProcessType.SASAutomation, MessagesConstants.SASAutomationSkippingRumMessage(edc.ConfigName), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                                            continue;
                                        }
                                        timer.Start();
                                        if (jobCount == 0)
                                        {
                                            Console.WriteLine(MessagesConstants.SASAutomationstoRunCountMessage(edcDetails.Count));
                                            await LogMessageAsync(edc!, ProcessType.SASAutomation, MessagesConstants.SASAutomationstoRunCountMessage(edcDetails.Count), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                                        }
                                        jobCount++;
                                    }                                    
                                }
                                var isIgnored = await RunAutomationJob(edc!, timer, jobCount, edcDetails.Count);
                                if (isIgnored.Item1)
                                {
                                    _ignoreCount++;
                                    _errorCount++; // Increment error count for each ignored file
                                }
                                else
                                {
                                    _successCount++;
                                    if (edc.ConfigurationType == ConfigurationTypeValue.FileTransfer)
                                    {
                                        await RunPurgeJob(edc!);
                                    }
                                }
                            }
                            LogSummary();
                            timer.Stop();
                            TimeSpan timeSpan = timer.Elapsed;
                            var ConfigtimeTaken = $"Time taken:{(int)timeSpan.TotalMinutes}M:{timeSpan.Seconds:00}S";
                            Console.WriteLine(MessagesConstants.WebJobEndedMessage(ConfigtimeTaken));
                            await LogMessageAsync(ProcessType.WebJob, MessagesConstants.WebJobEndedMessage(ConfigtimeTaken), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                        }
                        else
                        {
                            timer.Stop();
                            TimeSpan timeSpan = timer.Elapsed;
                            Console.WriteLine(MessagesConstants.SASAutomationstoRunCountMessage(edcDetails!.Count));
                            await LogMessageAsync(ProcessType.SASAutomation, MessagesConstants.SASAutomationstoRunCountMessage(edcDetails.Count), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                            var ConfigtimeTaken = $"Time taken:{(int)timeSpan.TotalMinutes}M:{timeSpan.Seconds:00}S";
                            Console.WriteLine(MessagesConstants.WebJobEndedMessage(ConfigtimeTaken));
                            await LogMessageAsync(ProcessType.WebJob, MessagesConstants.WebJobEndedMessage(ConfigtimeTaken), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                        }
                    }
                    config.Value = "0";
                    await _mediator.Send(new UpdateEDCISConfigurationCommand(config));
                }
                finally
                {
                    config.Value = "0";
                    await _mediator.Send(new UpdateEDCISConfigurationCommand(config));
                }

            }
            else
            {
                Console.WriteLine("EDCIS WebJob Already Running, Exiting");
                timer.Stop();
                TimeSpan timeSpan = timer.Elapsed;
                var ConfigtimeTaken = $"Time taken:{(int)timeSpan.TotalMinutes}M:{timeSpan.Seconds:00}S";
                await LogMessageAsync(ProcessType.WebJob, MessagesConstants.WebJobAlreadyRunningMessage, string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                await LogMessageAsync(ProcessType.WebJob, MessagesConstants.WebJobEndedMessage(ConfigtimeTaken), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                await _mediator.Send(new WebJonAlreadyRunningSenderCommand(string.Empty));
                Console.WriteLine("Email Sent");
            }
            Console.WriteLine("Job is completed");
            return new Response
            {
                IsSuccess = isSuccess,
                Message = message
            };
        }

        private void LogSummary()
        {
            Console.WriteLine($"Web Job Finished processing-{_successCount} file(s) processed successfully.{_ignoreCount} file(s) ignored with {_errorCount} error(s) total.");
        }
        private async Task<(bool, string)> RunAutomationJob(SASAutomationConfig edc, Stopwatch timer, int jobCount, int edcDetailsCount)
        {
            try
            {
                var studyDetail = await _mediator.Send(new GetTitleCommandQuery(edc.StudyID));
                if (studyDetail != null && studyDetail.StudyStatus == "Closed")
                {
                    edc.IsEDCActive = false;
                    await _mediator.Send(new UpdateAutomationAfterSASLaunchCommand(edc));
                    await LogMessageAsync(edc, ProcessType.SASAutomation, MessagesConstants.StudyStausClosedMessage(edc.ConfigName!), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                    return (true,string.Empty);
                }
                var configlist = await _mediator.Send(new GetEDCISConfigurationListQuery());
                edc.Arguments = configlist.Where(x => x.Key == "SASProgramArguments").Select(x => x.Value).FirstOrDefault();
                edc.File = configlist.Where(x => x.Key == "SASProgramFile").Select(x => x.Value).FirstOrDefault();
                edc.TimeoutInSeconds = configlist.Where(x => x.Key == "SASProgramTimeout").Select(x => Convert.ToInt16(x.Value)).FirstOrDefault();
                Console.WriteLine(MessagesConstants.SASAutomationStartedMessage(edc.ConfigName!));
                await LogMessageAsync(edc, ProcessType.SASAutomationStart, MessagesConstants.SASAutomationStartedMessage(edc.ConfigName!), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                edc.ConfigurationType = edc.ConfigurationType == null ? ConfigurationTypeValue.FileTransfer : edc.ConfigurationType;
                if (edc.ConfigurationType == ConfigurationTypeValue.FileTransfer)
                {
                    if (edc.IsEDCActive)
                    {
                        var file = await FileDownLoadStream(edc);

                        if (file.memoryStream.Length > 0)
                        {
                            if (file.isNewestMatchingFile)
                            {
                                bool IsSuccessfullyTransferred = false;
                                if (file.memoryStream != null)
                                {
                                    string archiveDestinationFolderPath = edc.ArchiveDestFolderPath == null ? "" : edc.ArchiveDestFolderPath;
                                    string currentDestinationFolderPath = edc.CurrentDestFolderPath == null ? "" : edc.CurrentDestFolderPath;

                                    IsSuccessfullyTransferred = await FileTransferUploadStream(edc, file.memoryStream, file.filename);
                                    string remoteCurrentFullDestinationFolderPath = edc.CurrentDestFolderPath + file.filename;
                                    string remoteCurrentFullArchiveDestinationFolderPath = edc.ArchiveDestFolderPath + file.filename;

                                    if (IsSuccessfullyTransferred)
                                    {
                                        bool isUnzipSuccess = false;
                                        if (remoteCurrentFullArchiveDestinationFolderPath.Contains(".zip"))
                                        {
                                            string FileNameOnly = file.filename.Substring(0, file.filename.LastIndexOf("."));
                                            string remotezipPath = currentDestinationFolderPath;
                                            Console.WriteLine(MessagesConstants.UnzipingStartedMessage(file.filename, edc.CurrentDestFolderPath == null ? "" : edc.CurrentDestFolderPath));
                                            await LogMessageAsync(edc, ProcessType.FileUnzipStarted, MessagesConstants.UnzipingStartedMessage(file.filename, edc.CurrentDestFolderPath == null ? "" : edc.CurrentDestFolderPath), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                                            isUnzipSuccess = await UnzipFileStream(edc, file.memoryStream, file.filename, remotezipPath);

                                            if (edc.IsDeleteFileAfterTransfer && isUnzipSuccess)
                                            {
                                                await DeleteSourceFile(edc, file.filename);
                                            }
                                            if (isUnzipSuccess)
                                            {
                                                await UpdateEdcJobDetails(edc.Id, file.filename);
                                                Console.WriteLine("Edc Config Details Updated");
                                            }

                                        }
                                        else
                                        {
                                            IsSuccessfullyTransferred = await NonUnzipFileTransfer(edc, file.memoryStream, file.filename);
                                            if (IsSuccessfullyTransferred)
                                            {
                                                await UpdateEdcJobDetails(edc.Id, file.filename);

                                                Console.WriteLine("Edc Config Details Updated");
                                            }

                                            if (edc.IsDeleteFileAfterTransfer)
                                            {
                                                await DeleteSourceFile(edc, file.filename);
                                                await UpdateEdcJobDetails(edc.Id, file.filename);
                                            }
                                        }
                                        if (!edc.IsDeleteFileAfterTransfer)
                                        {
                                            Console.WriteLine(MessagesConstants.SourceFileDeletionConfiguredMessage(edc.SourceFolderPath!));
                                            await LogMessageAsync(edc, ProcessType.SourceDeletionNotConfigured, MessagesConstants.SourceFileDeletionConfiguredMessage(edc.SourceFolderPath == null ? "" : edc.SourceFolderPath), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                                        }
                                        timer.Stop();
                                        TimeSpan timeSpan = timer.Elapsed;
                                        var ConfigtimeTaken = $"Time taken:{(int)timeSpan.TotalMinutes}M:{timeSpan.Seconds:00}S";
                                        Console.WriteLine(MessagesConstants.SASAutomationEndedMessage(edc.ConfigName, ConfigtimeTaken));
                                        await LogMessageAsync(edc, ProcessType.WebJob, MessagesConstants.SASAutomationEndedMessage(edc.ConfigName, ConfigtimeTaken), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());

                                    }
                                }
                                else
                                {
                                    Console.WriteLine(MessagesConstants.LatestFileTransferMessage);
                                    await LogMessageAsync(edc, ProcessType.FileTransfer, MessagesConstants.LatestFileTransferMessage, string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                                }
                            }
                            return (false,string.Empty);
                        }
                        else
                        {
                            timer.Stop();
                            TimeSpan timeSpanTaken = timer.Elapsed;
                            var JobtimeTaken = $"Time taken:{(int)timeSpanTaken.TotalMinutes}M:{timeSpanTaken.Seconds:00}S"; ;
                            await LogMessageAsync(edc, ProcessType.WebJob, MessagesConstants.SASAutomationEndedMessage(edc.ConfigName, JobtimeTaken), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                            return (true, string.Empty);
                        }
                    }
                    return (false, string.Empty);
                }
                else
                {
                    var message=await RunAgentService(edc);
                    await SASConfigLogMessageAsync(edc.Id);
                    if (!string.IsNullOrEmpty(edc.SuccessEmailRecipients))
                    {
                        await SendSuccessEmail(edc);
                    }
                    return (message.Item1, message.Item2);
                }
            }
            catch (Exception ex)
            {
                string Error = string.IsNullOrEmpty(ex.Message + ex.InnerException?.Message) ? MessagesConstants.UnknownError : ex.Message + ex.InnerException?.Message;
                Console.WriteLine(ProcessType.SASAutomation + ex.Message);
                await _mediator.Send(new UpdateErrorInLastExecutionCommand(edc.Id, true));
                await LogMessageAsync(edc, ProcessType.SASAutomation, Error, Error, SD.UserId == null ? "Schedule" : SD.UserId.ToString());

                string errorMessage = string.Format("<b> For User:</b> EDCIS.WebJobs" + "<br/>" + "<b>" + "Study ID : " + "</b>" + edc.StudyID + "<br/>" + "<b>" + "Config Name : " + "</b>" + edc.ConfigName + "<br/>" + "<b>" + "Error Message : " + "</b>" + Error);
                await _mediator.Send(new EmailSenderCommand(edc, errorMessage));

                timer.Stop();
                TimeSpan timeSpanTaken = timer.Elapsed;
                var JobtimeTaken = $"Time taken:{(int)timeSpanTaken.TotalMinutes}M:{timeSpanTaken.Seconds:00}S"; ;
                await LogMessageAsync(edc, ProcessType.WebJob, MessagesConstants.SASAutomationEndedMessage(edc.ConfigName, JobtimeTaken), string.Empty, SD.UserId);
                _failedRecords.Add(new SourceDestFTPSite(edc.SourceFTPSite == null ? "" : edc.SourceFTPSite, edc.DestFTPSite == null ? "" : edc.DestFTPSite));// Add to failed records
                return (true, string.Empty);

            }
        }

        private async Task SendSuccessEmail(SASAutomationConfig edc)
        {
            string successMessage = string.Format("<b> For User:</b> EDCIS.WebJobs" + "<br/>" + "<b>" + "Study ID : " + "</b>" + edc.StudyID + "<br/>" + "<b>" + "Config Name : " + "</b>" + edc.ConfigName + "<br/>" + "<b>" + "Success Message : " + "</b>" + "SAS Automation Successfully Run");
            await _mediator.Send(new SuccessEmailSenderCommand(edc, successMessage));
        }

        private async Task RunPurgeJob(SASAutomationConfig edc)
        {
            Console.WriteLine(ProcessType.PurgeDestArchive + "-" + "Started");
            var PurgeDetails = (await _mediator.Send(new GetEDCSettingQuery())).FirstOrDefault();
            if (PurgeDetails != null && PurgeDetails.DestArchivePurgePeriod != 0)
            {
                await PurgeDestArchiveFolder(edc, PurgeDetails.DestArchivePurgePeriod);
            }
            if (PurgeDetails != null && PurgeDetails.HistoryPurgePeriod != 0)
            {
                Console.WriteLine("History Log Purge Started");
                var historyLogs = await _mediator.Send(new GetDeleteHistoryLogsCommand(PurgeDetails!.HistoryPurgePeriod));
                if (historyLogs != null && historyLogs.Count > 0)
                {
                    try
                    {
                        await LogMessageAsync(ProcessType.PurgeHistoryLogs, MessagesConstants.HistoryLogStartedMessage(), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                        await PurgeLogMessage(PurgeDetails!.HistoryPurgePeriod);
                        await LogMessageAsync(ProcessType.PurgeHistoryLogsSuccess, MessagesConstants.HistoryLogSuccessMessage(), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                    }
                    catch (Exception ex)
                    {
                        string Error = string.IsNullOrEmpty(ex.Message + ex.InnerException?.Message) ? MessagesConstants.UnknownError : ex.Message + ex.InnerException?.Message;
                        await LogMessageAsync(ProcessType.ErrorPurgingHistoryLogs, MessagesConstants.HistoryLogFailureMessage(Error), Error, SD.UserId == null ? "Schedule" : SD.UserId.ToString());

                        string ErrorMessage = "<b> For User:</b> EDCIS.WebJobs" + string.Format(MessagesConstants.HistoryLogFailureMessage(Error));
                        await _mediator.Send(new EmailSenderCommand(edc, ErrorMessage));
                    }
                }
                Console.WriteLine("History Log Purge Successfully");
            }

        }
        private async Task UpdateEdcJobDetails(int configId, string fileName)
        {
            await _mediator.Send(new UpdateSASAutomationJobCommand(configId, fileName));
        }
        private async Task<(bool, string)> RunAgentService(SASAutomationConfig config)
        {
            await LogMessageAsync(config, ProcessType.SASProgramLaunching, MessagesConstants.SASProgramLaunchingMessage(config.ConfigName), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());

            bool isSuccess = false;
            string message = string.Empty;

            try
            {
                string? tempPath = Path.GetDirectoryName(config.Path);
                AgentCommand agentCommand = new AgentCommand()
                {
                    Args = config.Arguments!.Replace("{0}", config.Path),
                    Description = config.Description ?? string.Empty,
                    File = config.File ?? string.Empty,
                    Path = tempPath ?? string.Empty,
                    Timeout = config.TimeoutInSeconds

                };
                var response = await _agentService.RunAgentService(agentCommand);
                if (response.LaunchSuccess)
                {
                    await LogMessageAsync(config, ProcessType.SASProgramLaunched, MessagesConstants.SASProgramLaunchedMessage(config.ConfigName), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                    isSuccess = true;
                    message = response.Message;
                }
                else
                {
                    isSuccess = false;
                    message = response.Message;
                    await LogMessageAsync(config, ProcessType.ErrorLaunchingSASProgram, MessagesConstants.SASProgramLaunchErrorMessage(config.ConfigName, response.Message), response.ExceptionMsg, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                }
                config.LastSASLaunchDateTime = DateTime.UtcNow;
                config.LastSASLogFile = "Call SAS api to get Logs";
                await _mediator.Send(new UpdateAutomationAfterSASLaunchCommand(config));
                return (isSuccess,message);
            }

            catch (Exception ex)
            {
                isSuccess = false;
                await LogMessageAsync(config, ProcessType.ErrorLaunchingSASProgram, MessagesConstants.SASProgramLaunchErrorMessage(config.ConfigName, ex.Message), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());

            }
            return (isSuccess, message);
        }

        private async Task SASConfigLogMessageAsync(int configId)
        {
            var log = await _mediator.Send(new GetLogsByConfigIdQuery(configId));
            if (log != null)
            {
                var updateSASConfig = await _mediator.Send(new GetSASAutomationConfigByIdQuery(configId));
                updateSASConfig.LastError = log.ExceptionMessage;
                updateSASConfig.LastErrorDateTime = log.TimeStamp;
                await _mediator.Send(new UpdateAutomationAfterSASLaunchCommand(updateSASConfig));
            }
        }
        private async Task LogMessageAsync(Enum process, string message, string errorMsg, string? initiatedBy)
        {
            HistoryLog log = new HistoryLog();
            log.TimeStamp = DateTime.UtcNow;
            log.EDCConfigID = 0;
            log.StudyID = 0;
            log.ConfigName = string.Empty;
            log.Process = (ProcessType)process;
            log.LogDetails = message;
            log.ExceptionMessage = errorMsg;
            await _mediator.Send(new CreateHistoryLogsCommand(log));
        }
        private async Task LogMessageAsync(SASAutomationConfig edc, Enum process, string message, string errorMsg, string? initiatedBy)
        {
            HistoryLog log = new HistoryLog();
            log.TimeStamp = DateTime.UtcNow;
            log.EDCConfigID = edc.Id;
            log.StudyID = edc.StudyID;
            log.ConfigName = edc.ConfigName!;
            log.Process = (ProcessType)process;
            log.LogDetails = message;
            log.ExceptionMessage = errorMsg;
            await _mediator.Send(new CreateHistoryLogsCommand(log));
        }
        private async Task<(MemoryStream memoryStream, string filename, bool isNewestMatchingFile)> FileDownLoadStream(SASAutomationConfig edc)
        {
            bool isNewestMatchingFile = false;
            string fileName = string.Empty;
            try
            {
                RemoteSystemSetting setting = new RemoteSystemSetting()
                {
                    Host = edc.SourceHostName!,
                    Port = edc.SourcePortNumber!.Value,
                    UserName = edc.SourceUserName!,
                    Password = edc.SourcePassword!,
                    Type = edc.SourceFileProtocol!.Value.ToString(),
                    Encryption = edc.SourceEncryption!.Value.ToString()
                };

                MemoryStream ms = new MemoryStream();
                IRemoteFileSystemContext remote;
                if (setting.Type == FileProtocol.FTP.ToString())
                {
                    remote = new FtpRemoteFileSystem(setting);
                }
                else
                {
                    remote = new SftpRemoteFileSystem(setting);
                }
                remote.Connect();
                bool isConnected = remote.IsConnected();
                if (isConnected)
                {
                    Console.WriteLine(MessagesConstants.SourceConnectedSuccessMessage(edc.SourceFileProtocol.ToString()!, edc.SourceHostName!.ToString(), edc.SourcePortNumber));
                    await LogMessageAsync(edc, ProcessType.SourceConnection, MessagesConstants.SourceConnectedSuccessMessage(edc.SourceFileProtocol.ToString()!, edc.SourceHostName!.ToString(), edc.SourcePortNumber), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                }

                if (!remote.DirectoryExists(edc.SourceFolderPath!))
                {
                    string Error = MessagesConstants.MatchingDirectoryNotFoundMessage(edc.SourceFolderPath!);
                    throw new Exception(Error);
                }
                var filedetail = remote.GetListingDirectory(edc.SourceFolderPath!, edc.SourceFileName!);
                if (filedetail != null)
                {
                    var isExistTransferred = _mediator.Send(new GetSASAutomationConfigByIdQuery(edc.Id)).Result;
                    fileName = filedetail.FileName!;
                    var sourceFileFullName = filedetail.FileFullName!;
                    if (isExistTransferred.FileName != filedetail.FileName)
                    {
                        Console.WriteLine(MessagesConstants.MatchingFileFoundMessage(filedetail.FileName!, edc.SourceFolderPath!));
                        await LogMessageAsync(edc, ProcessType.NewMatchinFileFound, MessagesConstants.MatchingFileFoundMessage(filedetail.FileName!, edc.SourceFolderPath!), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                        isNewestMatchingFile = true;
                        bool IsExistInSource = remote.FileExists(filedetail.FileFullName!);
                        if (isConnected && IsExistInSource)
                        {
                            ms = remote.DownloadFile(filedetail.FileFullName!);
                        }
                    }
                    else
                    {
                        isNewestMatchingFile = false;
                        Console.WriteLine(MessagesConstants.MatchingFileNotFoundMessage(edc.SourceFolderPath!));
                        await LogMessageAsync(edc, ProcessType.NewMatchinFileNotFound, MessagesConstants.MatchingFileNotFoundMessage(edc.SourceFolderPath!), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                    }
                }
                else
                {
                    Console.WriteLine(MessagesConstants.SourceFileNotFoundMessage(edc.SourceFolderPath!));
                    await LogMessageAsync(edc, ProcessType.SASAutomation, MessagesConstants.SourceFileNotFoundMessage(edc.SourceFolderPath!), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());

                }
                remote.Disconnect();
                remote.Dispose();
                return (ms, fileName, isNewestMatchingFile);
            }
            catch (Exception ex)
            {
                string Error = string.IsNullOrEmpty(ex.Message + ex.InnerException?.Message) ? MessagesConstants.UnknownError : ex.Message + ex.InnerException?.Message;
                Console.WriteLine("error occurred while downloading the File" + Error);
                await LogMessageAsync(edc, ProcessType.ErrorConnectingToSource, MessagesConstants.SourceConnectedFailureMessage(edc.SourceFileProtocol.ToString()!, edc.SourceHostName!, edc.SourcePortNumber!.Value, Error), Error, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                throw new Exception(MessagesConstants.SourceConnectedFailureMessage(edc.SourceFileProtocol.ToString()!, edc.SourceHostName!, edc.SourcePortNumber!.Value, Error));
            }
        }

        private void LogMessage(SASAutomationConfig edc, Enum process, string message, string? initiatedBy)
        {
            HistoryLog log = new HistoryLog();
            log.TimeStamp = DateTime.UtcNow;
            log.EDCConfigID = edc.Id;
            log.StudyID = edc.StudyID;
            log.Process = (ProcessType)process;
            log.ConfigName = edc?.ConfigName;
            log.LogDetails = message;
            _mediator.Send(new CreateHistoryLogsCommand(log));
        }

        private async Task PurgeLogMessage(int? days)
        {
            await _mediator.Send(new DeleteHistoryLogsCommand(days));
        }


        private async Task<bool> UnzipFileStream(SASAutomationConfig edc, MemoryStream ms, string filename, string remotezipPath)
        {
            bool isUnzipSuccess = false;

            try
            {
                RemoteSystemSetting setting = new RemoteSystemSetting()
                {
                    Host = edc.DestHostName!,
                    Port = edc.DestPortNumber!.Value,
                    UserName = edc.DestUserName!,
                    Password = edc.DestPassword!,
                    Type = edc.DestFileProtocol.ToString()!,
                    Encryption = edc.DestEncryption.ToString()!
                };


                IRemoteFileSystemContext remote;
                if (setting.Type == FileProtocol.FTP.ToString())
                {
                    remote = new FtpRemoteFileSystem(setting);
                }
                else
                {
                    remote = new SftpRemoteFileSystem(setting);
                }
                remote.Connect();
                bool isConnected = remote.IsConnected();
                if (isConnected)
                {
                    int unzippedfilesCount;
                    bool result = remote.UnZipFile(ms, remotezipPath, edc.SourceZipPassword, out unzippedfilesCount);
                    isUnzipSuccess = result;
                    if (result)
                    {
                        Console.WriteLine(MessagesConstants.UnzipingSuccessMessage(filename, edc.CurrentDestFolderPath == null ? "" : edc.CurrentDestFolderPath, unzippedfilesCount));
                        await LogMessageAsync(edc, ProcessType.FileUnzipSuccess, MessagesConstants.UnzipingSuccessMessage(filename, edc.CurrentDestFolderPath == null ? "" : edc.CurrentDestFolderPath, unzippedfilesCount), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                    }
                    else
                    {
                        throw new Exception(MessagesConstants.FileSizeErrorMessage());
                    }
                }
                remote.Disconnect();
                remote.Dispose();
                return isUnzipSuccess;
            }
            catch (Exception ex)
            {
                string Error = string.IsNullOrEmpty(ex.Message + ex.InnerException?.Message) ? MessagesConstants.UnknownError : ex.Message + ex.InnerException?.Message;
                Console.WriteLine(MessagesConstants.UnzipingFailureMessage(filename, edc.CurrentDestFolderPath == null ? "" : edc.CurrentDestFolderPath, Error));
                await LogMessageAsync(edc, ProcessType.ErrorUnzippingFile, MessagesConstants.UnzipingFailureMessage(filename, edc.CurrentDestFolderPath!, Error), Error, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                await _mediator.Send(new UpdateErrorInLastExecutionCommand(edc.Id, true));
                string ErrorMessage = string.Format("<b> For User:</b> EDCIS.WebJobs+<br/>" + "<b>" + "Study ID : " + "</b>" + edc.StudyID + "<br/>" + "<b>" + "Config Name : " + "</b>" + edc.ConfigName + "<br/>" + "<b>" + "Error Message : " + "</b>" + MessagesConstants.UnzipingFailureMessage(filename, edc.CurrentDestFolderPath!, Error));
                await _mediator.Send(new EmailSenderCommand(edc, ErrorMessage));
                return isUnzipSuccess;
            }
        }
        private async Task<bool> FileTransferUploadStream(SASAutomationConfig edc, MemoryStream ms, string fileName)
        {
            bool isSuccessfullyTransferred = false;
            string folderPath = string.Empty;
            try
            {
                RemoteSystemSetting setting = new RemoteSystemSetting()
                {
                    Host = edc.DestHostName!,
                    Port = edc.DestPortNumber!.Value,
                    UserName = edc.DestUserName!,
                    Password = edc.DestPassword!,
                    Type = edc.DestFileProtocol.ToString()!,
                    Encryption = edc.DestEncryption.ToString()!
                };
                IRemoteFileSystemContext remote;
                if (setting.Type == FileProtocol.FTP.ToString())
                {
                    remote = new FtpRemoteFileSystem(setting);
                }
                else
                {
                    remote = new SftpRemoteFileSystem(setting);
                }

                remote.Connect();
                bool isConnected = remote.IsConnected();
                string remoteArchiveFullDestinationFolderPath = edc.ArchiveDestFolderPath + fileName;
                string remoteCurrentFullDestinationFolderPath = edc.CurrentDestFolderPath + fileName;

                if (isConnected)
                {
                    await LogMessageAsync(edc, ProcessType.DestinationConnection, MessagesConstants.DestinationConnectedSuccessMessage(edc.DestFileProtocol.ToString()!, edc.DestHostName!.ToString(), edc.DestPortNumber!.Value), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                    if (!remote.DirectoryExists(edc.ArchiveDestFolderPath!))
                    {
                        folderPath = "Archive";
                        string Error = MessagesConstants.MatchingDirectoryNotFoundMessage(edc.ArchiveDestFolderPath!);
                        throw new Exception(Error);
                    }
                    try
                    {
                        folderPath = "Archive";
                        await LogMessageAsync(edc, ProcessType.FileTransfer, MessagesConstants.CopyToArchiveStartedMessage(fileName, edc.ArchiveDestFolderPath!), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                        bool result = remote.UploadFile(ms, remoteArchiveFullDestinationFolderPath);
                        isSuccessfullyTransferred = result;
                        if (result)
                        {
                            await LogMessageAsync(edc, ProcessType.FileCopied, MessagesConstants.CopyToArchiveSuccessMessage(fileName, edc.ArchiveDestFolderPath!), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                        }
                        else
                        {
                            throw new Exception(MessagesConstants.FileSizeErrorMessage());
                        }
                    }
                    catch (Exception ex)
                    {
                        isSuccessfullyTransferred = false;
                        string Error = string.IsNullOrEmpty(ex.Message + ex.InnerException?.Message) ? MessagesConstants.UnknownError : ex.Message + ex.InnerException?.Message;
                        //await LogMessageAsync(edc, ProcessType.FileTransfer, MessagesConstants.CopyToArchiveFailureMessage(fileName, edc.ArchiveDestFolderPath!, Error), Error);
                        throw new Exception(MessagesConstants.CopyToArchiveFailureMessage(fileName, edc.ArchiveDestFolderPath!, Error));
                    }
                }
                else
                {
                    Console.WriteLine("Error while connecting with Destination Server");
                    await LogMessageAsync(edc, ProcessType.ErrorConnectingToDestination, MessagesConstants.DestinationConnectedFailureMessage(edc.DestFileProtocol.ToString()!, edc.DestHostName!, edc.DestPortNumber!.Value, "Error while connecting with Destination Server"), "Error while connecting with Destination Server", SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                }

                if (isConnected)
                {
                    if (!remote.DirectoryExists(edc.CurrentDestFolderPath!))
                    {
                        folderPath = "Current";
                        string Error = MessagesConstants.MatchingDirectoryNotFoundMessage(edc.CurrentDestFolderPath!);
                        throw new Exception(Error);
                    }
                    var fileDetail = remote.GetPurgingFile(edc.CurrentDestFolderPath!);
                    var DirectoryDetail = remote.GetPurgingDirectory(edc.CurrentDestFolderPath!);
                    folderPath = "Current";
                    var deletedFiles = new List<string>();
                    try
                    {
                        if (fileDetail.Count > 0)
                        {
                            foreach (FileDetail file in fileDetail)
                            {
                                remote.DeleteFileIfExists(file.FileFullName!);
                            }
                        }
                        if (DirectoryDetail.Count > 0)
                        {
                            foreach (FileDetail file in DirectoryDetail.OrderByDescending(x => x.Depth))
                            {
                                bool isExist = remote.DirectoryExists(file.FileFullName!);
                                if (isExist)
                                {
                                    remote.DeleteDirectory(file.FileFullName!);
                                }
                            }
                        }
                        if (fileDetail.Count > 0 || DirectoryDetail.Count > 0)
                        {
                            await LogMessageAsync(edc, ProcessType.CurrentFolderCleaning, MessagesConstants.CleanedFolderSuccessMessage(edc.CurrentDestFolderPath!), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                        }

                    }
                    catch (Exception ex)
                    {
                        string Error = string.IsNullOrEmpty(ex.Message + ex.InnerException?.Message) ? MessagesConstants.UnknownError : ex.Message + ex.InnerException?.Message;
                        await LogMessageAsync(edc, ProcessType.ErrorCleaningCurrentFolder, MessagesConstants.CleanedFolderFailureMessage(edc.CurrentDestFolderPath!, Error), Error, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                        await _mediator.Send(new UpdateErrorInLastExecutionCommand(edc.Id, true));
                        string ErrorMessage = string.Format("<b>For User:</b> EDCIS.WebJobs" + "<br/>" + "<b>" + "Study ID : " + "</b>" + edc.StudyID + "<br/>" + "<b>" + "Config Name : " + "</b>" + edc.ConfigName + "<br/>" + "<b>" + "Error Message : " + "</b>" + MessagesConstants.CleanedFolderFailureMessage(edc.CurrentDestFolderPath!, Error));
                        await _mediator.Send(new EmailSenderCommand(edc, ErrorMessage));
                    }

                }
                remote.Disconnect();
                remote.Dispose();
                return (isSuccessfullyTransferred);
            }
            catch (Exception ex)
            {
                string Error = string.IsNullOrEmpty(ex.Message + ex.InnerException?.Message) ? MessagesConstants.UnknownError : ex.Message + ex.InnerException?.Message;
                if (folderPath == "Current")
                {
                    throw new Exception(MessagesConstants.CleanedFolderFailureMessage(edc.CurrentDestFolderPath!, Error));
                }
                else
                {
                    throw new Exception(MessagesConstants.CopyToArchiveFailureMessage(fileName, edc.ArchiveDestFolderPath!, Error));
                }
            }
        }

        private async Task<bool> NonUnzipFileTransfer(SASAutomationConfig edc, MemoryStream ms, string fileName)
        {
            bool isSuccessfullyTransferred = false;
            try
            {
                RemoteSystemSetting setting = new RemoteSystemSetting()
                {
                    Host = edc.DestHostName!,
                    Port = edc.DestPortNumber!.Value,
                    UserName = edc.DestUserName!,
                    Password = edc.DestPassword!,
                    Type = edc.DestFileProtocol.ToString()!,
                    Encryption = edc.DestEncryption.ToString()!
                };
                IRemoteFileSystemContext remote;
                if (setting.Type == FileProtocol.FTP.ToString())
                {
                    remote = new FtpRemoteFileSystem(setting);
                }
                else
                {
                    remote = new SftpRemoteFileSystem(setting);
                }

                remote.Connect();
                bool isConnected = remote.IsConnected();

                string remoteCurrentFullDestinationFolderPath = edc.CurrentDestFolderPath + fileName;

                if (isConnected)
                {
                    try
                    {
                        await LogMessageAsync(edc, ProcessType.FileTransfer, MessagesConstants.CopyToDestinationStratedMessage(fileName, edc.CurrentDestFolderPath!), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                        bool result = remote.UploadFile(ms, remoteCurrentFullDestinationFolderPath);
                        isSuccessfullyTransferred = result;
                        if (result)
                        {
                            await LogMessageAsync(edc, ProcessType.FileCopied, MessagesConstants.CopyToDestinationSuccessMessage(fileName, edc.CurrentDestFolderPath!), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                        }
                        else
                        {
                            throw new Exception(MessagesConstants.FileSizeErrorMessage());
                        }
                    }
                    catch (Exception ex)
                    {
                        string Error = string.IsNullOrEmpty(ex.Message + ex.InnerException?.Message) ? MessagesConstants.UnknownError : ex.Message + ex.InnerException?.Message;
                        isSuccessfullyTransferred = false;
                        await LogMessageAsync(edc, ProcessType.ErrorCopyingFile, MessagesConstants.CopyToDestinationFailureMessage(fileName, edc.CurrentDestFolderPath!, Error), Error, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                        throw new Exception(MessagesConstants.CopyToDestinationFailureMessage(fileName, edc.CurrentDestFolderPath!, Error));
                    }
                }
                else
                {
                    Console.WriteLine("Error while connecting with Destination Server");
                    await LogMessageAsync(edc, ProcessType.ErrorConnectingToDestination, MessagesConstants.DestinationConnectedFailureMessage(edc.DestFileProtocol.ToString()!, edc.DestHostName!, edc.DestPortNumber!.Value, "Error while connecting with Destination Server"), "Error while connecting with Destination Server", SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                }
                remote.Disconnect();
                remote.Dispose();
                return (isSuccessfullyTransferred);
            }
            catch (Exception ex)
            {
                string Error = string.IsNullOrEmpty(ex.Message + ex.InnerException?.Message) ? MessagesConstants.UnknownError : ex.Message + ex.InnerException?.Message;
                // await LogMessageAsync(edc, ProcessType.FileTransfer, MessagesConstants.CopyToDestinationFailureMessage(fileName, edc.CurrentDestFolderPath!, Error), Error);
                throw new Exception(MessagesConstants.CopyToDestinationFailureMessage(fileName, edc.CurrentDestFolderPath!, Error));
            }
        }
        private async Task DeleteSourceFile(SASAutomationConfig edc, string fileName)
        {
            try
            {
                RemoteSystemSetting setting = new RemoteSystemSetting()
                {
                    Host = edc.SourceHostName!,
                    Port = edc.SourcePortNumber!.Value,
                    UserName = edc.SourceUserName!,
                    Password = edc.SourcePassword!,
                    Type = edc.SourceFileProtocol.ToString()!,
                    Encryption = edc.SourceEncryption.ToString()!
                };

                MemoryStream ms = new MemoryStream();
                IRemoteFileSystemContext remote;
                if (setting.Type == FileProtocol.FTP.ToString())
                {
                    remote = new FtpRemoteFileSystem(setting);
                }
                else
                {
                    remote = new SftpRemoteFileSystem(setting);
                }
                remote.Connect();
                bool isConnected = remote.IsConnected();
                if (isConnected)
                {
                    if (!remote.DirectoryExists(edc.SourceFolderPath!))
                    {
                        string Error = MessagesConstants.MatchingDirectoryNotFoundMessage(edc.SourceFolderPath!);
                        throw new Exception(Error);
                    }
                }
                remote.DeleteFileIfExists(edc.SourceFolderPath! + fileName);
                await LogMessageAsync(edc, ProcessType.SourceDeletion, MessagesConstants.SourceFileDeletedSuccessMessage(fileName, edc.SourceFolderPath!), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                remote.Disconnect();
                remote.Dispose();
            }

            catch (Exception ex)
            {
                string Error = string.IsNullOrEmpty(ex.Message + ex.InnerException?.Message) ? MessagesConstants.UnknownError : ex.Message + ex.InnerException?.Message;
                await LogMessageAsync(edc, ProcessType.ErrorDeletingSourceFile, MessagesConstants.SourceFileDeletedFailureMessage(fileName, edc.SourceFolderPath!, Error), Error, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                string ErrorMessage = string.Format("<b> For User:</b> EDCIS.WebJobs" + "<br/>" + "<b>" + "Study ID : " + "</b>" + edc.StudyID + "<br/>" + "<b>" + "Config Name : " + "</b>" + edc.ConfigName + "<br/>" + "<b>" + "Error Message : " + "</b>" + MessagesConstants.SourceFileDeletedFailureMessage(fileName, edc.SourceFolderPath!, Error));
                await _mediator.Send(new EmailSenderCommand(edc, ErrorMessage));
            }
        }

        private async Task PurgeDestArchiveFolder(SASAutomationConfig edc, int? purgeDays)
        {
            try
            {
                RemoteSystemSetting setting = new RemoteSystemSetting()
                {
                    Host = edc.DestHostName!,
                    Port = edc.DestPortNumber!.Value,        /*ftp:21, sftp:22*/
                    UserName = edc.DestUserName!,
                    Password = edc.DestPassword!,
                    Type = edc.DestFileProtocol!.Value.ToString(),
                    Encryption = edc.DestEncryption!.Value.ToString()
                };

                MemoryStream ms = new MemoryStream();
                IRemoteFileSystemContext remote;
                if (setting.Type == FileProtocol.FTP.ToString())
                {
                    remote = new FtpRemoteFileSystem(setting);
                }
                else
                {
                    remote = new SftpRemoteFileSystem(setting);
                }
                remote.Connect();
                bool isConnected = remote.IsConnected();
                if (isConnected)
                {
                    if (!remote.DirectoryExists(edc.ArchiveDestFolderPath!))
                    {
                        string Error = MessagesConstants.MatchingDirectoryNotFoundMessage(edc.ArchiveDestFolderPath!);
                        throw new Exception(Error);
                    }
                }
                // get a recursive listing of the files & folders in a specific folder
                var fileDetail = remote.GetPurgingFile(edc.ArchiveDestFolderPath!);
                var DirectoryDetail = remote.GetPurgingDirectory(edc.ArchiveDestFolderPath!);

                var deletedFiles = new List<string>();

                if (fileDetail != null)
                {
                    foreach (FileDetail file in fileDetail)
                    {
                        if (file.FileLastWriteTimeUtc <= DateTime.Now.AddDays((purgeDays == null ? 0 : -purgeDays.Value)))
                        {
                            Console.WriteLine(ProcessType.PurgeDestArchive + MessagesConstants.DestinationArchivePurgeFolderStartedMessage(edc.ArchiveDestFolderPath!));
                            await LogMessageAsync(edc, ProcessType.PurgeDestArchive, MessagesConstants.DestinationArchivePurgeFolderStartedMessage(edc.ArchiveDestFolderPath!), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                            remote.DeleteFileIfExists(edc.ArchiveDestFolderPath! + file!.FileName!);
                            Console.WriteLine(ProcessType.PurgeDestArchiveSuccess + MessagesConstants.DestinationArchivePurgeFolderSuccessMessage(edc.ArchiveDestFolderPath!));
                            await LogMessageAsync(edc, ProcessType.PurgeDestArchiveSuccess, MessagesConstants.DestinationArchivePurgeFolderSuccessMessage(edc.ArchiveDestFolderPath!), string.Empty, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                        }
                    }
                }
                else
                {
                    Console.WriteLine(ProcessType.PurgeDestArchive + "- " + "No file found for Purging");
                }
                remote.Disconnect();
                remote.Dispose();
            }
            catch (Exception ex)
            {
                string Error = string.IsNullOrEmpty(ex.Message + ex.InnerException?.Message) ? MessagesConstants.UnknownError : ex.Message + ex.InnerException?.Message;
                Console.WriteLine(ProcessType.ErrorPurgingDestArchive + MessagesConstants.DestinationArchivePurgeFolderFailureMessage(edc.ArchiveDestFolderPath!, Error));
                await LogMessageAsync(edc, ProcessType.ErrorPurgingDestArchive, MessagesConstants.DestinationArchivePurgeFolderFailureMessage(edc.ArchiveDestFolderPath!, Error), Error, SD.UserId == null ? "Schedule" : SD.UserId.ToString());
                string ErrorMessage = string.Format("<b> For User:</b> EDCIS.WebJobs" + "<br/>" + "<b>" + "Study ID : " + "</b>" + edc.StudyID + "<br/>" + "<b>" + "Config Name : " + "</b>" + edc.ConfigName + "<br/>" + "<b>" + "Error Message : " + "</b>" + MessagesConstants.DestinationArchivePurgeFolderFailureMessage(edc.ArchiveDestFolderPath!, Error));
                await _mediator.Send(new EmailSenderCommand(edc, ErrorMessage));
            }
        }
    }
    public class SourceDestFTPSite
    {
        public string SourceFTPSite { get; set; }
        public string DestFTPSite { get; set; }
        public SourceDestFTPSite(string sourceFTPSite, string destFTPSite)
        {
            SourceFTPSite = sourceFTPSite;
            DestFTPSite = destFTPSite;
        }
        public override bool Equals(object obj)
        {
            if (obj is SourceDestFTPSite other)
            {
                return (SourceFTPSite == other.SourceFTPSite && DestFTPSite == other.DestFTPSite) ||
                       (SourceFTPSite == other.DestFTPSite && DestFTPSite == other.SourceFTPSite);
            }
            return false;
        }
        public override int GetHashCode()
        {
            int hashFirst = SourceFTPSite?.GetHashCode() ?? 0;
            int hashSecond = DestFTPSite?.GetHashCode() ?? 0;
            return hashFirst ^ hashSecond;
        }
    }
}
