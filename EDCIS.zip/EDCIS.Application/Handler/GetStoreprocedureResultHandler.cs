﻿using Azure;
using EDCIS.Application.Persistence;
using EDCIS.Domain.Entities;
using System.Diagnostics;

namespace EDCIS.Application.Handler
{
    public record GetAutomationReportQuery(DateTime? fromDate, DateTime? toDate, long? studyId, string? initiatedBy, bool groupByStudy, bool groupByInitiated) : IRequest<List<AutomationReportResult>>;
    public class GetStoreprocedureResultHandler : IRequestHandler<GetAutomationReportQuery, List<AutomationReportResult>>
    {
        private readonly IAsyncRepository<AutomationReportResult> _automationReportRepository;
      
        public GetStoreprocedureResultHandler(IAsyncRepository<AutomationReportResult> automationReportRepository)
        {
          _automationReportRepository = automationReportRepository;          
        }
   public async Task<List<AutomationReportResult>> Handle(GetAutomationReportQuery request, CancellationToken cancellationToken)
        {
            try
            {
                List<AutomationReportResult> logDetails;

                logDetails = await _automationReportRepository.GetRowSQLAsync(request.fromDate, request.toDate, request.studyId, request.initiatedBy, request.groupByStudy, request.groupByInitiated);
                return logDetails!;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
