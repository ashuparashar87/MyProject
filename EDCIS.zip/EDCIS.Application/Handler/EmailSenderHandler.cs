﻿using EDCIS.Application.ClientInfrastructure.Dtos;
using EDCIS.Application.Persistence;
using EDCIS.Application.Utility;
using EDCIS.Application.Utility.Constant;
using EDCIS.Domain.Entities;
using EDCIS.Domain.Enum;
using Microsoft.Identity.Client;
using MimeKit;
using System.Diagnostics;

namespace EDCIS.Application.Handler
{

    public record  EmailSenderCommand(SASAutomationConfig edc,string message) : IRequest<Unit>;

    public class EmailSenderCommandHandler : IRequestHandler<EmailSenderCommand, Unit>
    {
      
        private readonly IAsyncRepository<HistoryLog> _historyLogRepository;
        private readonly EmailConfiguration _emailConfig;

        public EmailSenderCommandHandler(IAsyncRepository<HistoryLog> historyLogRepository, EmailConfiguration emailConfig)
        {
            _historyLogRepository = historyLogRepository;
            _emailConfig = emailConfig;
        }
      
        public async Task<Unit> Handle(EmailSenderCommand request, CancellationToken cancellationToken)
        {
            try
            {
                string? addRecipients = SD.Error_ToEmail?.Replace(" ", "");
                string? emailToSend = string.Empty;

                if (!string.IsNullOrEmpty(request.edc.ErrorEmailRecipients))
                {
                    emailToSend = addRecipients + ";" + request.edc.ErrorEmailRecipients;
                }
                else {
                    emailToSend = addRecipients;
                }

                if (emailToSend != null)
                {
                    var emailHandler = new EmailHandler();
                    string subject = SD.CriticalErrorEmail_Subject!;
                    string body = SD.CriticalErrorEmail_BodyTemplate!;
                    var mailMessage = emailHandler.CreateEmailMessage(request.message, emailToSend, subject, body, _emailConfig);
                    await emailHandler.SendAsync(mailMessage);
                }
            }
            catch (Exception ex)
            {
                string errorEmail = MessagesConstants.EmailFailureMessage(ex.Message + ex.InnerException?.Message);
                await LogMessageAsync(request.edc, ProcessType.SASAutomation, errorEmail, errorEmail,SD.UserId);
            }
            return Unit.Value;

        }

        private async Task LogMessageAsync(SASAutomationConfig edc, Enum process, string message, string errorMsg,string? initiatedBy)
        {
            HistoryLog log = new HistoryLog();
            log.TimeStamp = DateTime.UtcNow;
            log.EDCConfigID = edc.Id;
            log.StudyID = edc.StudyID;
            log.ConfigName = edc.ConfigName!;
            log.Process = (ProcessType)process;
            log.LogDetails = message;
            log.ExceptionMessage = errorMsg;
            log.InitiatedBy = initiatedBy==null ? "Schedule" : initiatedBy.ToString();
            await _historyLogRepository.AddAsync(log);
        }
    }

    public record UIEmailSenderCommand(string message) : IRequest<Unit>;


    public class UIEmailSenderCommandHandler : IRequestHandler<UIEmailSenderCommand, Unit>
    {
        private readonly EmailConfiguration _emailConfig;
        public List<MailboxAddress>? ToAddressList { get; set; }
        public UIEmailSenderCommandHandler(EmailConfiguration emailConfig)
        {
            _emailConfig = emailConfig;
        }

        public async Task<Unit> Handle(UIEmailSenderCommand request, CancellationToken cancellationToken)
        {
            try
            {
                string? emailToSend = SD.Error_ToEmail?.Replace(" ", "");
                if (emailToSend != null)
                {
                    var emailHandler = new EmailHandler();
                    string subject = SD.CriticalErrorEmail_Subject!;
                    string body = SD.CriticalErrorEmail_BodyTemplate!;
                    var mailMessage = emailHandler.CreateEmailMessage(request.message, emailToSend, subject, body, _emailConfig);
                    await emailHandler.SendAsync(mailMessage);
                }
            }
            catch (Exception)
            {
            }
            return Unit.Value;
        }
    }


    public record SuccessEmailSenderCommand(SASAutomationConfig edc, string message) : IRequest<Unit>;

    public class SuccessEmailSenderCommandHandler : IRequestHandler<SuccessEmailSenderCommand, Unit>
    {

        private readonly IAsyncRepository<HistoryLog> _historyLogRepository;
        private readonly EmailConfiguration _emailConfig;

        public SuccessEmailSenderCommandHandler(IAsyncRepository<HistoryLog> historyLogRepository, EmailConfiguration emailConfig)
        {
            _historyLogRepository = historyLogRepository;
            _emailConfig = emailConfig;
        }

        public async Task<Unit> Handle(SuccessEmailSenderCommand request, CancellationToken cancellationToken)
        {
            try
            {
                string? emailToSend = string.Empty;

                if (!string.IsNullOrEmpty(request.edc.SuccessEmailRecipients))
                {
                    emailToSend =  request.edc.SuccessEmailRecipients;
                }

                if (emailToSend != null)
                {
                    var emailHandler = new EmailHandler();
                    string subject = SD.SuccessEmail_BodyTemplate!;
                    string body = SD.SuccessEmail_BodyTemplate!;
                    var mailMessage = emailHandler.CreateEmailMessage(request.message, emailToSend, subject,body, _emailConfig);
                    await emailHandler.SendAsync(mailMessage);
                }
            }
            catch (Exception ex)
            {
                string errorEmail = MessagesConstants.EmailFailureMessage(ex.Message + ex.InnerException?.Message);
                await LogMessageAsync(request.edc, ProcessType.SASAutomation, errorEmail, errorEmail, SD.UserId);
            }
            return Unit.Value;

        }
        private async Task LogMessageAsync(SASAutomationConfig edc, Enum process, string message, string errorMsg, string? initiatedBy)
        {
            HistoryLog log = new HistoryLog();
            log.TimeStamp = DateTime.UtcNow;
            log.EDCConfigID = edc.Id;
            log.StudyID = edc.StudyID;
            log.ConfigName = edc.ConfigName!;
            log.Process = (ProcessType)process;
            log.LogDetails = message;
            log.ExceptionMessage = errorMsg;
            log.InitiatedBy = initiatedBy == null ? "Schedule" : initiatedBy.ToString();
            await _historyLogRepository.AddAsync(log);
        }
    }

    public record WebJonAlreadyRunningSenderCommand(string message) : IRequest<Unit>;


    public class WebJonAlreadyRunningSenderCommandHandler : IRequestHandler<WebJonAlreadyRunningSenderCommand, Unit>
    {
        private readonly EmailConfiguration _emailConfig;
        public List<MailboxAddress>? ToAddressList { get; set; }
        public WebJonAlreadyRunningSenderCommandHandler(EmailConfiguration emailConfig)
        {
            _emailConfig = emailConfig;
        }

        public async Task<Unit> Handle(WebJonAlreadyRunningSenderCommand request, CancellationToken cancellationToken)
        {
            try
            {
                string? emailToSend = SD.WebJobAlreadyRunning_ToEmail?.Replace(" ", "");
                if (emailToSend != null)
                {
                    var emailHandler = new EmailHandler();
                    string subject = SD.WebJobAlreadyRunning_Subject!;
                    string body = SD.WebJobAlreadyRunning_BodyTemplate!;
                    string currentDateText = DateTime.Now.ToString("dd-MMM-yyyy HH:mm");
                    string updatedbody= body.Replace("{dd-MMM-yyy HH:mm}", currentDateText);
                    var mailMessage = emailHandler.CreateEmailMessage(request.message, emailToSend,subject, updatedbody, _emailConfig);
                    await emailHandler.SendAsync(mailMessage);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return Unit.Value;
        }
    }

    public class EmailHandler
    {
        public List<MailboxAddress>? ToAddressList { get; set; }
       
        public MimeMessage CreateEmailMessage(string message, string emailToSend, string subject,string body, EmailConfiguration _emailConfig)
        {
            string[] emailToSends = emailToSend.Split(';');
            ToAddressList = new List<MailboxAddress>();

            if (emailToSends != null)
            {
                ToAddressList.AddRange(emailToSends.Where(x => x != "").Select(x => new MailboxAddress("email", x)));
            }

            var emailMessage = new MimeMessage();
            emailMessage.From.Add(new MailboxAddress("email", _emailConfig.From));
            emailMessage.To.AddRange(ToAddressList);
            var env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            if (Debugger.IsAttached)
            {
                emailMessage.Subject = env == "Production" ? subject : "Local: " + subject;
            }
            else
            {
                emailMessage.Subject = env == "Production" ? subject : env?.ToUpper() + ": " + subject;
            }           
            emailMessage.Body = new TextPart(MimeKit.Text.TextFormat.Html) { Text = body + "<br/>" + message };
            return emailMessage;
        }

        public async Task SendAsync(MimeMessage mailMessage)
        {
            var scopes = new string[] { SD.OfficeURL };
            var confidentialClientApp = ConfidentialClientApplicationBuilder.Create(SD.SharePointClientId)
                .WithAuthority(AzureCloudInstance.AzurePublic, SD.SharePointTenantId)
                .WithCertificate(AzureKeyVault.GetKeyVaultCertificate())
                .Build();
            Microsoft.Identity.Client.AuthenticationResult tokenResult = await confidentialClientApp
                .AcquireTokenForClient(scopes)
                .ExecuteAsync();
            var micToken = tokenResult.AccessToken;
            var oauth2 = new MailKit.Security.SaslMechanismOAuth2(SD.EmailUsername, micToken);
            using (var client = new MailKit.Net.Smtp.SmtpClient())
            {
                try
                {
                    await client.ConnectAsync(SD.EmailSmtpServer, Convert.ToInt32(SD.EmailPort), false);
                    await client.AuthenticateAsync(oauth2);
                    await client.SendAsync(mailMessage);

                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    await client.DisconnectAsync(true);
                    client.Dispose();
                }
            }
        }


        //public async Task SendAsync(MimeMessage mailMessage, EmailConfiguration _emailConfig)
        //{
        //    using (var client = new SmtpClient())
        //    {
        //        try
        //        {
        //            await client.ConnectAsync(_emailConfig.SmtpServer, _emailConfig.Port, false);
        //            client.AuthenticationMechanisms.Remove("XOAUTH2");
        //            await client.AuthenticateAsync(_emailConfig.UserName, _emailConfig.Password);
        //            await client.SendAsync(mailMessage);
        //        }
        //        catch (Exception)
        //        {
        //        }
        //        finally
        //        {
        //            client.Disconnect(true);
        //            client.Dispose();
        //        }
        //    }
        //}

    }
}

