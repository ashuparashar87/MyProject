﻿using EDCIS.Application.Persistence;
using EDCIS.Domain.Entities;

namespace EDCIS.Application.Handler
{
    public record GetEDCSettingQuery() : IRequest<List<EDCToSASConfig>>;
    public class GetEDCSettingQueryHandler : IRequestHandler<GetEDCSettingQuery, List<EDCToSASConfig>>
    {
        private readonly IAsyncRepository<EDCToSASConfig> _EDCToSASConfigRepository;

        public GetEDCSettingQueryHandler(IAsyncRepository<EDCToSASConfig> EDCToSASConfigRepository)
        {
            _EDCToSASConfigRepository = EDCToSASConfigRepository;
        }

        public async Task<List<EDCToSASConfig>> Handle(GetEDCSettingQuery request, CancellationToken cancellationToken)
        {
            var edcDetails = await _EDCToSASConfigRepository.GetAllAsync();
            return edcDetails.ToList();
        }
    }
}
