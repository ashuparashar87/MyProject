﻿using EDCIS.Application.Persistence;
using EDCIS.Domain.Entities;

namespace EDCIS.Application.Handler
{
    public record CreateEDCToSASConfigCommand(EDCToSASConfig model) : IRequest<EDCToSASConfig>;
    public class CreateEDCToSASConfigCommandHandler : IRequestHandler<CreateEDCToSASConfigCommand, EDCToSASConfig>
    {
        private readonly IAsyncRepository<EDCToSASConfig> _EDCToSASConfigRepository;
        public CreateEDCToSASConfigCommandHandler(IAsyncRepository<EDCToSASConfig> EDCToSASConfigRepository)
        {
            _EDCToSASConfigRepository = EDCToSASConfigRepository;
        }
        public async Task<EDCToSASConfig> Handle(CreateEDCToSASConfigCommand request, CancellationToken cancellationToken)
        {
            var exsistRecord = (await _EDCToSASConfigRepository.GetAllAsync()).FirstOrDefault();
            if (exsistRecord != null)
            {
                exsistRecord.DestArchivePurgePeriod = request.model.DestArchivePurgePeriod;
                exsistRecord.HistoryPurgePeriod = request.model.HistoryPurgePeriod;
                exsistRecord.SupportEmail = request.model.SupportEmail;
                exsistRecord.IsAutomationActive = request.model.IsAutomationActive;
                await _EDCToSASConfigRepository.UpdateAsync(exsistRecord);
                return (await _EDCToSASConfigRepository.GetAllAsync()).FirstOrDefault()!;
            }
            else
            {
                return await _EDCToSASConfigRepository.AddAsync(request.model);
            }
        }
    }
}
