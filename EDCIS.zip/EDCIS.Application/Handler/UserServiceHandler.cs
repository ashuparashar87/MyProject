﻿using Azure.Messaging;
using EDCIS.Application.ClientInfrastructure.Dtos;
using EDCIS.Application.Utility;
using EDCIS.Application.Utility.Constant;
using EDCIS.Domain;
using EDCIS.Domain.Entities;
using EDCIS.Domain.Enum;
using System.ComponentModel;
using System.Security.Claims;
using static EDCIS.Application.Utility.Constant.MessagesConstants;

namespace EDCIS.Application.Handler
{

    public class UserServiceHandler
    {
        private readonly IMediator _mediator;

        public UserServiceHandler(IMediator mediator)
        {
            _mediator = mediator;
        }
        public async Task<List<Claim>?> AddUser(List<Claim>? claims, List<AdGroupConfig> groups)
        {
            var emailClaim = claims?.First(c => c.Type == ClaimTypes.Email);
            var userId = emailClaim?.Value;
            string role = string.Empty;
            var roles = new List<RoleList>();
            var resources = await _mediator.Send(new GetResourceListCommandQuery());
            var appUsers = resources.Where(x => x.EmailAddress == userId && x.IsActive == true);
            var existingUser = appUsers.SingleOrDefault();
            foreach (var AdRole in groups)
            {
                {
                    RoleList roleList = new RoleList();
                    if (AdRole.GroupName == SD.Admin)
                    {
                        role = nameof(ResourceRole.Admin);
                        roleList.Role = role;
                        roleList.Precedence = 1;
                        roles.Add(roleList);
                    }
                    else if (AdRole.GroupName == SD.ITAdmin)
                    {
                        role = nameof(ResourceRole.ITAdmin);
                        roleList.Role = role;
                        roleList.Precedence = 2;
                        roles.Add(roleList);
                    }
                    else if (AdRole.GroupName == SD.DataManager)
                    {
                        role = nameof(ResourceRole.DataManager);
                        roleList.Role = role;
                        roleList.Precedence = 3;
                        roles.Add(roleList);
                    }
                    else if (AdRole.GroupName == SD.Statistician)
                    {
                        role = nameof(ResourceRole.Statistician);
                        roleList.Role = role;
                        roleList.Precedence = 4;
                        roles.Add(roleList);
                    }
                    else if (AdRole.GroupName == SD.ReadOnly)
                    {
                        role = nameof(ResourceRole.ReadOnly);
                        roleList.Role = role;
                        roleList.Precedence = 5;
                        roles.Add(roleList);
                    }
                }
                var userRole = roles.OrderBy(p => p.Precedence).FirstOrDefault();

                if (userRole != null && !string.IsNullOrEmpty(userRole.Role))
                {
                    if (!Enum.TryParse<ResourceRole>(role, out ResourceRole appUserRole))
                    {
                        throw new InvalidEnumArgumentException(string.Format("Enum value {0} doesn't exist in EDCIS  Application.", appUserRole));

                    }

                    var appRole = (ResourceRole)Enum.Parse(typeof(ResourceRole), role);
                    if (existingUser != null)
                    {
                        existingUser.LastLoginAt = DateTime.UtcNow;
                        existingUser.IsActive = true;
                        if (existingUser.Role != appRole)
                        {
                            existingUser.Role = appRole;
                        }
                        claims?.Add(new Claim(ClaimTypes.Role, existingUser.Role.ToString()));
                        await _mediator.Send(new UpdateResourceCommand(existingUser));
                    }
                    else
                    {
                        var resource = new Resource();
                        resource.EmailAddress = userId;
                        resource.Role = appRole;
                        claims?.Add(new Claim(ClaimTypes.Role, appRole.ToString()));
                        resource.IsActive = true;
                        resource.LastLoginAt = DateTime.UtcNow;
                        resource.CreatedDate = DateTime.UtcNow;
                        resource.CreatedBy = SD.UserId ?? MessagesConstants.SystemUserEmail;
                        resource.FirstName = claims?.GetClaim("name");
                        await _mediator.Send(new CreateResourceCommand(resource));
                    }
                }
            }
            return claims;
        }
    }
}
