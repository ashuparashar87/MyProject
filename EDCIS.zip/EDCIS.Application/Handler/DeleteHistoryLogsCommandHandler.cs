﻿using EDCIS.Application.Persistence;
using EDCIS.Domain.Entities;

namespace EDCIS.Application.Handler
{
    public record DeleteHistoryLogsCommand(int? days) : IRequest<Unit>;
    public class DeleteHistoryLogsCommandHandler : IRequestHandler<DeleteHistoryLogsCommand, Unit>
    {
        private readonly IAsyncRepository<HistoryLog> _historyLogRepository;
        public DeleteHistoryLogsCommandHandler(IAsyncRepository<HistoryLog> historyLogRepository)
        {
            _historyLogRepository = historyLogRepository;
        }
        public async Task<Unit> Handle(DeleteHistoryLogsCommand request, CancellationToken cancellationToken)
        {
            if (request.days.HasValue)
            {
                var logDetails = await _historyLogRepository.GetAsync(x => x.TimeStamp <= DateTime.Now.AddDays(-request.days.Value));
                foreach (var logDetail in logDetails)
                {
                    await _historyLogRepository.DeleteAsync(logDetail);
                }
            }
            return Unit.Value;
        }
    }

    public record GetDeleteHistoryLogsCommand(int? days) : IRequest<List<HistoryLog>>;
    public class GetDeleteHistoryLogsCommandHandler : IRequestHandler<GetDeleteHistoryLogsCommand, List<HistoryLog>>
    {
        private readonly IAsyncRepository<HistoryLog> _historyLogRepository;
        public GetDeleteHistoryLogsCommandHandler(IAsyncRepository<HistoryLog> historyLogRepository)
        {
            _historyLogRepository = historyLogRepository;
        }
        public async Task<List<HistoryLog>> Handle(GetDeleteHistoryLogsCommand request, CancellationToken cancellationToken)
        {
            List<HistoryLog> logDetails=new List<HistoryLog>();
            if (request.days.HasValue)
            {
                logDetails = (await _historyLogRepository.GetAsync(x => x.TimeStamp <= DateTime.Now.AddDays(-request.days.Value))).ToList();
            }
            return logDetails;
        }
    }
}
