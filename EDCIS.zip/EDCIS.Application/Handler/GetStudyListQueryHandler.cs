﻿using EDCIS.Application.Persistence;
using EDCIS.Domain.Entities;
using EDCIS.Domain.Enum;

namespace EDCIS.Application.Handler
{
    public class GetStudyListCommandQuery : IRequest<List<StudyListVm>>
    {
    }
    public class GetStudyListQueryHandler : IRequestHandler<GetStudyListCommandQuery, List<StudyListVm>>
    {
        private readonly IAsyncCTMS_RDBRepository<EDCISStudyView> _studyRepository;
        private readonly IAsyncRepository<SASAutomationConfig> _EDCSourceRepository;

        public GetStudyListQueryHandler(IAsyncCTMS_RDBRepository<EDCISStudyView> studyRepository,
            IAsyncRepository<SASAutomationConfig> EDCSourceRepository)
        {
            _studyRepository = studyRepository;
            _EDCSourceRepository = EDCSourceRepository;
        }

        public async Task<List<StudyListVm>> Handle(GetStudyListCommandQuery request, CancellationToken cancellationToken)
        {

            var studies = (await _studyRepository.GetAllAsync()).OrderBy(x => x.StudyName).ToList();

            var edcDetails = (await _EDCSourceRepository.GetAllAsync()).GroupBy(s => s.StudyID)
                                  .Select(o => o.FirstOrDefault());

            var response = studies?.GroupJoin(edcDetails, x => x.StudyID, y => y?.StudyID,
                 (x, y) => new { x, y = y.DefaultIfEmpty() })
                .SelectMany(z => z.y.Select(y => new StudyListVm()
                {
                    StudyID = z.x.StudyID.ToString(),
                    StudyName = z?.x?.StudyName,
                    ProtocolNumber = z?.x?.ProtocolNumber,
                    StudyStatus = z?.x?.StudyStatus,
                    SponsorName = z?.x?.SponsorName,
                    TherapeuticArea = z?.x?.TherapeuticArea,
                    Indication = z?.x?.Indication,
                    SASAutomation = y == null ? "NO" : "Yes",
                    HasError = y == null?false: (y.IsEDCActive == true && y.LastError != null)
                })).ToList();
            return response!;
        }
    }

    public record GetTitleCommandQuery(long? studyId = null) :IRequest<TitleDetails>;
   
    public class GetTitleCommandHandler : IRequestHandler<GetTitleCommandQuery, TitleDetails>
    {
        private readonly IAsyncCTMS_RDBRepository<EDCISStudyView> _studyRepository;

        public GetTitleCommandHandler(IAsyncCTMS_RDBRepository<EDCISStudyView> studyRepository)
        {
            _studyRepository = studyRepository;
        }

        public async Task<TitleDetails> Handle(GetTitleCommandQuery request, CancellationToken cancellationToken)
        {

            var studies = (await _studyRepository.GetAsync(x=>x.StudyID== request.studyId)).ToList();
            var response = studies.Select(x => new TitleDetails()
                {
                    StudyName = x.StudyName,
                    ProtocolNumber = x.ProtocolNumber,
                    SponsorName = x.SponsorName,
                    StudyStatus= x.StudyStatus
                });
            return response.FirstOrDefault()!;

            
        }
    }
}
