﻿using EDCIS.Application.Persistence;
using EDCIS.Application.Utility;
using EDCIS.Domain.Entities;

namespace EDCIS.Application.Handler
{
    public record GetSASAutomationConfigByIdQuery(int id) : IRequest<SASAutomationConfig>;
    public class GetSASAutomationConfigByIdQueryHandler : IRequestHandler<GetSASAutomationConfigByIdQuery, SASAutomationConfig>
    {
        private readonly IAsyncRepository<SASAutomationConfig> _SASAutomationConfigRepository;
        public GetSASAutomationConfigByIdQueryHandler(IAsyncRepository<SASAutomationConfig> SASAutomationConfigRepository, IAsyncCTMS_RDBRepository<EDCISStudyView> studyRepository)
        {
            _SASAutomationConfigRepository = SASAutomationConfigRepository;
        }

        public async Task<SASAutomationConfig> Handle(GetSASAutomationConfigByIdQuery request, CancellationToken cancellationToken)
        {
            var edcDetails = (await _SASAutomationConfigRepository.GetByIdAsync(request.id));
            return edcDetails!;
        }
    }
    public record GetSASAutomationConfigByNameQuery(string Name) : IRequest<SASAutomationConfig>;
    public class GetSASAutomationConfigByNameQueryHandler : IRequestHandler<GetSASAutomationConfigByNameQuery, SASAutomationConfig>
    {
        private readonly IAsyncRepository<SASAutomationConfig> _SASAutomationConfigRepository;
        public GetSASAutomationConfigByNameQueryHandler(IAsyncRepository<SASAutomationConfig> SASAutomationConfigRepository, IAsyncCTMS_RDBRepository<EDCISStudyView> studyRepository)
        {
            _SASAutomationConfigRepository = SASAutomationConfigRepository;
        }

        public async Task<SASAutomationConfig> Handle(GetSASAutomationConfigByNameQuery request, CancellationToken cancellationToken)
        {
            var edcDetails = (await _SASAutomationConfigRepository.GetAllAsync()).Where(x => x.ConfigName == request.Name).FirstOrDefault();
            return edcDetails!;
        }
    }
    public record GetSASAutomationConfigCloneQuery(int id) : IRequest<SASAutomationConfig>;
    public class GetSASAutomationConfigCloneQueryHandler : IRequestHandler<GetSASAutomationConfigCloneQuery, SASAutomationConfig>
    {
        private readonly IAsyncRepository<SASAutomationConfig> _SASAutomationConfigRepository;
        public GetSASAutomationConfigCloneQueryHandler(IAsyncRepository<SASAutomationConfig> SASAutomationConfigRepository, IAsyncCTMS_RDBRepository<EDCISStudyView> studyRepository)
        {
            _SASAutomationConfigRepository = SASAutomationConfigRepository;
        }

        public async Task<SASAutomationConfig> Handle(GetSASAutomationConfigCloneQuery request, CancellationToken cancellationToken)
        {
            var edcDetails = (await _SASAutomationConfigRepository.GetAsync(x => x.Id == request.id));
            return edcDetails.SingleOrDefault()!;
        }
    }

    public record GetSASAutomationConfigQuery(long? configId = null) : IRequest<List<SASAutomationConfig>>;
    public class GetSASAutomationConfigQueryHandler : IRequestHandler<GetSASAutomationConfigQuery, List<SASAutomationConfig>>
    {
        private readonly IAsyncRepository<SASAutomationConfig> _SASAutomationConfigRepository;
        private readonly IAsyncCTMS_RDBRepository<EDCISStudyView> _studyRepository;

        public GetSASAutomationConfigQueryHandler(IAsyncRepository<SASAutomationConfig> SASAutomationConfigRepository, IAsyncCTMS_RDBRepository<EDCISStudyView> studyRepository)
        {
            _SASAutomationConfigRepository = SASAutomationConfigRepository;
            _studyRepository = studyRepository;
        }

        public async Task<List<SASAutomationConfig>> Handle(GetSASAutomationConfigQuery request, CancellationToken cancellationToken)
        {
            IReadOnlyList<SASAutomationConfig>? edcDetails;
            if (request.configId != null && request.configId != 0)
            {
                edcDetails = await _SASAutomationConfigRepository.GetAsync(x => x.Id == request.configId );
            }
            else
            {
                edcDetails = await _SASAutomationConfigRepository.GetAsync((x => (x.TransferDate == null || x.TransferDate < DateTime.Today)));
            }

            return edcDetails.ToList();
        }

    }
    public record GetSASAutomationConfigByStudyIdQuery(long studyId) : IRequest<List<SASAutomationConfig>>;
    public class GetSASAutomationConfigByStudyIdQueryHandler : IRequestHandler<GetSASAutomationConfigByStudyIdQuery, List<SASAutomationConfig>>
    {
        private readonly IAsyncRepository<SASAutomationConfig> _SASAutomationConfigRepository;

        public GetSASAutomationConfigByStudyIdQueryHandler(IAsyncRepository<SASAutomationConfig> SASAutomationConfigRepository)
        {
            _SASAutomationConfigRepository = SASAutomationConfigRepository;
    }

        public async Task<List<SASAutomationConfig>> Handle(GetSASAutomationConfigByStudyIdQuery request, CancellationToken cancellationToken)
        {
            var edcDetails = await GetEDCDetailLists(request.studyId);
            return edcDetails!;
        }
        private async Task<List<SASAutomationConfig>> GetEDCDetailLists(long studyId)
        {           
            if (studyId== 0)
            {
                var edcDetails = (await _SASAutomationConfigRepository.GetAllAsync()).Where(x=>x?.IsEDCActive==true &&x.LastError!=null);               
                return edcDetails.ToList();
            }
            else
            {
                var edcDetails = (await _SASAutomationConfigRepository.GetAllAsync()).Where(x => x.StudyID == studyId);
                return edcDetails.ToList();
            }
        }
    }
   }
