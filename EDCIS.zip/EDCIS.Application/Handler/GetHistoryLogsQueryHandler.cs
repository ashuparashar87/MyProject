﻿using EDCIS.Application.Persistence;
using EDCIS.Domain.Entities;
using System.Diagnostics;

namespace EDCIS.Application.Handler
{
    public record GetHistoryLogsQuery(DateTime? fromDate, DateTime? thruDate) : IRequest<List<HistoryLog>>;
    public class GetHistoryLogsQueryHandler : IRequestHandler<GetHistoryLogsQuery, List<HistoryLog>>
    {
        private readonly IAsyncRepository<HistoryLog> _logRepository;
        private readonly IAsyncCTMS_RDBRepository<EDCISStudyView> _studyRepository;
        public GetHistoryLogsQueryHandler(IAsyncRepository<HistoryLog> logRepository, IAsyncCTMS_RDBRepository<EDCISStudyView> studyRepository)
        {
            _logRepository = logRepository;
            _studyRepository = studyRepository;
        }

        public async Task<List<HistoryLog>> Handle(GetHistoryLogsQuery request, CancellationToken cancellationToken)
        {
            IEnumerable<HistoryLog> logDetails;

            if (request.fromDate != null && request.thruDate != null)
            {
                logDetails = await _logRepository.GetAsync(x => x.TimeStamp >= request.fromDate && x.TimeStamp <= request.thruDate, orderBy: x => x.OrderByDescending(y => y.TimeStamp));
            }
            else if (request.fromDate != null && request.thruDate == null)
            {
                logDetails = await _logRepository.GetAsync(x => x.TimeStamp >= request.fromDate, orderBy: x => x.OrderByDescending(y => y.TimeStamp));
            }
            else if (request.fromDate == null && request.thruDate != null)
            {
                logDetails = await _logRepository.GetAsync(x => x.TimeStamp <= request.thruDate, orderBy: x => x.OrderByDescending(y => y.TimeStamp));
            }
            else
            {
                logDetails = await _logRepository.GetAsync(orderBy: x => x.OrderByDescending(y => y.TimeStamp));
            }

            var studies = (await _studyRepository.GetAllAsync()).OrderBy(x => x.StudyName);

            var response = logDetails?.GroupJoin(studies, x => x.StudyID, y => y.StudyID,
                 (x, y) => new { x, y = y.DefaultIfEmpty() })
                .SelectMany(z => z.y.Select(y => new HistoryLog()
                {
                    Id = z.x.Id,
                    StudyID = y?.StudyID,
                    StudyName = y?.StudyName,
                    EDCConfigID = z?.x?.EDCConfigID,
                    ConfigName = z?.x?.ConfigName,
                    Process = z!.x.Process,
                    TimeStamp = z.x.TimeStamp,
                    LogDetails = z.x.LogDetails,
                    InitiatedBy = z.x.InitiatedBy,
                    ExceptionMessage = z.x.ExceptionMessage
                })).ToList();

            return response!;
        }
    }

    public record GetHistoryLogsByStudyIdQuery(long StudId, DateTime? fromDate, DateTime? thruDate) : IRequest<List<HistoryLog>>;

    public class GetHistoryLogsByStudyIdQueryHandler : IRequestHandler<GetHistoryLogsByStudyIdQuery, List<HistoryLog>>
    {
        private readonly IAsyncRepository<HistoryLog> _logRepository;
        private readonly IAsyncCTMS_RDBRepository<EDCISStudyView> _studyRepository;
        public GetHistoryLogsByStudyIdQueryHandler(IAsyncRepository<HistoryLog> logRepository, IAsyncCTMS_RDBRepository<EDCISStudyView> studyRepository)
        {
            _logRepository = logRepository;
            _studyRepository = studyRepository;
        }

        public async Task<List<HistoryLog>> Handle(GetHistoryLogsByStudyIdQuery request, CancellationToken cancellationToken)
        {
            IEnumerable<HistoryLog> logDetails;

            if (request.fromDate != null && request.thruDate != null)
            {
                logDetails = await _logRepository.GetAsync(x => x.StudyID == request.StudId && x.TimeStamp >= request.fromDate && x.TimeStamp <= request.thruDate, orderBy: x => x.OrderByDescending(y => y.TimeStamp));
            }
            else if (request.fromDate != null && request.thruDate == null)
            {
                logDetails = await _logRepository.GetAsync(x => x.StudyID == request.StudId && x.TimeStamp >= request.fromDate, orderBy: x => x.OrderByDescending(y => y.TimeStamp));
            }
            else if (request.fromDate == null && request.thruDate != null)
            {
                logDetails = await _logRepository.GetAsync(x => x.StudyID == request.StudId && x.TimeStamp <= request.thruDate, orderBy: x => x.OrderByDescending(y => y.TimeStamp));
            }
            else
            {
                logDetails = await _logRepository.GetAsync(orderBy: x => x.OrderByDescending(y => y.TimeStamp));
            }

            var studies = (await _studyRepository.GetAllAsync()).OrderBy(x => x.StudyName);

            var response = logDetails?.GroupJoin(studies, x => x.StudyID, y => y.StudyID,
                 (x, y) => new { x, y = y.DefaultIfEmpty() })
                .SelectMany(z => z.y.Select(y => new HistoryLog()
                {
                    StudyID = y?.StudyID,
                    EDCConfigID = z.x.EDCConfigID,
                    StudyName = y?.StudyName,
                    Id = z.x.Id,
                    Process = z.x.Process,
                    ConfigName = z.x.ConfigName,
                    TimeStamp = z.x.TimeStamp,
                    LogDetails = z.x.LogDetails,
                    InitiatedBy = z.x.InitiatedBy,
                    ExceptionMessage = z.x.ExceptionMessage

                })).ToList();

            return response!;
        }
    }

    public record GetHistoryLogsByConfigIdQuery(int id, DateTime? fromDate, DateTime? thruDate) : IRequest<List<HistoryLog>>;

    public class GetHistoryLogsByConfigIdQueryHandler : IRequestHandler<GetHistoryLogsByConfigIdQuery, List<HistoryLog>>
    {
        private readonly IAsyncRepository<HistoryLog> _logRepository;
        private readonly IAsyncCTMS_RDBRepository<EDCISStudyView> _studyRepository;
        public GetHistoryLogsByConfigIdQueryHandler(IAsyncRepository<HistoryLog> logRepository, IAsyncCTMS_RDBRepository<EDCISStudyView> studyRepository)
        {
            _logRepository = logRepository;
            _studyRepository = studyRepository;
        }

        public async Task<List<HistoryLog>> Handle(GetHistoryLogsByConfigIdQuery request, CancellationToken cancellationToken)
        {
            IEnumerable<HistoryLog> logDetails;

            if (request.fromDate != null && request.thruDate != null)
            {
                logDetails = await _logRepository.GetAsync(x => x.EDCConfigID == request.id && x.TimeStamp >= request.fromDate && x.TimeStamp <= request.thruDate, orderBy: x => x.OrderByDescending(y => y.TimeStamp));
            }
            else if (request.fromDate != null && request.thruDate == null)
            {
                logDetails = await _logRepository.GetAsync(x => x.EDCConfigID == request.id && x.TimeStamp >= request.fromDate, orderBy: x => x.OrderByDescending(y => y.TimeStamp));
            }
            else if (request.fromDate == null && request.thruDate != null)
            {
                logDetails = await _logRepository.GetAsync(x => x.EDCConfigID == request.id && x.TimeStamp <= request.thruDate, orderBy: x => x.OrderByDescending(y => y.TimeStamp));
            }
            else
            {
                logDetails = await _logRepository.GetAsync(orderBy: x => x.OrderByDescending(y => y.TimeStamp));
            }

            var studies = (await _studyRepository.GetAllAsync()).OrderBy(x => x.StudyName);

            var response = logDetails?.GroupJoin(studies, x => x.StudyID, y => y.StudyID,
                 (x, y) => new { x, y = y.DefaultIfEmpty() })
                .SelectMany(z => z.y.Select(y => new HistoryLog()
                {
                    StudyID = y?.StudyID,
                    EDCConfigID = z.x.EDCConfigID,
                    StudyName = y?.StudyName,
                    Id = z.x.Id,
                    Process = z.x.Process,
                    ConfigName = z.x.ConfigName,
                    TimeStamp = z.x.TimeStamp,
                    LogDetails = z.x.LogDetails,
                    InitiatedBy = z.x.InitiatedBy,
                    ExceptionMessage = z.x.ExceptionMessage
                })).ToList();

            return response!;
        }
    }

    public record GetLogsByConfigIdQuery(int id) : IRequest<HistoryLog?>;
    public class GetLogsByConfigIdQueryHandler : IRequestHandler<GetLogsByConfigIdQuery, HistoryLog?>
    {
        private readonly IAsyncRepository<HistoryLog> _logRepository;
        public GetLogsByConfigIdQueryHandler(IAsyncRepository<HistoryLog> logRepository)
        {
            _logRepository = logRepository;
        }

        public async Task<HistoryLog?> Handle(GetLogsByConfigIdQuery request, CancellationToken cancellationToken)
        {
            HistoryLog? logDetails;
            logDetails = (await _logRepository.GetAsync(x => x.EDCConfigID == request.id && x.ExceptionMessage != ""))
                .OrderByDescending(x => x.TimeStamp).FirstOrDefault();
            return logDetails;
        }
    }

    public record GetHistoryLogsByInitiateByQuery(string id, DateTime? fromDate, DateTime? thruDate) : IRequest<List<HistoryLog>>;

    public class GetHistoryLogsByInitiateByQueryHandler : IRequestHandler<GetHistoryLogsByInitiateByQuery, List<HistoryLog>>
    {
        private readonly IAsyncRepository<HistoryLog> _logRepository;
        private readonly IAsyncCTMS_RDBRepository<EDCISStudyView> _studyRepository;
        public GetHistoryLogsByInitiateByQueryHandler(IAsyncRepository<HistoryLog> logRepository, IAsyncCTMS_RDBRepository<EDCISStudyView> studyRepository)
        {
            _logRepository = logRepository;
            _studyRepository = studyRepository;
        }

        public async Task<List<HistoryLog>> Handle(GetHistoryLogsByInitiateByQuery request, CancellationToken cancellationToken)
        {
            IEnumerable<HistoryLog> logDetails;

            if (request.fromDate != null && request.thruDate != null)
            {
                logDetails = await _logRepository.GetAsync(x => x.InitiatedBy == request.id && x.TimeStamp >= request.fromDate && x.TimeStamp <= request.thruDate, orderBy: x => x.OrderByDescending(y => y.TimeStamp));
            }
            else if (request.fromDate != null && request.thruDate == null)
            {
                logDetails = await _logRepository.GetAsync(x => x.InitiatedBy == request.id && x.TimeStamp >= request.fromDate, orderBy: x => x.OrderByDescending(y => y.TimeStamp));
            }
            else if (request.fromDate == null && request.thruDate != null)
            {
                logDetails = await _logRepository.GetAsync(x => x.InitiatedBy == request.id && x.TimeStamp <= request.thruDate, orderBy: x => x.OrderByDescending(y => y.TimeStamp));
            }
            else
            {
                logDetails = await _logRepository.GetAsync(orderBy: x => x.OrderByDescending(y => y.TimeStamp));
            }

            var studies = (await _studyRepository.GetAllAsync()).OrderBy(x => x.StudyName);

            var response = logDetails?.GroupJoin(studies, x => x.StudyID, y => y.StudyID,
                 (x, y) => new { x, y = y.DefaultIfEmpty() })
                .SelectMany(z => z.y.Select(y => new HistoryLog()
                {
                    StudyID = y?.StudyID,
                    EDCConfigID = z.x.EDCConfigID,
                    StudyName = y?.StudyName,
                    Id = z.x.Id,
                    Process = z.x.Process,
                    ConfigName = z.x.ConfigName,
                    TimeStamp = z.x.TimeStamp,
                    LogDetails = z.x.LogDetails,
                    InitiatedBy = z.x.InitiatedBy,
                    ExceptionMessage = z.x.ExceptionMessage
                })).ToList();

            return response!;
        }
    }


    public record GetHistoryLogsByStudyIdInitiateByQuery(long StudId, string id, DateTime? fromDate, DateTime? thruDate) : IRequest<List<HistoryLog>>;

    public class GetHistoryLogsByStudyIdInitiateByQueryHandler : IRequestHandler<GetHistoryLogsByStudyIdInitiateByQuery, List<HistoryLog>>
    {
        private readonly IAsyncRepository<HistoryLog> _logRepository;
        private readonly IAsyncCTMS_RDBRepository<EDCISStudyView> _studyRepository;
        public GetHistoryLogsByStudyIdInitiateByQueryHandler(IAsyncRepository<HistoryLog> logRepository, IAsyncCTMS_RDBRepository<EDCISStudyView> studyRepository)
        {
            _logRepository = logRepository;
            _studyRepository = studyRepository;
        }

        public async Task<List<HistoryLog>> Handle(GetHistoryLogsByStudyIdInitiateByQuery request, CancellationToken cancellationToken)
        {
            IEnumerable<HistoryLog> logDetails;
           
                if (request.fromDate != null && request.thruDate != null &&(request.StudId != 0 && (!string.IsNullOrEmpty(request.id) && request.id != "All")))
                {
                    logDetails = await _logRepository.GetAsync(x => x.StudyID == request.StudId && x.InitiatedBy == request.id && x.TimeStamp >= request.fromDate && x.TimeStamp <= request.thruDate, orderBy: x => x.OrderByDescending(y => y.TimeStamp));
                }
                else if (request.fromDate != null && request.thruDate == null)
                {
                    logDetails = await _logRepository.GetAsync(x => x.StudyID == request.StudId && x.InitiatedBy == request.id && x.TimeStamp >= request.fromDate, orderBy: x => x.OrderByDescending(y => y.TimeStamp));
                }
                else if (request.fromDate == null && request.thruDate != null)
                {
                    logDetails = await _logRepository.GetAsync(x => x.StudyID == request.StudId && x.InitiatedBy == request.id && x.TimeStamp <= request.thruDate, orderBy: x => x.OrderByDescending(y => y.TimeStamp));
                }
                else
                {
                    logDetails = await _logRepository.GetAsync(orderBy: x => x.OrderByDescending(y => y.TimeStamp));
                }
        
            var studies = (await _studyRepository.GetAllAsync()).OrderBy(x => x.StudyName);

            var response = logDetails?.GroupJoin(studies, x => x.StudyID, y => y.StudyID,
                 (x, y) => new { x, y = y.DefaultIfEmpty() })
                .SelectMany(z => z.y.Select(y => new HistoryLog()
                {
                    StudyID = y?.StudyID,
                    EDCConfigID = z.x.EDCConfigID,
                    StudyName = y?.StudyName,
                    Id = z.x.Id,
                    Process = z.x.Process,
                    ConfigName = z.x.ConfigName,
                    TimeStamp = z.x.TimeStamp,
                    LogDetails = z.x.LogDetails,
                    InitiatedBy = z.x.InitiatedBy,
                    ExceptionMessage = z.x.ExceptionMessage
                })).ToList();

            return response!;
        }
    }
}
