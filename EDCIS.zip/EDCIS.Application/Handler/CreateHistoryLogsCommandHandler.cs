﻿using EDCIS.Application.Persistence;
using EDCIS.Domain.Entities;

namespace EDCIS.Application.Handler
{
    public record CreateHistoryLogsCommand(HistoryLog model) : IRequest<Unit>;
    public class CreateHistoryLogsCommandHandler : IRequestHandler<CreateHistoryLogsCommand, Unit>
    {
        private readonly IAsyncRepository<HistoryLog> _historyLogRepository;
        public CreateHistoryLogsCommandHandler(IAsyncRepository<HistoryLog> historyLogRepository)
        {
            _historyLogRepository = historyLogRepository;
        }
        public async Task<Unit> Handle(CreateHistoryLogsCommand request, CancellationToken cancellationToken)
        {
            await _historyLogRepository.AddAsync(request.model);
            return Unit.Value;
        }
    }
}
