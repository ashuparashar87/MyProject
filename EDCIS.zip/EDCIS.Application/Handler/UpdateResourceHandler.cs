﻿using EDCIS.Application.Persistence;
using EDCIS.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDCIS.Application.Handler
{
    public record UpdateResourceCommand(Resource model) : IRequest<Unit>;
    public class UpdateResourceHandler : IRequestHandler<UpdateResourceCommand, Unit>
    {
        private readonly IAsyncRepository<Resource> _resourceRepository;
        private readonly IMapper _mapper;
        public UpdateResourceHandler(IMapper mapper, IAsyncRepository<Resource> resourceRepository)
        {
            _resourceRepository = resourceRepository;
            _mapper = mapper;
        }

        public async Task<Unit> Handle(UpdateResourceCommand request, CancellationToken cancellationToken)
        {
            await _resourceRepository.UpdateAsync(request.model);
            return Unit.Value;
        }
    }
}
