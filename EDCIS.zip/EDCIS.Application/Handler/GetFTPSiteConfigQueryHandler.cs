﻿using EDCIS.Application.Persistence;
using EDCIS.Domain.Entities;
using System.Security.Cryptography.X509Certificates;
using System.Text.RegularExpressions;

namespace EDCIS.Application.Handler
{
    public record GetFTPSiteConfigQuery() : IRequest<List<FTPSiteConfig>>;
    public class GetFTPSiteConfigQueryHandler : IRequestHandler<GetFTPSiteConfigQuery, List<FTPSiteConfig>>
    {
        private readonly IAsyncRepository<FTPSiteConfig> _FTPSiteConfigRepository;

        public GetFTPSiteConfigQueryHandler(IAsyncRepository<FTPSiteConfig> FTPSiteConfigRepository)
        {
            _FTPSiteConfigRepository = FTPSiteConfigRepository;
        }

        public async Task<List<FTPSiteConfig>> Handle(GetFTPSiteConfigQuery request, CancellationToken cancellationToken)
        {
            var edcDetails = await _FTPSiteConfigRepository.GetAllAsync();
            return edcDetails.ToList();
        }
    }
    public record GetFTPSiteConfigQueryByFTPSiteQuery(string FTPSite) : IRequest<FTPSiteConfig>;
    public class GetFTPSiteConfigQueryByFTPSiteHandler : IRequestHandler<GetFTPSiteConfigQueryByFTPSiteQuery, FTPSiteConfig>
    {
        private readonly IAsyncRepository<FTPSiteConfig> _FTPSiteConfigRepository;

        public GetFTPSiteConfigQueryByFTPSiteHandler(IAsyncRepository<FTPSiteConfig> FTPSiteConfigRepository)
        {
            _FTPSiteConfigRepository = FTPSiteConfigRepository;
        }

        public async Task<FTPSiteConfig> Handle(GetFTPSiteConfigQueryByFTPSiteQuery request, CancellationToken cancellationToken)
        {
            return (await _FTPSiteConfigRepository.GetAsync(x => x.FTPSite == request.FTPSite)).SingleOrDefault()!;

        }
    }

    public record GetFTPSiteConfigQueryByIdQuery(int Id) : IRequest<FTPSiteConfig>;
    public class GetFTPSiteConfigQueryByIdHandler : IRequestHandler<GetFTPSiteConfigQueryByIdQuery, FTPSiteConfig>
    {
        private readonly IAsyncRepository<FTPSiteConfig> _FTPSiteConfigRepository;

        public GetFTPSiteConfigQueryByIdHandler(IAsyncRepository<FTPSiteConfig> FTPSiteConfigRepository)
        {
            _FTPSiteConfigRepository = FTPSiteConfigRepository;
        }

        public async Task<FTPSiteConfig> Handle(GetFTPSiteConfigQueryByIdQuery request, CancellationToken cancellationToken)
        {
            return (await _FTPSiteConfigRepository.GetAsync(x => x.Id == request.Id)).SingleOrDefault()!;

        }
    }

    public record GetDeleteFTPSiteConfigQuery(int Id) : IRequest<FTPSiteConfig>;
    public class GetDeleteFTPSiteConfigQueryHandler : IRequestHandler<GetDeleteFTPSiteConfigQuery, FTPSiteConfig>
    {
        private readonly IAsyncRepository<FTPSiteConfig> _FTPSiteConfigRepository;
        private readonly IAsyncRepository<SASAutomationConfig> _SASAutomationConfigRepository;

        public GetDeleteFTPSiteConfigQueryHandler(IAsyncRepository<FTPSiteConfig> FTPSiteConfigRepository, IAsyncRepository<SASAutomationConfig> SASAutomationConfigRepository)
        {
            _FTPSiteConfigRepository = FTPSiteConfigRepository;
            _SASAutomationConfigRepository = SASAutomationConfigRepository;
        }

        public async Task<FTPSiteConfig> Handle(GetDeleteFTPSiteConfigQuery request, CancellationToken cancellationToken)
        {
            var edcAdminConfig = (await _FTPSiteConfigRepository.GetAsync(x => x.Id == request.Id)).SingleOrDefault()!;
            var edcConfig = (await _SASAutomationConfigRepository.GetAsync(x => x.SourceFTPSite == edcAdminConfig.FTPSite || x.DestFTPSite == edcAdminConfig.FTPSite));
            if (edcConfig.Count == 0)
            {
                return edcAdminConfig;
            }
# nullable disable
            return null;
#nullable enable
        }
    }

    public record DeleteFTPSiteConfigQuery(FTPSiteConfig model) : IRequest<Unit>;
    public class DeleteFTPSiteConfigQueryHandler : IRequestHandler<DeleteFTPSiteConfigQuery, Unit>
    {
        private readonly IAsyncRepository<FTPSiteConfig> _FTPSiteConfigRepository;

        public DeleteFTPSiteConfigQueryHandler(IAsyncRepository<FTPSiteConfig> FTPSiteConfigRepository)
        {
            _FTPSiteConfigRepository = FTPSiteConfigRepository;
        }

        public async Task<Unit> Handle(DeleteFTPSiteConfigQuery request, CancellationToken cancellationToken)
        {
            await _FTPSiteConfigRepository.DeleteAsync(request.model);
            return Unit.Value;
        }
    }
}

