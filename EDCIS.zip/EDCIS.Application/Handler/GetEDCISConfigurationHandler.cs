﻿using EDCIS.Application.Persistence;
using EDCIS.Domain.Entities;
namespace EDCIS.Application.Handler
{
    public record GetEDCISConfigurationListQuery() : IRequest<List<EDCISConfiguration>>;

    internal class GetEDCISConfigurationHandler : IRequestHandler<GetEDCISConfigurationListQuery, List<EDCISConfiguration>>
    {
        private readonly IAsyncRepository<EDCISConfiguration> _EDCISConfigurationRepository;
        public GetEDCISConfigurationHandler(IAsyncRepository<EDCISConfiguration> EDCISConfigurationRepository)
        {
            _EDCISConfigurationRepository = EDCISConfigurationRepository;
        }

        public async Task<List<EDCISConfiguration>> Handle(GetEDCISConfigurationListQuery request, CancellationToken cancellationToken)
        {
            var configeList = await _EDCISConfigurationRepository.GetAllAsync();
            return configeList.ToList();
        }
    }

    public record GetEDCISConfigurationByIdQuery(long id) : IRequest<List<EDCISConfiguration>>;

    internal class GetEDCISConfigurationByIdQueryHandler : IRequestHandler<GetEDCISConfigurationByIdQuery, List<EDCISConfiguration>>
    {
        private readonly IAsyncRepository<EDCISConfiguration> _EDCISConfigurationRepository;
        public GetEDCISConfigurationByIdQueryHandler(IAsyncRepository<EDCISConfiguration> EDCISConfigurationRepository)
        {
            _EDCISConfigurationRepository = EDCISConfigurationRepository;
        }


        public async Task<List<EDCISConfiguration>> Handle(GetEDCISConfigurationByIdQuery request, CancellationToken cancellationToken)
        {
            var configeList = await _EDCISConfigurationRepository.GetAsync(x => x.Id == request.id);
            return configeList.ToList();

        }
    }

    public record GetEDCISConfigurationByKeyQuery(string key) : IRequest<List<EDCISConfiguration>>;

    internal class GetEDCISConfigurationByKeyQueryHandler : IRequestHandler<GetEDCISConfigurationByKeyQuery, List<EDCISConfiguration>>
    {
        private readonly IAsyncRepository<EDCISConfiguration> _EDCISConfigurationRepository;
        public GetEDCISConfigurationByKeyQueryHandler(IAsyncRepository<EDCISConfiguration> EDCISConfigurationRepository)
        {
            _EDCISConfigurationRepository = EDCISConfigurationRepository;
        }


        public async Task<List<EDCISConfiguration>> Handle(GetEDCISConfigurationByKeyQuery request, CancellationToken cancellationToken)
        {
            var configeList = await _EDCISConfigurationRepository.GetAsync(x=> x.Key ==request.key);
            return configeList.ToList();

        }
    }
}
