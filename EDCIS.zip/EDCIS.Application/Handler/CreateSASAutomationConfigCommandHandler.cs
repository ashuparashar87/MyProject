﻿using EDCIS.Application.Persistence;
using EDCIS.Domain.Entities;

namespace EDCIS.Application.Handler
{
    public record CreateSASAutomationConfigCommand(SASAutomationConfig model) : IRequest<Unit>;
    public class CreateSASAutomationConfigCommandHandler : IRequestHandler<CreateSASAutomationConfigCommand, Unit>
    {
        private readonly IAsyncRepository<SASAutomationConfig> _sasAutomationConfigRepository;
        private readonly IAsyncRepository<FTPSiteConfig> _ftpSiteConfigConfigRepository;

        public CreateSASAutomationConfigCommandHandler(IAsyncRepository<SASAutomationConfig> sasAutomationConfigRepository, IAsyncRepository<FTPSiteConfig> ftpSiteConfigConfigRepository)
        {
            _sasAutomationConfigRepository = sasAutomationConfigRepository;
            _ftpSiteConfigConfigRepository = ftpSiteConfigConfigRepository;

        }
        public async Task<Unit> Handle(CreateSASAutomationConfigCommand request, CancellationToken cancellationToken)
        {
            var existRecord = await _sasAutomationConfigRepository.GetAsync(x => x.Id == request.model.Id);

            if (request.model.ConfigurationType == Domain.Enum.ConfigurationTypeValue.FileTransfer)
            {
                var sourceConfigDetail = (await _ftpSiteConfigConfigRepository.GetAsync(x => x.FTPSite == request.model.SourceFTPSite)).SingleOrDefault();
                var destConfigDetail = (await _ftpSiteConfigConfigRepository.GetAsync(x => x.FTPSite == request.model.DestFTPSite)).SingleOrDefault();

                if (existRecord.Count == 0 && sourceConfigDetail != null && destConfigDetail != null)
                {
                    request.model.SourceFTPSite = sourceConfigDetail.FTPSite;
                    request.model.SourceFileProtocol = sourceConfigDetail.FileProtocol;
                    request.model.SourceEncryption = sourceConfigDetail.Encryption;
                    request.model.SourceHostName = sourceConfigDetail.HostName;
                    request.model.SourcePortNumber = sourceConfigDetail.PortNumber;
                    request.model.SourceUserName = sourceConfigDetail.UserName;
                    request.model.SourcePassword = sourceConfigDetail.Password;
                    request.model.DestFTPSite = destConfigDetail.FTPSite;
                    request.model.DestFileProtocol = destConfigDetail.FileProtocol;
                    request.model.DestEncryption = destConfigDetail.Encryption;
                    request.model.DestHostName = destConfigDetail.HostName;
                    request.model.DestPortNumber = destConfigDetail.PortNumber;
                    request.model.DestUserName = destConfigDetail.UserName;
                    request.model.DestPassword = destConfigDetail.Password;
                    await _sasAutomationConfigRepository.AddAsync(request.model);
                }
                else
                {
                    var updatedRecord = existRecord.SingleOrDefault();
                    if (updatedRecord != null && sourceConfigDetail != null && destConfigDetail != null)
                    {
                        updatedRecord.StudyID = request.model.StudyID;
                        updatedRecord.SourceFTPSite = sourceConfigDetail.FTPSite;
                        updatedRecord.SourceFileProtocol = sourceConfigDetail.FileProtocol;
                        updatedRecord.SourceEncryption = sourceConfigDetail.Encryption;
                        updatedRecord.SourceHostName = sourceConfigDetail.HostName;
                        updatedRecord.SourcePortNumber = sourceConfigDetail.PortNumber;
                        updatedRecord.SourceUserName = sourceConfigDetail.UserName;
                        updatedRecord.SourcePassword = sourceConfigDetail.Password;
                        updatedRecord.SourceFileName = request.model.SourceFileName;
                        updatedRecord.SourceZipPassword = request.model.SourceZipPassword;
                        updatedRecord.SourceFolderPath = request.model.SourceFolderPath;
                        updatedRecord.DestFTPSite = destConfigDetail.FTPSite;
                        updatedRecord.DestFileProtocol = destConfigDetail.FileProtocol;
                        updatedRecord.DestEncryption = destConfigDetail.Encryption;
                        updatedRecord.DestHostName = destConfigDetail.HostName;
                        updatedRecord.DestPortNumber = destConfigDetail.PortNumber;
                        updatedRecord.DestUserName = destConfigDetail.UserName;
                        updatedRecord.DestPassword = destConfigDetail.Password;
                        updatedRecord.ArchiveDestFolderPath = request.model.ArchiveDestFolderPath;
                        updatedRecord.CurrentDestFolderPath = request.model.CurrentDestFolderPath;
                        updatedRecord.IsEDCActive = request.model.IsEDCActive;
                        updatedRecord.IsDaily = request.model.IsDaily;
                        updatedRecord.TimeSlot = request.model.TimeSlot;
                        updatedRecord.WeekDays = request.model.WeekDays;
                        updatedRecord.IsDeleteFileAfterTransfer = request.model.IsDeleteFileAfterTransfer;
                        updatedRecord.ConfigName = request.model.ConfigName;
                        updatedRecord.IsErrorInLastExecution = request.model.IsErrorInLastExecution;
                        updatedRecord.ErrorEmailRecipients = request.model.ErrorEmailRecipients;
                        updatedRecord.SuccessEmailRecipients = request.model.SuccessEmailRecipients;
                        updatedRecord.CanRunStatistician = request.model.CanRunStatistician;
                        updatedRecord.CanDMRUN = request.model.CanDMRUN;
                        updatedRecord.ExecuteProgramAfterTransfer = request.model.ExecuteProgramAfterTransfer;
                        updatedRecord.TimeoutInSeconds = request.model.TimeoutInSeconds;
                        updatedRecord.Description = request.model.Description;
                        updatedRecord.File = request.model.File;
                        updatedRecord.Path = request.model.Path;
                        updatedRecord.Arguments = request.model.Arguments;
                        updatedRecord.ConfigurationType = request.model.ConfigurationType;
                        await _sasAutomationConfigRepository.UpdateAsync(updatedRecord);
                    }
                }
            }
            else
            {
                if (existRecord.Count == 0)
                {
                    await _sasAutomationConfigRepository.AddAsync(request.model);
                }
                else
                {
                    var updatedRecord = existRecord.SingleOrDefault();
                    if (updatedRecord != null)
                    {
                        updatedRecord.StudyID = request.model.StudyID; 
                        updatedRecord.IsEDCActive = request.model.IsEDCActive;
                        updatedRecord.IsDaily = request.model.IsDaily;
                        updatedRecord.TimeSlot = request.model.TimeSlot;
                        updatedRecord.WeekDays = request.model.WeekDays;
                        updatedRecord.IsDeleteFileAfterTransfer = request.model.IsDeleteFileAfterTransfer;
                        updatedRecord.ConfigName = request.model.ConfigName;
                        updatedRecord.IsErrorInLastExecution = request.model.IsErrorInLastExecution;
                        updatedRecord.ErrorEmailRecipients = request.model.ErrorEmailRecipients;
                        updatedRecord.SuccessEmailRecipients = request.model.SuccessEmailRecipients;
                        updatedRecord.CanRunStatistician = request.model.CanRunStatistician;
                        updatedRecord.CanDMRUN = request.model.CanDMRUN;
                        updatedRecord.ExecuteProgramAfterTransfer = request.model.ExecuteProgramAfterTransfer;
                        updatedRecord.TimeoutInSeconds = request.model.TimeoutInSeconds;
                        updatedRecord.Description = request.model.Description;
                        updatedRecord.File = request.model.File;
                        updatedRecord.Path = request.model.Path;
                        updatedRecord.Arguments = request.model.Arguments;
                        updatedRecord.ConfigurationType = request.model.ConfigurationType;
                        await _sasAutomationConfigRepository.UpdateAsync(updatedRecord);
                    }
                }
            }
            return Unit.Value;
        }
    }

    public record CloneSASAutomationConfigCommand(SASAutomationConfig model) : IRequest<Unit>;
    public class CloneSASAutomationConfigCommandHandler : IRequestHandler<CloneSASAutomationConfigCommand, Unit>
    {
        private readonly IAsyncRepository<SASAutomationConfig> _sasAutomationConfigRepository;
        public CloneSASAutomationConfigCommandHandler(IAsyncRepository<SASAutomationConfig> sasAutomationConfigRepository)
        {
            _sasAutomationConfigRepository = sasAutomationConfigRepository;
        }
        public async Task<Unit> Handle(CloneSASAutomationConfigCommand request, CancellationToken cancellationToken)
        {
            await _sasAutomationConfigRepository.AddAsync(request.model);
            return Unit.Value;
        }
    }

    public record UpdateSASConfigCommand(SASAutomationConfig model) : IRequest<Unit>;
    public class UpdateSASConfigCommandHandler : IRequestHandler<UpdateSASConfigCommand, Unit>
    {
        private readonly IAsyncRepository<SASAutomationConfig> _sasAutomationConfigRepository;

        public UpdateSASConfigCommandHandler(IAsyncRepository<SASAutomationConfig> sasAutomationConfigRepository)
        {
            _sasAutomationConfigRepository = sasAutomationConfigRepository;

        }
        public async Task<Unit> Handle(UpdateSASConfigCommand request, CancellationToken cancellationToken)
        {
          await _sasAutomationConfigRepository.UpdateAsync(request.model);
            return Unit.Value;
        }
    }
}
