﻿using EDCIS.Domain.Entities;


namespace EDCIS.Application.Profiles
{
    public class MappingProfile : AutoMapper.Profile
    {
        public MappingProfile()
        {
            CreateMap<EDCISStudyView, StudyListVm>();
        }
    }
}
