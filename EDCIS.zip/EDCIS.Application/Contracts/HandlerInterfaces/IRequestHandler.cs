﻿using System.Linq.Expressions;
namespace EDCIS.Application.Contracts.HandlerInterfaces
{
    public interface IEDCRequestHandler<T>
    {
        Task<T?> GetRequestByIdAsync(object key);
        Task<T> AddRequestAsync(T entity);
        Task UpdateRequestAsync(T entity);
        Task DeleteRequestAsync(T entity);
        Task<IEnumerable<T>> GetAllAsync();

        Task<IEnumerable<T>> GetAsync(Expression<Func<T, bool>>? predicate = null,
        Func<IQueryable<T>, IOrderedQueryable<T>>? orderBy = null,
        string? includeString = null,
        bool disableTracking = true);

    }
}
