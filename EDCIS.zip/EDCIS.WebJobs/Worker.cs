﻿using EDCIS.Application.Handler;
using MediatR;
using Microsoft.Extensions.Logging;
using EDCIS.Application.ClientInfrastructure.Dtos;

namespace EDCIS.WebJobs
{
    public class Worker
    {
        private readonly ILogger<Worker> _logger;
        private readonly IMediator _mediator;
        public Worker(ILogger<Worker> logger, IMediator mediator)
        {
            _logger = logger;
            _mediator = mediator;
        }
        public async Task ExecuteAsync()
        {
            var toEmails = await _mediator.Send(new GetEDCSettingQuery());
            var emails = toEmails.FirstOrDefault()?.SupportEmail;
            SD.Error_ToEmail = emails != null ? emails : SD.CriticalErrorEmail_ToEmail;
            await _mediator.Send(new ExecuteSASAutomationWebJobCommand());
            _logger.LogInformation("Job is completed");
        }
    }
}
