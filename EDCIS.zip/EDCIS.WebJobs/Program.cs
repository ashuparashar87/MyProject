﻿using EDCIS.Application;
using EDCIS.Application.Persistence;
using EDCIS.Infrastructure;
using EDCIS.Infrastructure.Repository;
using EDCIS.WebJobs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Reflection;

public class Program
{
    public static IConfiguration? _Configuration;
    public static async Task Main(string[] args)
    {
        await CreateHostBuilderAsync(args);
    }

    public static  Task CreateHostBuilderAsync(string[] args)
    {

        IHostBuilder builder = Host.CreateDefaultBuilder(args)
            .ConfigureServices((hostContext, services) =>
            {
                IConfigurationBuilder builder = new ConfigurationBuilder()
                   .SetBasePath(Directory.GetCurrentDirectory())
                   .AddJsonFile("appsettings.json")
                   .AddEnvironmentVariables()
                   .AddUserSecrets<Program>();
                _Configuration = builder.Build();               
                // Add services to the container.
                services.AddApplicationServices(_Configuration);
                // Add services to the container.
                services.AddApplicationServices(hostContext.Configuration);
                services.AddInfrastructureServices(_Configuration, hostContext.HostingEnvironment.IsDevelopment());
                services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly()));
                services.AddScoped(typeof(IAsyncRepository<>), typeof(RepositoryBase<>));
                services.AddScoped<Worker>();
            });


        var app = builder.Build();
        using (var scope = app.Services.CreateScope())
        {
            var services = scope.ServiceProvider;
            var svc = app.Services.GetRequiredService<Worker>();
            svc.ExecuteAsync().Wait();
        }
        return Task.CompletedTask;
    }
}