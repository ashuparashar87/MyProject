using System.ComponentModel.DataAnnotations;
using EDCIS.Application.Utility;

namespace EDCIS.UI.Pages.Log
{
    public class LogsModel : PageModel
    {
        [Display(Name = "From")]
        public DateTime? fromDate { get; set; }

        [Display(Name = "Thru")]
        public DateTime? thruDate { get; set; }

        private readonly ILogger _logger;
        private readonly IMediator _mediator;

        [BindProperty]
        public HistoryLog MainEntity { get; set; } = null!;

        public LogsModel(ILogger<LogsModel> logger, IMediator mediator)
        {
            _logger = logger;
            _mediator = mediator;
        }
        public IActionResult OnGet(long studyId,int edcId)
        {
            if (MainEntity == null && studyId != 0)
            {
                MainEntity = new HistoryLog();
                MainEntity.StudyID = studyId;
            }
            if (MainEntity == null && edcId != 0)
            {
                MainEntity = new HistoryLog();
                MainEntity.EDCConfigID = edcId;
            }

            fromDate = DateTime.Now.Date;
            thruDate = DateTime.Now.Date.AddHours(23).AddMinutes(59);

            return Page();
        }

    public async Task<IActionResult> OnGetGridData(DataSourceLoadOptions loadOptions, DateTime? fromDate, DateTime? thruDate, string TimeZone, long studId,int edcId)
        {
            try
            {
                DateTime? FromDate = fromDate != null ? fromDate.Value.ShiftLocalToUtc(TimeZone) : null;
                DateTime? ThruDate = thruDate != null ? thruDate.Value.ShiftLocalToUtc(TimeZone) : null;

                IEnumerable<HistoryLog> historyLogs;

                if (studId != 0)
                {
                    historyLogs = await _mediator.Send(new GetHistoryLogsByStudyIdQuery(studId, FromDate, ThruDate));
                }
                else if (edcId != 0)
                {
                    historyLogs = await _mediator.Send(new GetHistoryLogsByConfigIdQuery(edcId, FromDate, ThruDate));
                }
                else
                {
                    historyLogs = await _mediator.Send(new GetHistoryLogsQuery(FromDate, ThruDate));
                }
                var logs = historyLogs
                    .Select(c => new
                    {
                        Id = c.Id,
                        TimeStamp = c.TimeStamp.ShiftUtcToLocal(TimeZone),
                        EDCConfigID = c.EDCConfigID.ToString(),
                        StudyID = c.StudyID.ToString(),
                        Process = Enum.GetName(c.Process),
                        LogDetails = c.LogDetails,
                        ConfigName = c.ConfigName,
                        IsError = string.IsNullOrEmpty(c.ExceptionMessage) ? false : true,
                        StudyName = c.StudyName
                    }).ToList();
                return new JsonResult(DataSourceLoader.Load(logs, loadOptions));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message + " " + ex.InnerException);
                return StatusCode(500, ex.Message + " " + ex.InnerException);
            }
        }
    }
}
