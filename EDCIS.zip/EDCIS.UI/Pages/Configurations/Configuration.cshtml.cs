using EDCIS.UI.Pages.Resources;

namespace EDCIS.UI.Pages.Configurations
{
    public class ConfigurationModel : PageModel
    {

        private readonly ILogger _logger;
        private readonly IMediator _mediator;

        public EDCISConfiguration MainEntity { get; set; } = null!;

        public ConfigurationModel(ILogger<ConfigurationModel> logger, IMediator mediator)
        {
            _mediator = mediator;
            _logger = logger;
        }

        public async Task<IActionResult> OnGet(long key)
        {
            if (key == 0)
            {
                return Page();
            }
#nullable disable
            var data  = await _mediator.Send(new GetEDCISConfigurationByIdQuery(key));
            MainEntity = data.FirstOrDefault();
            #nullable enable
            if (MainEntity == null)
            {
                _logger.LogError(string.Format("No record found for key ", key));
                return NotFound();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostEdit([Bind("Id,Key,Value,Description,CreatedDate,CreatedBy")] EDCISConfiguration MainEntity)
        {
            MainEntity.LastModifiedDate = DateTime.UtcNow;
            if (ModelState.IsValid)
            {
                try
                {
                     await _mediator.Send(new UpdateEDCISConfigurationCommand(MainEntity));

                }
                catch (Exception ex)
                {
                    _logger.LogError(ex.Message);
                    throw;
                }
                return StatusCode(StatusCodes.Status202Accepted);
            }
            return Page();
        }


    }
}
