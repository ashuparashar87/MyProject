
namespace EDCIS.UI.Pages.Configurations
{
    public class ConfigurationsModel : PageModel
    {
        private readonly ILogger _logger;
        private readonly IMediator _mediator;
        public ConfigurationsModel(ILogger<ConfigurationsModel> logger, IMediator mediator)
        {
            _mediator = mediator;
            _logger = logger;
        }
        public void OnGet()
        {
        }


        public async Task<IActionResult> OnGetGridData(DataSourceLoadOptions loadOptions)
        {
            try
            {
                var configlist = await _mediator.Send(new GetEDCISConfigurationListQuery());
                return new JsonResult(DataSourceLoader.Load(configlist, loadOptions));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message + " " + ex.InnerException);
                return StatusCode(500, ex.Message + " " + ex.InnerException);
            }
        }
    }
}
