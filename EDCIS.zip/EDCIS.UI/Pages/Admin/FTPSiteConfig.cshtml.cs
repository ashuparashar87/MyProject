using EDCIS.Application.Configuration;
using EDCIS.Application.Interface;
using EDCIS.Application.Utility.Constant;
using EDCIS.Domain.Enum;
using EDCIS.Application.Response;
using Renci.SshNet.Common;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore.Authorization;

namespace EDCIS.UI.Pages.Admin
{
    [Authorize(Policy = "CanModifiedData")]
    public class FTPSiteConfigModel : PageModel
    {
        private readonly ILogger _logger;
        private readonly IMediator _mediator;
        [BindProperty]
        public string? ReturnUrl { get; set; }
        [BindProperty]
        public FTPSiteConfig MainEntity { get; set; } = null!;

        public FTPSiteConfigModel(ILogger<FTPSiteConfig> logger, IMediator mediator)
        {
            _logger = logger;
            _mediator = mediator;
        }
        public async Task<IActionResult> OnGet(int key)
        {
            if (key == 0)
            {
                return Page();
            }
            MainEntity = await _mediator.Send(new GetFTPSiteConfigQueryByIdQuery(key));

            if (MainEntity == null)
            {
                _logger.LogError(string.Format("No record found for key ", key));
                return NotFound();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostCreate([Bind(include: "FTPSite,FileProtocol,Encryption,HostName,PortNumber,UserName,Password")] FTPSiteConfig MainEntity)
        {

            ModelState.Remove("MainEntity.Id");
            ModelState.Remove("MainEntity.CreatedDate");
            if (ModelState.IsValid)
            {
                try
                {
                    MainEntity.CreatedDate = DateTime.UtcNow;
                    await _mediator.Send(new CreateFTPSiteConfigCommand(MainEntity));
                }
                catch (Exception ex)
                {
                    if (ex.InnerException is SqlException sqlex)
                    {
                        if (sqlex.Number == 2601)
                        {
                            return new JsonResult(new ReturnResponse { Message = "FTP Site with same name already exists." });
                        }
                    }
                    else
                    {
                        return new JsonResult(new ReturnResponse { Message = ex.Message });

                    }
                }
                return StatusCode(StatusCodes.Status202Accepted);
            }
            return Page();
        }


        public async Task<IActionResult> OnGetDelete(int key)
        {
            try
            {
                MainEntity = await _mediator.Send(new GetDeleteFTPSiteConfigQuery(key));

                if (MainEntity != null)
                {
                    await _mediator.Send(new DeleteFTPSiteConfigQuery(MainEntity));
                }
                else
                {
                    return new JsonResult(new ReturnResponse { Message = MessagesConstants.DeleteSASAutomationMessage, IsSuccess = true });

                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);

            }
            return StatusCode(StatusCodes.Status202Accepted);
        }

        public IActionResult OnPostTestConnection(string fileProtocol, string encryption, string hostName, string userName, string password, int portNumber)
        {
            var sourceConnResponse =  TestConnection(hostName, fileProtocol, encryption, userName, password, portNumber);
            return new JsonResult(new ReturnResponse { Message = sourceConnResponse.message, IsSuccess = sourceConnResponse.isSuccess });
        }

        private (string message, bool isSuccess) TestConnection(string hostName, string fileProtocol, string encryption, string userName, string password, int portNumber)
        {
            bool isSuccess = false;
            string message = string.Empty;
            try
            {
                RemoteSystemSetting setting = new RemoteSystemSetting()
                {
                    Host = hostName,
                    Port = portNumber,
                    UserName = userName,
                    Password = password,
                    Type = fileProtocol,
                    Encryption = encryption
                };

                IRemoteFileSystemContext remote;
                if (setting.Type == FileProtocol.FTP.ToString())
                {
                    remote = new FtpRemoteFileSystem(setting);
                }
                else
                {
                    remote = new SftpRemoteFileSystem(setting);
                }
                remote.Connect();
                bool isConnected = remote.IsConnected();
                if (isConnected)
                {
                    isSuccess = true;
                    message = MessagesConstants.FTPConnectedSuccessMessage(fileProtocol, hostName, portNumber);
                }
                remote.Disconnect();
                remote.Dispose();
                return (message, isSuccess);
            }
            catch (SshConnectionException)
            {
                isSuccess = false;
                message = MessagesConstants.FTPConnectedFailureMessage(fileProtocol, hostName, portNumber, "Failed to connect.");
                return (message, isSuccess);
            }
            catch (Exception ex)
            {
                isSuccess = false;
                message = ex.Message;
                return (message, isSuccess);
            }
        }

        public async Task<IActionResult> OnPostEdit([Bind("Id,FTPSite,FileProtocol,Encryption,HostName,PortNumber,UserName,Password,CreatedDate,CreatedBy")] FTPSiteConfig MainEntity)
        {
            MainEntity.LastModifiedDate = DateTime.UtcNow;
            if (ModelState.IsValid)
            {
                try
                {
                    await _mediator.Send(new CreateFTPSiteConfigCommand(MainEntity));
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex.Message);
                    throw;
                }
                return StatusCode(StatusCodes.Status202Accepted);
            }
            return Page();
        }
    }
}
