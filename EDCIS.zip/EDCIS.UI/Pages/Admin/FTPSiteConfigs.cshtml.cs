using EDCIS.Application.Handler;
using EDCIS.Domain.Entities;
using EDCIS.UI.Pages.Log;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Runtime.ConstrainedExecution;

namespace EDCIS.UI.Pages.Admin
{

    public class FTPSiteConfigsModel : PageModel
    {
        private readonly ILogger _logger;
        private readonly IMediator _mediator;
        [BindProperty]
        public FTPSiteConfig MainEntity { get; set; } = null!;


        public FTPSiteConfigsModel(ILogger<FTPSiteConfig> logger, IMediator mediator)
        {
            _logger = logger;
            _mediator = mediator;
        }
        public ActionResult OnGet()
        {
            return Page();
        }


        public async Task<IActionResult> OnGetGridData(DataSourceLoadOptions loadOptions)
        {
            try { 
            var ftpSiteDetails = await _mediator.Send(new GetFTPSiteConfigQuery());

            var ftpDetails = ftpSiteDetails.OrderBy(x => x.Id)
                .Select(c => new
                {
                    Id = c.Id,
                    FTPSite = c.FTPSite,
                    HostName = c.HostName,
                    FileProtocol = Enum.GetName(c.FileProtocol),
                    Encryption = Enum.GetName(c.Encryption),
                    PortNumber = c.PortNumber,
                    UserName = c.UserName,
                    Password = c.Password,
                    CreatedBy = c.CreatedBy,
                    CreatedDate = c.CreatedDate,
                    LastModifiedBy = c.LastModifiedBy,
                    LastModifiedDate = c.LastModifiedDate,
                });
                return new JsonResult(DataSourceLoader.Load(ftpDetails, loadOptions));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message + " " + ex.InnerException);
                return StatusCode(500, ex.Message + " " + ex.InnerException);
            }
        }
    }
}
