using EDCIS.Application.Utility.Constant;

namespace EDCIS.UI.Pages.Admin
{
    public class IndexModel : PageModel
    {
        public IActionResult OnGet()
        {
            return Page();
        }
    }
}
