using EDCIS.Application.Utility.Constant;
using Microsoft.AspNetCore.Authorization;

namespace EDCIS.UI.Pages.EDCToSASConfigSetting
{
    public class EDCToSASConfigModel : PageModel
    {
        private readonly IMediator _mediator;

        [BindProperty]
        public EDCToSASConfig MainEntity { get; set; } = null!;

        public EDCToSASConfigModel(IMediator mediator)
        {
            _mediator = mediator;
        }

        public async Task<IActionResult> OnGetAsync()
        {
           var EDCToSASConfigDetails =  await _mediator.Send(new GetEDCSettingQuery());
           
            if(EDCToSASConfigDetails.Count> 0)
            {
                MainEntity = EDCToSASConfigDetails.Single();
            }
            return Page();
        }

        public async Task<ActionResult> OnPostCreate([Bind] EDCToSASConfig MainEntity)
        {
            this.MainEntity = MainEntity;
            if (MainEntity.HistoryPurgePeriod == null)
            {
                MainEntity.HistoryPurgePeriod = 0;
            }
            if (MainEntity.DestArchivePurgePeriod == null)
            {
                MainEntity.DestArchivePurgePeriod = 0;
            }
            if (ModelState.IsValid)
            {
                await _mediator.Send(new CreateEDCToSASConfigCommand(MainEntity));
                TempData["Message"] = MessagesConstants.SaveSuccessMessage;
            }
            return Page();
        }
        
    }
}
