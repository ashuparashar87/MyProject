using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EDCIS.UI.Pages.Maintenance
{
    public class MaintenanceModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
