
namespace EDCIS.UI.Pages.Resources
{
    public class ResourceModel : PageModel
    {
        private readonly ILogger _logger;
        private readonly IMediator _mediator;

        public Resource MainEntity { get; set; } = null!;
        public ResourceModel(ILogger<ResourceModel> logger, IMediator mediator)
        {
            _mediator = mediator;
            _logger = logger;
        }

        public async Task<IActionResult> OnGet(long key = 0)
        {
            if (key == 0)
            {
                return Page();
            }
            #nullable disable
            MainEntity = await _mediator.Send(new GetResourceByIdQuery(key));
            #nullable enable

            if (MainEntity == null)
            {
                _logger.LogError(string.Format("Record not found for id ", key));
                return NotFound();
            }
            return Page();
        }
    }
}
