using EDCIS.Application.ClientInfrastructure.Dtos;
using EDCIS.Application.Utility.Constant;
using EDCIS.Domain.Enum;
using Microsoft.AspNetCore.Authorization;
using static EDCIS.Application.Utility.Constant.MessagesConstants;

namespace EDCIS.UI.Pages.Resources
{
    public class ResourcesModel : PageModel
    {

        private readonly ILogger _logger;
        private readonly IMediator _mediator;
        private readonly UserGroupService _userGroupService;

        public ResourcesModel(ILogger<ResourceModel> logger, IMediator mediator, UserGroupService userGroupService)
        {
            _mediator = mediator;
            _logger = logger;
            _userGroupService = userGroupService;

        }

        public async Task<IActionResult> OnGetGridData(DataSourceLoadOptions loadOptions)
        {
            var resourceslist = await _mediator.Send(new GetResourceListCommandQuery());

            var resources = resourceslist.OrderBy(x => x.FirstName).ThenBy(x => x.LastName)
                .Select(c => new
                {
                    Id = c.Id,
                    FirstName = c.FirstName,
                    LastName = c.LastName,
                    EmailAddress = c.EmailAddress,
                    Role = Enum.GetName(c.Role),
                    IsActive = c.IsActive,
                    DaysSinceLogin = Convert.ToString(c.LastLoginAt != null ? (DateTime.UtcNow - c.LastLoginAt.Value).Days : string.Empty),
                    CreatedBy = c.CreatedBy,
                    CreatedDate = c.CreatedDate,
                    LastModifiedBy = c.LastModifiedBy,
                    LastModifiedDate = c.LastModifiedDate
                });
            return new JsonResult(DataSourceLoader.Load(resources, loadOptions));
        }
        public async Task<IActionResult> OnGetUsers()
        {
            var resources = await _mediator.Send(new GetResourceListCommandQuery());
            string role = string.Empty;
            var roles = new List<RoleList>();
            foreach (var resource in resources.Where(x => x.EmailAddress != "SystemUser@advancedgroup.com"))
            {
                var appUser = await _mediator.Send(new GetResourceByEmailIdQuery(resource.EmailAddress!));
                var adUserGroups = await _userGroupService.GetUserSecurityGroupsAsync(appUser?.EmailAddress);
                if (adUserGroups != null)
                {
                    foreach (var adRole in adUserGroups)
                    {
                        if (adRole == null) continue;
                        RoleList roleList = new RoleList();
                        if (adRole == SD.Admin)
                        {
                            role = nameof(ResourceRole.Admin);
                            roleList.Role = role;
                            roleList.Precedence = 1;
                            roles.Add(roleList);
                        }
                        if (adRole == SD.ITAdmin)
                        {
                            role = nameof(ResourceRole.ITAdmin);
                            roleList.Role = role;
                            roleList.Precedence = 2;
                            roles.Add(roleList);
                        }
                        if (adRole == SD.DataManager)
                        {
                            role = nameof(ResourceRole.DataManager);
                            roleList.Role = role;
                            roleList.Precedence = 3;
                            roles.Add(roleList);
                        }
                        if (adRole == SD.Statistician)
                        {
                            role = nameof(ResourceRole.Statistician);
                            roleList.Role = role;
                            roleList.Precedence = 4;
                            roles.Add(roleList);
                        }

                        else if (adRole == SD.ReadOnly)
                        {
                            role = nameof(ResourceRole.ReadOnly);
                            roleList.Role = role;
                            roleList.Precedence = 5;
                            roles.Add(roleList);
                        }
                    }
                }
                var userRole = roles.OrderBy(p => p.Precedence).FirstOrDefault();
                if (userRole != null && string.IsNullOrEmpty(userRole.Role))
                {
                    if (appUser != null)
                    {
                        appUser.IsActive = false;
                        await _mediator.Send(new UpdateResourceCommand(appUser));
                        return StatusCode(StatusCodes.Status202Accepted);
                    }
                }
            }
            await SyncAdUsersAsync();
            return StatusCode(StatusCodes.Status202Accepted);
        }

        private async Task SyncAdUsersAsync()
        {
            var resources = await _mediator.Send(new GetResourceListCommandQuery());
            var dbUserIds = resources.Where(x => x.EmailAddress != MessagesConstants.SystemUserEmail).Select(x => x.EmailAddress).ToList();
            foreach (var email in dbUserIds)
            {
                var adUsers = await _userGroupService.GetUsersFromAzureAd(email);
                if (adUsers == null)
                {
                    var usersToRemove = await _mediator.Send(new GetResourceByEmailIdQuery(email));
                    if (usersToRemove != null)
                    {
                        usersToRemove.IsActive = false;
                        await _mediator.Send(new UpdateResourceCommand(usersToRemove));
                    }
                }
            }
        }
    }
}

