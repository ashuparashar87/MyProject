using EDCIS.Application.Persistence;
using EDCIS.Application.Utility;
using EDCIS.Domain.Entities;
using EDCIS.Domain.Enum;
using EDCIS.UI.Model;
using EDCIS.UI.Pages.Configurations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace EDCIS.UI.Pages.Reports
{
    public class AutomationReportModel : PageModel
    {
        private readonly ILogger _logger;
        private readonly IMediator _mediator;
        private readonly IAsyncRepository<HistoryLog> _logRepository;
        private readonly IAsyncCTMS_RDBRepository<EDCISStudyView> _studyRepository;
        private readonly IAsyncRepository<Resource> _resourceRepository;

        public AutomaticReportResponse MainEntity { get; set; } = null!;

        public AutomationReportModel(ILogger<AutomationReportModel> logger, IMediator mediator, IAsyncRepository<HistoryLog> logRepository, IAsyncCTMS_RDBRepository<EDCISStudyView> studyRepository, IAsyncRepository<Resource> resourceRepository)
        {
            _mediator = mediator;
            _logger = logger;
            _logRepository = logRepository;
            _studyRepository = studyRepository;
            _resourceRepository = resourceRepository;
        }

        public async Task OnGetAsync()
        {

            var studyList = await _studyRepository.GetAllAsync();
            var studyListResponse = studyList.OrderBy(x => x.StudyID)
                  .Select(c => new
                  {
                      StudyID = c.StudyID,
                      StudyName = (c.StudyName + " " + c.ProtocolNumber)
                  });
            ViewData["StudyOption"] = new SelectList(studyListResponse?.OrderBy(x => x.StudyID), "StudyID", "StudyName");

            var resourceList = await _resourceRepository.GetAllAsync();
            ViewData["InitiatedByOption"] = new SelectList(resourceList?.OrderBy(x => x.FirstName), "EmailAddress", "FirstName");

        }

        public async Task<IActionResult> OnGetGridData(DataSourceLoadOptions loadOptions, DateTime? fromDate, DateTime? thruDate, string TimeZone, long studyId, string? initialBy, bool groupByStudy, bool groupByIntitate)
        {
            try
            {
                DateTime? FromDate = fromDate != null ? fromDate.Value.ShiftLocalToUtc(TimeZone) : null;
                DateTime? ThruDate = thruDate != null ? thruDate.Value.ShiftLocalToUtc(TimeZone) : null;
                var studyList = await _studyRepository.GetAllAsync();               
                List<AutomationReportResult> query;
                query = await _mediator.Send(new GetAutomationReportQuery(FromDate,ThruDate,studyId,initialBy,groupByStudy, groupByIntitate));
                var resourceList = await _resourceRepository.GetAllAsync();
                var automaticReportResponse = query?.GroupJoin(studyList, x => x.StudyID, y => y.StudyID,
                  (x, y) => new { x, y = y.DefaultIfEmpty() })
                 .SelectMany(c => c.y.Select(y => new AutomaticReportResponse()
                 {

                     StudyID = c.x?.StudyID,
                     StudyName = y?.StudyName,
                     CTMSProtocolNumber = y?.ProtocolNumber != null ? "" : y?.ProtocolNumber,
                     Month = c.x?.TimeStampMonth,
                     Year = c.x?.TimeStampYear,
                     InitiatedBy = c.x?.InitiatedBy,
                     NumberConfigsRun = c.x?.NumberConfigsRun,
                     NumberFilesTransferred = c.x?.NumberFilesTransferred,
                     NumberFilesUnzipped = c.x?.NumberFilesUnzipped,
                     NumberSasProgramsRun = c.x?.NumberSasProgramsRun,
                     NumberErrors = c.x?.NumberErrors
                 }));

                automaticReportResponse = automaticReportResponse?.GroupJoin(resourceList, x => x.InitiatedBy, y => y.EmailAddress,
                     (x, y) => new { x, y = y.DefaultIfEmpty() })
                 .SelectMany(c => c.y.Select(y => new AutomaticReportResponse()
                 {

                     StudyID = c.x?.StudyID,
                     StudyName = c.x?.StudyName,
                     CTMSProtocolNumber = c.x?.CTMSProtocolNumber,
                     Month = c.x?.Month,
                     Year = c.x?.Year,
                     InitiatedBy = y?.FirstName == null ? "Schedule" : y?.FirstName,
                     NumberConfigsRun = c.x?.NumberConfigsRun,
                     NumberFilesTransferred = c.x?.NumberFilesTransferred,
                     NumberFilesUnzipped = c.x?.NumberFilesUnzipped,
                     NumberSasProgramsRun = c.x?.NumberSasProgramsRun,
                     NumberErrors = c.x?.NumberErrors
                 }));
                return new JsonResult(DataSourceLoader.Load(automaticReportResponse, loadOptions));
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message + ex.InnerException?.Message);
            }
        }

        public async Task<IActionResult> OnGetGridDataOld(DataSourceLoadOptions loadOptions, DateTime? fromDate, DateTime? thruDate, string TimeZone, long studyId, string? initialBy,bool groupByStudy,bool groupByIntitate)
        {
            try
            {
                DateTime? FromDate = fromDate != null ? fromDate.Value.ShiftLocalToUtc(TimeZone) : null;
                DateTime? ThruDate = thruDate != null ? thruDate.Value.ShiftLocalToUtc(TimeZone) : null;
                var studyList = await _studyRepository.GetAllAsync();
                IEnumerable<HistoryLog> historyLogs;
                IEnumerable<AutomaticReportResponse> query;

                if (studyId != 0 && string.IsNullOrEmpty(initialBy) && initialBy == "All" && groupByStudy)
                {
                    historyLogs = await _mediator.Send(new GetHistoryLogsByStudyIdQuery(studyId, FromDate, ThruDate));
                    query = GroupByStudyId(historyLogs);

                }
                else if (!string.IsNullOrEmpty(initialBy) && initialBy != "All" && studyId == 0 && groupByIntitate)
                {
                    historyLogs = await _mediator.Send(new GetHistoryLogsByInitiateByQuery(initialBy, FromDate, ThruDate));
                    query = GroupByInitial(historyLogs);

                }
                else if (!string.IsNullOrEmpty(initialBy) && initialBy != "All" && studyId != 0 && groupByIntitate && groupByStudy)
                {
                    historyLogs = await _mediator.Send(new GetHistoryLogsByStudyIdInitiateByQuery(studyId, initialBy, FromDate, ThruDate));
                    query = GroupbyStudyintialBy(historyLogs);

                }
                else if (!string.IsNullOrEmpty(initialBy) && initialBy == "All" && studyId == 0)
                {
                    historyLogs = await _mediator.Send(new GetHistoryLogsQuery(FromDate, ThruDate));
                    if (groupByStudy && groupByIntitate)
                    {
                        query = GroupbyStudyintialBy(historyLogs);
                    }
                    else if (groupByStudy)
                    {
                        query = GroupByStudyId(historyLogs);
                    }
                    else if (groupByIntitate)
                    {
                        query = GroupByInitial(historyLogs);
                    }
                    else
                    {
                        query = GroupbyTimestamp(historyLogs);
                    }
                }
                else
                {
                    historyLogs = await _mediator.Send(new GetHistoryLogsQuery(FromDate, ThruDate));
                    query = GroupbyTimestamp(historyLogs);

                }

                var resourceList = await _resourceRepository.GetAllAsync();
                var automaticReportResponse = query?.GroupJoin(studyList, x => x.StudyID, y => y.StudyID,
                  (x, y) => new { x, y = y.DefaultIfEmpty() })
                 .SelectMany(c => c.y.Select(y => new AutomaticReportResponse()
                 {

                     StudyID = c.x.StudyID,
                     StudyName = y?.StudyName,
                     CTMSProtocolNumber = y?.ProtocolNumber != null ? "" : y?.ProtocolNumber,
                     Month = c.x.Month,
                     Year = c.x.Year,
                     InitiatedBy = c.x.InitiatedBy,
                     NumberConfigsRun = c.x.NumberConfigsRun,
                     NumberFilesTransferred = c.x.NumberFilesTransferred,
                     NumberFilesUnzipped = c.x.NumberFilesUnzipped,
                     NumberSasProgramsRun = c.x.NumberSasProgramsRun,
                     NumberErrors = c.x.NumberErrors
                 }));

                automaticReportResponse = automaticReportResponse?.GroupJoin(resourceList, x => x.InitiatedBy, y => y.EmailAddress,
                     (x, y) => new { x, y = y.DefaultIfEmpty() })
                 .SelectMany(c => c.y.Select(y => new AutomaticReportResponse()
                 {

                     StudyID = c.x.StudyID,
                     StudyName = c.x.StudyName,
                     CTMSProtocolNumber = c.x.CTMSProtocolNumber,
                     Month = c.x.Month,
                     Year = c.x.Year,
                     InitiatedBy = y?.FirstName==null? "Schedule": y?.FirstName,
                     NumberConfigsRun = c.x.NumberConfigsRun,
                     NumberFilesTransferred = c.x.NumberFilesTransferred,
                     NumberFilesUnzipped = c.x.NumberFilesUnzipped,
                     NumberSasProgramsRun = c.x.NumberSasProgramsRun,
                     NumberErrors = c.x.NumberErrors
                 }));
                return new JsonResult(DataSourceLoader.Load(automaticReportResponse, loadOptions));
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message + ex.InnerException?.Message);
            }
        }

        private static IEnumerable<AutomaticReportResponse> GroupbyTimestamp(IEnumerable<HistoryLog> historyLogs)
        {
            return from log in historyLogs
                   group log by new
                   {

                       log.TimeStamp.Date.Year,
                       log.TimeStamp.Date.Month,
                   } into g
                   orderby g.Max(x => x.TimeStamp) descending
                   select new AutomaticReportResponse
                   {
                       StudyID = null,
                       InitiatedBy = null,
                       Month = g.Key.Month,
                       Year = g.Key.Year,
                       NumberConfigsRun = g.Count(x => x.Process == ProcessType.SASAutomationStart),
                       NumberFilesTransferred = g.Count(x => x.Process == ProcessType.FileCopied),
                       NumberFilesUnzipped = g.Count(x => x.Process == ProcessType.FileUnzipSuccess),
                       NumberSasProgramsRun = g.Count(x => x.Process == ProcessType.SASProgramLaunched),
                       NumberErrors = g.Count(x => x.Process.ToString().Contains("Error"))
                   };
        }

        private static IEnumerable<AutomaticReportResponse> GroupbyStudyintialBy(IEnumerable<HistoryLog> historyLogs)
        {
            return from log in historyLogs
                   group log by new
                   {
                       log.StudyID,
                       log.TimeStamp.Date.Year,
                       log.TimeStamp.Date.Month,
                       log.InitiatedBy
                   } into g
                   orderby g.Max(x => x.TimeStamp) descending
                   select new AutomaticReportResponse
                   {
                       StudyID = g.Key.StudyID,
                       InitiatedBy = g.Key.InitiatedBy,
                       Month = g.Key.Month,
                       Year = g.Key.Year,
                       NumberConfigsRun = g.Count(x => x.Process == ProcessType.SASAutomationStart),
                       NumberFilesTransferred = g.Count(x => x.Process == ProcessType.FileCopied),
                       NumberFilesUnzipped = g.Count(x => x.Process == ProcessType.FileUnzipSuccess),
                       NumberSasProgramsRun = g.Count(x => x.Process == ProcessType.SASProgramLaunched),
                       NumberErrors = g.Count(x => x.Process.ToString().Contains("Error"))
                   };
        }

        private static IEnumerable<AutomaticReportResponse> GroupByInitial(IEnumerable<HistoryLog> historyLogs)
        {
            return from log in historyLogs
                   group log by new
                   {
                       log.TimeStamp.Date.Year,
                       log.TimeStamp.Date.Month,
                       log.InitiatedBy
                   } into g
                   orderby g.Max(x => x.TimeStamp) descending
                   select new AutomaticReportResponse
                   {
                       StudyID = null,
                       InitiatedBy = g.Key.InitiatedBy,
                       Month = g.Key.Month,
                       Year = g.Key.Year,
                       NumberConfigsRun = g.Count(x => x.Process == ProcessType.SASAutomationStart),
                       NumberFilesTransferred = g.Count(x => x.Process == ProcessType.FileCopied),
                       NumberFilesUnzipped = g.Count(x => x.Process == ProcessType.FileUnzipSuccess),
                       NumberSasProgramsRun = g.Count(x => x.Process == ProcessType.SASProgramLaunched),
                       NumberErrors = g.Count(x => x.Process.ToString().Contains("Error"))
                   };
        }

        private static IEnumerable<AutomaticReportResponse> GroupByStudyId(IEnumerable<HistoryLog> historyLogs)
        {
            return from log in historyLogs
                   group log by new
                   {
                       log.StudyID,
                       log.TimeStamp.Date.Year,
                       log.TimeStamp.Date.Month,

                   } into g
                   orderby g.Max(x => x.TimeStamp) descending
                   select new AutomaticReportResponse
                   {
                       StudyID = g.Key.StudyID,
                       InitiatedBy = null,
                       Month = g.Key.Month,
                       Year = g.Key.Year,
                       NumberConfigsRun = g.Count(x => x.Process == ProcessType.SASAutomationStart),
                       NumberFilesTransferred = g.Count(x => x.Process == ProcessType.FileCopied),
                       NumberFilesUnzipped = g.Count(x => x.Process == ProcessType.FileUnzipSuccess),
                       NumberSasProgramsRun = g.Count(x => x.Process == ProcessType.SASProgramLaunched),
                       NumberErrors = g.Count(x => x.Process.ToString().Contains("Error"))
                   };
        }
    }
}
