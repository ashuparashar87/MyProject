using EDCIS.Application.Client;
using EDCIS.Application.ClientInfrastructure.Dtos;
using EDCIS.Application.Configuration;
using EDCIS.Application.Interface;
using EDCIS.Application.Response;
using EDCIS.Application.Utility;
using EDCIS.Application.Utility.Constant;
using EDCIS.Domain.Enum;
using FluentFTP;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using System.Net;
using System.Net.Http.Headers;
using static Microsoft.Graph.Constants;

namespace EDCIS.UI.Pages.Home
{
    public class SASAutomationConfigModel : PageModel
    {
        private readonly IMediator _mediator;
        private readonly IConfiguration _configuration;
        private readonly ISASAgentService _agentService;
        private readonly IAuthorizationService _authorizationService;

        [BindProperty]
        public string? ReturnUrl { get; set; }
        [BindProperty]
        public ConfigurationTypeValue? ConfigurationType { get; set; }

        [BindProperty]
        public SASAutomationConfig MainEntity { get; set; } = null!;

        [BindProperty]
        public List<string>? WeekDaysList { get; set; }
        [BindProperty]
        public List<string> AreChecked { get; set; } = null!;
        public string? StudyName { get; set; }
        public string? Sponsor { get; set; }
        public string? StudyStatus { get; set; }
        public string? Protocol { get; set; }
        public string IsJobRunning { get; set; } = "0";
        [BindProperty]
        public bool IsEditRunAuthorized { get; set; }
        [BindProperty]
        public bool IsProgramAuthorized { get; set; }
        [BindProperty]
        public string IncomingTimezoneOffset { get; set; } = null!;

        public SASAutomationConfigModel(IMediator mediator, IConfiguration configuration, ISASAgentService agentService, IAuthorizationService authorizationService)
        {
            _mediator = mediator;
            _configuration = configuration;
            _agentService = agentService;
            _authorizationService = authorizationService;
        }
        private async Task<TitleDetails> GetTitle(long studyId)
        {
            var titleDetails = (await _mediator.Send(new GetTitleCommandQuery(studyId)));
            return titleDetails;
        }
        public async Task<IActionResult> OnGet(int key, long StudyId, bool IsParent, string timezoneDetail)
        {
            var isEditRunAuthorizationResult = await _authorizationService.AuthorizeAsync(User, "CanModifiedData");

            if (isEditRunAuthorizationResult.Succeeded)
            {
                IsEditRunAuthorized = true;
            }
            else
            {
                IsEditRunAuthorized = false;
            }
            IncomingTimezoneOffset = timezoneDetail;
            ReturnUrl = "/Home/Home";
            WeekDaysList = new List<string>(){"Monday","Tuesday","Wednesday",
                "Thursday","Friday","Saturday","Sunday"};
            GetTimeIntervals();
            var titleDetails = await GetTitle(StudyId);
            StudyName = titleDetails.StudyName;
            Protocol = titleDetails.ProtocolNumber;
            Sponsor = titleDetails.SponsorName;
            StudyStatus = titleDetails.StudyStatus;
            var configlist = await _mediator.Send(new GetEDCISConfigurationListQuery());
            if (IsParent == true)
            {
                if (MainEntity == null)
                {
                    MainEntity = new SASAutomationConfig();
                    MainEntity.StudyID = StudyId;
                    MainEntity.IsEDCActive = true;
                    MainEntity.IsDaily = true;
                    MainEntity.TimeIntervalList = new SelectList(GetTimeIntervals(), "2:00 AM");
                    MainEntity.EDCSASAgentURL = _configuration["EdcSasAgent:EdcSasAgentUrl"];
                    MainEntity.ConfigurationType = ConfigurationTypeValue.FileTransfer;
                    ConfigurationType = MainEntity.ConfigurationType;
                    MainEntity.Arguments = configlist.Where(x => x.Key == "SASProgramArguments").Select(x => x.Value).FirstOrDefault();
                    MainEntity.File = configlist.Where(x => x.Key == "SASProgramFile").Select(x => x.Value).FirstOrDefault();
                    MainEntity.TimeoutInSeconds = configlist.Where(x => x.Key == "SASProgramTimeout").Select(x => Convert.ToInt16(x.Value)).FirstOrDefault();
                }
            }
            else
            {
                MainEntity = await _mediator.Send(new GetSASAutomationConfigByIdQuery(key));
                if (MainEntity != null)
                {
                    var currentUtcDateTime = DateTime.UtcNow.AddMinutes(Convert.ToDouble(IncomingTimezoneOffset));
                    var utcDate = currentUtcDateTime.ToString("dd-MMM-yyyy") + " " + MainEntity.TimeSlot;
                    var utcTimeSlot = Convert.ToDateTime(utcDate);
                    var utcToLocalDateTime = utcTimeSlot.ShiftUtcToLocal(IncomingTimezoneOffset);
                    var localTime = utcToLocalDateTime.ToString("t");
                    MainEntity.TimeSlot = localTime;
                    MainEntity.EDCSASAgentURL = _configuration["EdcSasAgent:EdcSasAgentUrl"];
                    MainEntity.TimeIntervalList = new SelectList(GetTimeIntervals(), MainEntity.TimeSlot);
                    MainEntity.TransferDateString = MainEntity.TransferDate.ShiftUtcToLocal(IncomingTimezoneOffset)?.ToString("dd-MMM-yyyy hh:mm:ss tt");
                    var config = (await _mediator.Send(new GetEDCISConfigurationByKeyQuery("IsSASAutomationJobRunning"))).SingleOrDefault();
                    IsJobRunning = config?.Value != null ? config.Value : "0";
                    MainEntity.ConfigurationType = MainEntity.ConfigurationType == null ? ConfigurationTypeValue.FileTransfer : MainEntity.ConfigurationType;
                    ConfigurationType = MainEntity.ConfigurationType;
                    MainEntity.Arguments = configlist.Where(x => x.Key == "SASProgramArguments").Select(x => x.Value).FirstOrDefault();
                    MainEntity.File = configlist.Where(x => x.Key == "SASProgramFile").Select(x => x.Value).FirstOrDefault();
                    MainEntity.TimeoutInSeconds = configlist.Where(x => x.Key == "SASProgramTimeout").Select(x => Convert.ToInt16(x.Value)).FirstOrDefault();
                    var isCanProgramAuthorizationResult = await _authorizationService.AuthorizeAsync(User, "CanProgramAutomation");

                    if (isCanProgramAuthorizationResult.Succeeded && (MainEntity.CanRunStatistician || MainEntity.CanDMRUN))
                    {
                        IsProgramAuthorized = true;
                    }
                    else
                    {
                        IsProgramAuthorized = false;
                    }
                    if (!(string.IsNullOrEmpty(MainEntity.WeekDays)))
                    {
                        MainEntity.IsWeekly = true;
                        MainEntity.IsDaily = false;
                    }
                }
                else
                {
                    MainEntity = new SASAutomationConfig();
                    MainEntity.StudyID = StudyId;
                    MainEntity.IsEDCActive = true;
                    MainEntity.IsDaily = true;
                    MainEntity.TimeIntervalList = new SelectList(GetTimeIntervals(), "2:00 AM");
                    MainEntity.EDCSASAgentURL = _configuration["EdcSasAgent:EdcSasAgentUrl"];
                    MainEntity.ConfigurationType = ConfigurationTypeValue.FileTransfer;
                    ConfigurationType = MainEntity.ConfigurationType;
                    MainEntity.Arguments = configlist.Where(x => x.Key == "SASProgramArguments").Select(x => x.Value).FirstOrDefault();
                    MainEntity.File = configlist.Where(x => x.Key == "SASProgramFile").Select(x => x.Value).FirstOrDefault();
                    MainEntity.TimeoutInSeconds = configlist.Where(x => x.Key == "SASProgramTimeout").Select(x => Convert.ToInt16(x.Value)).FirstOrDefault();
                }
            }
            return Page();
        }

        public async Task<IActionResult> OnGetEDCSiteGridData(DataSourceLoadOptions loadOptions)
        {
            var ftpSites = (await _mediator.Send(new GetFTPSiteConfigQuery()));
            var ftpDetails = ftpSites.OrderBy(x => x.FTPSite)
               .Select(c => new
               {
                   FTPSite = c.FTPSite,
                   HostName = c.HostName,
                   FileProtocol = Enum.GetName(c.FileProtocol),
                   Encryption = Enum.GetName(c.Encryption),
                   PortNumber = c.PortNumber,
                   UserName = c.UserName,
               });
            return new JsonResult(DataSourceLoader.Load(ftpDetails, loadOptions));
        }


        public async Task<ActionResult> OnPostCreate([Bind] SASAutomationConfig MainEntity)
        {
            var titleDetails = await GetTitle(MainEntity.StudyID);
            if (titleDetails != null)
            {
                StudyName = titleDetails.StudyName;
                Protocol = titleDetails.ProtocolNumber;
                Sponsor = titleDetails.SponsorName;
                StudyStatus = titleDetails.StudyStatus;
            }
            this.MainEntity = MainEntity;
            WeekDaysList = new List<string>(){"Monday","Tuesday","Wednesday",
                "Thursday","Friday","Saturday","Sunday"};
            MainEntity.TimeIntervalList = new SelectList(GetTimeIntervals());
            MainEntity.ConfigurationType = this.ConfigurationType;

            if (MainEntity.IsWeekly == true && AreChecked.ToArray().Count() == 0)
            {
                ModelState.AddModelError("MainEntity.IsWeekly", "Please select at least one weekday.");
                return Page();
            }

            if (ModelState.IsValid)
            {
                if (MainEntity.ConfigName == null)
                {
                    ModelState.AddModelError("MainEntity.ConfigName", "Config Name is required.");
                    return Page();
                }

                if (MainEntity.ConfigurationType == ConfigurationTypeValue.FileTransfer)
                {
                    if (MainEntity.SourceFileName == null)
                    {
                        ModelState.AddModelError("MainEntity.SourceFileName", "Source File Name  is required.");
                        return Page();
                    }
                    if (!Path.HasExtension(MainEntity.SourceFileName))
                    {
                        ModelState.AddModelError("MainEntity.SourceFileName", "FileName extension is required.");
                        return Page();
                    }
                    if (MainEntity.SourceFolderPath == null)
                    {
                        ModelState.AddModelError("MainEntity.SourceFolderPath", "Source Folder Path  is required.");
                        return Page();
                    }

                    if (MainEntity.SourceFTPSite == "Select a value...")
                    {
                        ModelState.AddModelError("MainEntity.SourceFTPSite", "FTP Site is required.");
                        return Page();
                    }

                    if (MainEntity.DestFTPSite == "Select a value...")
                    {
                        ModelState.AddModelError("MainEntity.DestFTPSite", "FTP Site is required.");
                        return Page();
                    }
                    if (MainEntity.ArchiveDestFolderPath == null)
                    {
                        ModelState.AddModelError("MainEntity.ArchiveDestFolderPath", "Archive Destibation Folder Path  is required.");
                        return Page();
                    }
                    if (MainEntity.CurrentDestFolderPath == null)
                    {
                        ModelState.AddModelError("MainEntity.CurrentDestFolderPath", "Current Destination Folder Path  is required.");
                        return Page();
                    }
                    CreateFTPFullPath(MainEntity);
                }
                else
                {
                    if (MainEntity.File == null)
                    {
                        ModelState.AddModelError("MainEntity.File", "SAS Executable File is required.");
                        return Page();
                    }
                    if (MainEntity.Description == null)
                    {
                        ModelState.AddModelError("MainEntity.Description", "Description is required.");
                        return Page();
                    }
                    MainEntity.SourcePortNumber = 0;
                    MainEntity.DestPortNumber = 0;
                    MainEntity.SourceEncryption = EncryptionMode.None;
                    MainEntity.DestEncryption = EncryptionMode.None;
                    MainEntity.SourceFileProtocol = FileProtocol.None;
                    MainEntity.DestFileProtocol = FileProtocol.None;
                }
                MainEntity.WeekDays = string.Join(",", AreChecked.ToArray());
                try
                {

                    var currentUtcDateTime = DateTime.UtcNow.AddMinutes(Convert.ToDouble(IncomingTimezoneOffset));
                    var utcDate = currentUtcDateTime.ToString("dd-MMM-yyyy") + " " + MainEntity.TimeSlot;
                    var utcTimeSlot = Convert.ToDateTime(utcDate);
                    var localToUtcDateTime = utcTimeSlot.ShiftLocalToUtc(IncomingTimezoneOffset);
                    var utcTime = localToUtcDateTime.ToString("t");
                    MainEntity.TimeSlot = utcTime;
                    MainEntity.IsErrorInLastExecution = false;
                    await _mediator.Send(new CreateSASAutomationConfigCommand(MainEntity));
                    TempData["IsSucess"] = "true";
                    string url = "/Home/SASAutomationConfig?key=" + MainEntity.Id + "&StudyId=" + MainEntity.StudyID + "&IsParent=false" + "&timezoneDetail=" + IncomingTimezoneOffset;
                    return new JsonResult(new ReturnResponse { Message = url, IsSuccess = true });
                }
                catch (Exception ex)
                {
                    if (ex.InnerException is SqlException sqlex)
                    {
                        if (sqlex.Number == 2601)
                        {
                            ModelState.AddModelError("MainEntity.ConfigName", MessagesConstants.DuplicateErrorMsgSASConfig);
                            TempData["ErrorMessage"] = MessagesConstants.DuplicateErrorMsgSASConfig;
                            string url1 = "/Home/SASAutomationConfig?key=" + MainEntity.Id + "&StudyId=" + MainEntity.StudyID + "&IsParent=false" + "&timezoneDetail=" + IncomingTimezoneOffset;
                            return new JsonResult(new ReturnResponse { Message = url1, IsSuccess = false });
                        }
                        else
                        {
                            TempData["ErrorMessage"] = ex.InnerException.Message;
                        }
                    }
                    else
                    {
                        TempData["ErrorMessage"] = ex.Message;
                    }
                    string url = "/Home/SASAutomationConfig?key=" + MainEntity.Id + "&StudyId=" + MainEntity.StudyID + "&IsParent=false" + "&timezoneDetail=" + IncomingTimezoneOffset;
                    return new JsonResult(new ReturnResponse { Message = url, IsSuccess = false });

                }
            }

            return Page();
        }

        private static void CreateFTPFullPath(SASAutomationConfig MainEntity)
        {
            if (MainEntity.ConfigurationType == ConfigurationTypeValue.FileTransfer)
            {
                MainEntity.SourceFolderPath = MainEntity.SourceFolderPath == null ? "" : MainEntity.SourceFolderPath.Trim();
                MainEntity.ArchiveDestFolderPath = MainEntity.ArchiveDestFolderPath == null ? "" : MainEntity.ArchiveDestFolderPath.Trim();
                MainEntity.CurrentDestFolderPath = MainEntity.CurrentDestFolderPath == null ? "" : MainEntity.CurrentDestFolderPath.Trim();

                if (!MainEntity.SourceFolderPath.StartsWith("/"))
                {
                    MainEntity.SourceFolderPath = "/" + MainEntity.SourceFolderPath;
                }
                if (!MainEntity.SourceFolderPath.EndsWith("/"))
                {
                    MainEntity.SourceFolderPath = MainEntity.SourceFolderPath + "/";
                }
                if (!MainEntity.ArchiveDestFolderPath.StartsWith("/"))
                {
                    MainEntity.ArchiveDestFolderPath = "/" + MainEntity.ArchiveDestFolderPath;
                }
                if (!MainEntity.ArchiveDestFolderPath.EndsWith("/"))
                {
                    MainEntity.ArchiveDestFolderPath = MainEntity.ArchiveDestFolderPath + "/";
                }
                if (!MainEntity.CurrentDestFolderPath.StartsWith("/"))
                {
                    MainEntity.CurrentDestFolderPath = "/" + MainEntity.CurrentDestFolderPath;
                }
                if (!MainEntity.CurrentDestFolderPath.EndsWith("/"))
                {
                    MainEntity.CurrentDestFolderPath = MainEntity.CurrentDestFolderPath + "/";
                }
            }
        }

        public List<string> GetTimeIntervals()
        {
            List<string> timeIntervals = new List<string>();
            TimeSpan startTime = new TimeSpan(0, 0, 0);
            DateTime startDate = new DateTime(DateTime.MinValue.Ticks); // Date to be used to get shortTime format.
            for (int i = 0; i < 48; i++)
            {
                int minutesToBeAdded = 30 * i;      // Increasing minutes by 30 minutes interval
                TimeSpan timeToBeAdded = new TimeSpan(0, minutesToBeAdded, 0);
                TimeSpan t = startTime.Add(timeToBeAdded);
                DateTime result = startDate + t;
                timeIntervals.Add(result.ToShortTimeString());      // Use Date.ToShortTimeString() method to get the desired format
            }
            return timeIntervals;
        }



        public async Task<IActionResult> OnPostSourceTestConnection(string ftpSite, string folderPath)
        {

            var FTPSourceDetails = await _mediator.Send(new GetFTPSiteConfigQueryByFTPSiteQuery(ftpSite));
            var sourceConnResponse = SourceTestConnection(FTPSourceDetails, folderPath);
            return new JsonResult(new ReturnResponse { Message = sourceConnResponse.message, IsSuccess = sourceConnResponse.isSuccess });
        }
        public async Task<IActionResult> OnPostVerifyConfigName(string configName)
        {
            try
            {
                MainEntity = await _mediator.Send(new GetSASAutomationConfigByNameQuery(configName));
                if (MainEntity != null)
                {
                    return new JsonResult(new ReturnResponse { Message = MessagesConstants.DuplicateErrorMsgSASConfig, IsSuccess = false });
                }
                else
                {
                    return new JsonResult(new ReturnResponse { Message = "", IsSuccess = true });
                }
            }
            catch (Exception ex)
            {
                if (ex.InnerException is SqlException sqlex)
                {
                    if (sqlex.Number == 2601)
                    {
                        return new JsonResult(new ReturnResponse { Message = MessagesConstants.DuplicateErrorMsgSASConfig, IsSuccess = false });
                    }
                    else
                    {

                        return new JsonResult(new ReturnResponse { Message = ex.InnerException.Message, IsSuccess = false });
                    }
                }
                else
                {
                    return new JsonResult(new ReturnResponse { Message = ex.Message, IsSuccess = false });
                }
            }
        }
        public async Task<IActionResult> OnPostSASTestConnection(string url)
        {
            bool isSuccess = false;
            string message = string.Empty;
            try
            {
                var response = await _agentService.PingAgentService();
                if (response.IsSuccessStatusCode)
                {
                    isSuccess = true;
                    message = "Success!";
                }
            }

            catch (Exception ex)
            {
                isSuccess = false;
                message = ex.Message;
            }
            return new JsonResult(new ReturnResponse { Message = message, IsSuccess = isSuccess });
        }
        public async Task<IActionResult> OnPostRunAgentService(int Id, string args, string description, string File, string Path, int timeout)
        {
            MainEntity = await _mediator.Send(new GetSASAutomationConfigByIdQuery(Id));
            if (MainEntity != null)
            {
                MainEntity.Arguments = args;
                MainEntity.Description = description;
                MainEntity.File = File;
                MainEntity.Path = Path;
                MainEntity.TimeoutInSeconds = timeout;
                await _mediator.Send(new UpdateSASConfigCommand(MainEntity));

            }
            bool isSuccess = false;
            string message = string.Empty;
            string logFile = string.Empty;
            try
            {
                string? tempPath = System.IO.Path.GetDirectoryName(Path);
                AgentCommand agentCommand = new AgentCommand()
                {
                    Args = args.Replace("{0}", Path),
                    Description = description,
                    File = File,
                    Path = tempPath ?? string.Empty,
                    Timeout = timeout

                };
                var response = await _agentService.RunAgentService(agentCommand);
                if (response.LaunchSuccess)
                {
                    isSuccess = true;
                    message = response.Message;
                    logFile = response.LogFile;
                }
                else
                {
                    isSuccess = false;
                    message = response.Message;
                    logFile = response.LogFile;
                }
            }

            catch (Exception ex)
            {
                isSuccess = false;
                message = ex.Message;
            }
            return new JsonResult(new ReturnResponse { Message = message, LogFile = logFile, IsSuccess = isSuccess });
        }

        public async Task<IActionResult> OnPostWebJobAsync([Bind] SASAutomationConfig MainEntity)
        {
            this.MainEntity = MainEntity;
            MainEntity.ConfigurationType = ConfigurationType;
            string url = "/Home/SASAutomationConfig" + "?key=" + MainEntity.Id + "&StudyId=" + MainEntity.StudyID + "&IsParent=false" + "&timezoneDetail=" + IncomingTimezoneOffset;
            WeekDaysList = new List<string>(){"Monday","Tuesday","Wednesday",
                "Thursday","Friday","Saturday","Sunday"};
            MainEntity.TimeIntervalList = new SelectList(GetTimeIntervals());
            if (MainEntity.IsWeekly == true && AreChecked.ToArray().Count() == 0)
            {
                ModelState.AddModelError("MainEntity.IsWeekly", "Please select at least one weekday.");
            }
            if (MainEntity.ConfigName == null)
            {
                ModelState.AddModelError("MainEntity.ConfigName", "Config Name is required.");
            }

            if (MainEntity.ConfigurationType == ConfigurationTypeValue.FileTransfer)
            {
                Validate(MainEntity);
            }
            if (ModelState.IsValid)
            {
                try
                {

                    if (MainEntity.ConfigurationType == ConfigurationTypeValue.FileTransfer)
                    {
                        CreateFTPFullPath(MainEntity);
                    }
                    var currentUtcDateTime = DateTime.UtcNow.AddMinutes(Convert.ToDouble(IncomingTimezoneOffset));
                    var utcDate = currentUtcDateTime.ToString("dd-MMM-yyyy") + " " + MainEntity.TimeSlot;
                    var utcTimeSlot = Convert.ToDateTime(utcDate);
                    var localToUtcDateTime = utcTimeSlot.ShiftLocalToUtc(IncomingTimezoneOffset);
                    var utcTime = localToUtcDateTime.ToString("t");
                    MainEntity.TimeSlot = utcTime;
                    MainEntity.IsErrorInLastExecution = false;
                    await _mediator.Send(new CreateSASAutomationConfigCommand(MainEntity));
                    //job run
                    await _mediator.Send(new ExecuteSASAutomationWebJobCommand(MainEntity.Id));
                    var response = await _mediator.Send(new ExecuteSASAutomationWebJobCommand(MainEntity.Id));
                    bool success = response.IsSuccess;
                    string? msg = response?.Message;
                    return new JsonResult(new { IsSuccess = success, Message = msg, RedirectUrl = url });
                    //return new JsonResult(new { IsSuccess = true, Message = "SAS Program Is Successfully Launched!", RedirectUrl = url });
                }
                catch (Exception ex)
                {
                    if (ex.InnerException is SqlException sqlex)
                    {
                        if (sqlex.Number == 2601)
                        {
                            return new JsonResult(new { IsSuccess = false, modelError = "", Message = MessagesConstants.DuplicateErrorMsgSASConfig });
                        }
                    }
                    return new JsonResult(new { IsSuccess = false, modelError = "", Message = "Error while Running SAS Automation Web Job. " + ex.Message, RedirectUrl = url });
                }
            }

            var error = ModelState.ToList().Where(x => x.Value?.ValidationState == Microsoft.AspNetCore.Mvc.ModelBinding.ModelValidationState.Invalid);
            Dictionary<string, string> modelError = new Dictionary<string, string>();
            if (error.Any())
            {
                foreach (var item in error)
                {
                    var errorMessage = item.Value?.Errors?.FirstOrDefault()?.ErrorMessage;
                    if (errorMessage != null)
                    {
                        modelError.Add(item.Key, errorMessage);
                    }
                }
            }

            return new JsonResult(new { IsSuccess = false, modelError = modelError, RedirectUrl = url });

        }

        private void Validate(SASAutomationConfig MainEntity)
        {

            if (MainEntity.SourceFileName == null)
            {
                ModelState.AddModelError("MainEntity.SourceFileName", "Source File Name  is required.");
            }

            if (!Path.HasExtension(MainEntity.SourceFileName))
            {
                ModelState.AddModelError("MainEntity.SourceFileName", "FileName extension is required.");
            }
            if (MainEntity.SourceFolderPath == null)
            {
                ModelState.AddModelError("MainEntity.SourceFolderPath", "Source Folder Path  is required.");
            }

            if (MainEntity.SourceFTPSite == "Select a value...")
            {
                ModelState.AddModelError("MainEntity.SourceFTPSite", "FTP Site is required.");
            }

            if (MainEntity.DestFTPSite == "Select a value...")
            {
                ModelState.AddModelError("MainEntity.DestFTPSite", "FTP Site is required.");
            }
            if (MainEntity.ArchiveDestFolderPath == null)
            {
                ModelState.AddModelError("MainEntity.ArchiveDestFolderPath", "Archive Destibation Folder Path  is required.");
            }
            if (MainEntity.CurrentDestFolderPath == null)
            {
                ModelState.AddModelError("MainEntity.CurrentDestFolderPath", "Current Destination Folder Path  is required.");
            }
        }

        public async Task<IActionResult> OnPostWebJobAsync1()
        {
            var getResponse = await GetWebJobAsync();
            if (getResponse != null)
            {
                dynamic? jsonStatus = JsonConvert.DeserializeObject(getResponse);
                if (jsonStatus?.latest_run != null)
                {
                    var jobStatus = jsonStatus.latest_run.status;
                }
            }
            string apiUrl = SD.SASAutomationWebJobUrl;
            // string ApiUrl = "https://edcis-dev.scm.azurewebsites.net/api/";
            string call = "triggeredwebjobs/SASAutomationWebJob/run";
            string result = string.Empty;
            //var userPswd = $"{"$edcis-dev"}:{"aewtiA5EfXjJ7fxgyt3Ty3iK4ZRr3pbRKY9nrwopMEK1wylb31lhpXtLFe24"}";
            var userPswd = $"{SD.SASAutomationWebJobUserName}:{SD.SASAutomationWebJobPassword}";
            userPswd = Convert.ToBase64String(System.Text.ASCIIEncoding.UTF8.GetBytes(userPswd));
            var response = new HttpResponseMessage(HttpStatusCode.NotFound);
            try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(apiUrl);
                    client.Timeout = TimeSpan.FromMinutes(30);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", userPswd);
                    response = await client.PostAsync(call, new StringContent(string.Empty, System.Text.Encoding.UTF8, "application/json"));
                }
                return new JsonResult(new ReturnResponse { IsSuccess = response.IsSuccessStatusCode });
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message + ex.InnerException?.Message);
            }
        }
        private async Task<string> GetWebJobAsync()
        {
            //string apiUrl = "https://edcis-dev.scm.azurewebsites.net/api/triggeredwebjobs/SASAutomationWebJob";
            string apiUrl = SD.SASAutomationWebJobUrl;
            string call = "triggeredwebjobs/SASAutomationWebJob";
            string baseURL = string.Format("{0}", call);
            //var userPswd = $"{"$edcis-dev"}:{"aewtiA5EfXjJ7fxgyt3Ty3iK4ZRr3pbRKY9nrwopMEK1wylb31lhpXtLFe24"}";
            var userPswd = $"{SD.SASAutomationWebJobUserName}:{SD.SASAutomationWebJobPassword}";
            userPswd = Convert.ToBase64String(System.Text.ASCIIEncoding.UTF8.GetBytes(userPswd));
            string result = string.Empty;

            try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(apiUrl);
                    client.Timeout = TimeSpan.FromMinutes(30);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", userPswd);
                    var response = new HttpResponseMessage();
                    response = await client.GetAsync(baseURL);
                    result = response.IsSuccessStatusCode ? (response.Content.ReadAsStringAsync().Result) : response.IsSuccessStatusCode.ToString();
                    return result;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message + ex.InnerException?.Message);

            }
        }
        public async Task<IActionResult> OnPostDestinationTestConnection(string ftpSite, string archiveDestFolderPath, string destUnZippedFolderPath)
        {
            var FTPSourceDetails = await _mediator.Send(new GetFTPSiteConfigQueryByFTPSiteQuery(ftpSite));
            var DestConnResponse = DestTestConnection(FTPSourceDetails, archiveDestFolderPath, destUnZippedFolderPath);
            return new JsonResult(new ReturnResponse { Message = DestConnResponse.message, IsSuccess = DestConnResponse.isSuccess });

        }

        private (string message, bool isSuccess) SourceTestConnection(FTPSiteConfig model, string folderPath)
        {
            bool isSuccess = false;
            string message = string.Empty;
            try
            {
                RemoteSystemSetting setting = new RemoteSystemSetting()
                {
                    Host = model.HostName,
                    Port = model.PortNumber,
                    UserName = model.UserName,
                    Password = model.Password,
                    Type = model.FileProtocol.ToString(),
                    Encryption = model.Encryption.ToString(),
                };

                IRemoteFileSystemContext remote;
                if (setting.Type == FileProtocol.FTP.ToString())
                {
                    remote = new FtpRemoteFileSystem(setting);
                }
                else
                {
                    remote = new SftpRemoteFileSystem(setting);
                }
                remote.Connect();
                bool isConnected = remote.IsConnected();
                if (isConnected)
                {
                    var IsDirectoryExists = remote.DirectoryExists(folderPath);
                    if (IsDirectoryExists)
                    {
                        message = MessagesConstants.UISourceConnectedSuccessMessage(model.HostName, folderPath);
                        isSuccess = true;
                    }
                    else
                    {
                        message = MessagesConstants.UISourceConnectedFailureMessage(model.HostName, folderPath);
                        isSuccess = false;
                    }

                }
                remote.Disconnect();
                remote.Dispose();
                return (message, isSuccess);
            }
            catch (Exception ex)
            {
                isSuccess = false;
                message = ex.Message;
                return (message, isSuccess);
            }
        }

        private (string message, bool isSuccess) DestTestConnection(FTPSiteConfig model, string folderPath, string UnZippedFolderPath)
        {
            bool isSuccess = false;
            string message = string.Empty;
            try
            {
                RemoteSystemSetting setting = new RemoteSystemSetting()
                {
                    Host = model.HostName,
                    Port = model.PortNumber,
                    UserName = model.UserName,
                    Password = model.Password,
                    Type = model.FileProtocol.ToString(),
                    Encryption = model.Encryption.ToString()
                };

                IRemoteFileSystemContext remote;
                if (setting.Type == FileProtocol.FTP.ToString())
                {
                    remote = new FtpRemoteFileSystem(setting);
                }
                else
                {
                    remote = new SftpRemoteFileSystem(setting);
                }
                remote.Connect();
                bool isConnected = remote.IsConnected();
                if (isConnected)
                {
                    var IsDirectoryExists = remote.DirectoryExists(folderPath);
                    if (IsDirectoryExists)
                    {
                        if (!string.IsNullOrEmpty(UnZippedFolderPath))
                        {
                            var isUnzipDirectoryExists = remote.DirectoryExists(UnZippedFolderPath);
                            if (isUnzipDirectoryExists)
                            {
                                message = MessagesConstants.UIDestConnectedSuccessMessage(model.HostName, folderPath, UnZippedFolderPath);
                                isSuccess = true;
                            }
                            else
                            {
                                message = MessagesConstants.UIDestConnectedFailureMessage(model.HostName, folderPath, UnZippedFolderPath);
                                isSuccess = false;
                            }
                        }
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(UnZippedFolderPath))
                        {
                            var isUnzipDirectoryExists = remote.DirectoryExists(UnZippedFolderPath);
                            if (isUnzipDirectoryExists)
                            {
                                message = MessagesConstants.UIDestConnectedArchiveFailureMessage(model.HostName, folderPath, UnZippedFolderPath);
                                isSuccess = false;
                            }
                            else
                            {
                                message = MessagesConstants.UIArchieveDestConnectedFailureMessage(model.HostName, folderPath, UnZippedFolderPath);
                                isSuccess = false;
                            }
                        }
                    }
                }
                remote.Disconnect();
                remote.Dispose();
                return (message, isSuccess);
            }
            catch (Exception ex)
            {
                isSuccess = false;
                message = ex.Message + ex.InnerException?.Message;
                return (message, isSuccess);
            }
        }

    }
}

