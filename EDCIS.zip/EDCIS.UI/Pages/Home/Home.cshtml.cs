using EDCIS.Application.Utility;
using Microsoft.AspNetCore.Authorization;
using System;

namespace EDCIS.UI.Pages.Home
{
    [IgnoreAntiforgeryToken]
    public class HomeModel : PageModel
    {
        private readonly ILogger _logger;
        private readonly IMediator _mediator;
        private readonly IAuthorizationService _authorizationService;
        [BindProperty]
        public bool IsEditRunAuthorized { get; set; }
        [BindProperty]
        public int HasErrorCount { get; set; }
        [BindProperty]

#  nullable disable
        public string Study_Filter_Id
        {
            get { string val = TempData["StudyFilId"].ToString(); TempData.Keep("StudyFilId"); return val; }
            set { TempData["StudyFilId"] = value; }
        }

#nullable enable
        public HomeModel(ILogger<HomeModel> logger, IMediator mediator, IAuthorizationService authorizationService)
        {
            _logger = logger;
            _mediator = mediator;
            _authorizationService = authorizationService;
        }
        public async Task<IActionResult> OnGet(long studyId)
        {
            var isCanProgramAuthorizationResult = await _authorizationService.AuthorizeAsync(User, "CanModifiedData");
            HasErrorCount = 0;
            var edcDetails = (await _mediator.Send(new GetSASAutomationConfigByStudyIdQuery(0)));
            var edcDetail = edcDetails.OrderBy(x => x.Id)
             .Select(c => new SASAutomationConfigDto
             {                
                 IsEDCActive = c?.IsEDCActive == null ? false : c.IsEDCActive,                
                 HasError = !string.IsNullOrEmpty(c?.LastError) ? true : false                 
             });
            this.HasErrorCount = edcDetail.Count(x => x.HasError == true && x.IsEDCActive == true);
            if (isCanProgramAuthorizationResult.Succeeded)
            {
                IsEditRunAuthorized = true;
            }
            else
            {
                IsEditRunAuthorized = false;
            }
            Study_Filter_Id = studyId.ToString();
            return Page();
        }

        public async Task<IActionResult> OnGetGridData(DataSourceLoadOptions loadOptions,int notificationBell)
        {
            try { 
            var studies = (await _mediator.Send(new GetStudyListCommandQuery())).OrderBy(x => x.StudyID).ToList();
            if (!string.IsNullOrEmpty(Study_Filter_Id) && Study_Filter_Id != "0")
            {
                studies = studies.Where(x => x.StudyID == Study_Filter_Id).ToList();                
            }     
            
            if(notificationBell>0)
            {
                var edcDetails = (await _mediator.Send(new GetSASAutomationConfigByStudyIdQuery(0)));
                var edcDetailWithError = edcDetails.Select(x => x.StudyID.ToString()).ToList();
                var   studies1 = studies.Join(edcDetailWithError, x => x.StudyID, y => y, (x, y) => new StudyListVm()
                {
                    StudyID = x.StudyID,
                    StudyName = x.StudyName,
                    ProtocolNumber = x.ProtocolNumber,
                    StudyStatus = x.StudyStatus,
                    SponsorName = x.SponsorName,
                    TherapeuticArea = x.TherapeuticArea,
                    Indication = x.Indication,
                    SASAutomation = x.SASAutomation ,
                    HasError = true
                });
                return new JsonResult(DataSourceLoader.Load(studies1.OrderByDescending(x => x.StudyID), loadOptions));
            }
            return new JsonResult(DataSourceLoader.Load(studies.OrderByDescending(x => x.StudyID), loadOptions));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message + " " + ex.InnerException);
                return StatusCode(500, ex.Message + " " + ex.InnerException);
            }
        }

        public async Task<IActionResult> OnGetGridSASAutomationConfiguration(DataSourceLoadOptions loadOptions, long StudyId, string timeZone)
        {
            var configlist = await _mediator.Send(new GetEDCISConfigurationListQuery());
            var Arguments = configlist.Where(x => x.Key == "SASProgramArguments").Select(x => x.Value).FirstOrDefault();
            var File = configlist.Where(x => x.Key == "SASProgramFile").Select(x => x.Value).FirstOrDefault();
            var TimeoutInSeconds = configlist.Where(x => x.Key == "SASProgramTimeout").Select(x => Convert.ToInt16(x.Value)).FirstOrDefault();
            var edcDetails = (await _mediator.Send(new GetSASAutomationConfigByStudyIdQuery(StudyId)));
            var edcDetail = edcDetails.OrderBy(x => x.Id)
             .Select(c => new SASAutomationConfigDto
             {
                 Id = c.Id,
                 ConfigurationType=c.ConfigurationType==null ? "FileTransfer" : c.ConfigurationType.ToString(),
                 ConfigName = c.ConfigName,
                 StudyID = c.StudyID.ToString(),
                 FileName = c.FileName,
                 SourceFileProtocol = Enum.GetName(c.SourceFileProtocol!.Value),
                 SourceEncryption = Enum.GetName(c.SourceEncryption!.Value),
                 SourceHostName = c.SourceHostName,
                 SourcePortNumber = c.SourcePortNumber,
                 SourceUserName = c.SourceUserName,
                 SourcePassword = c.SourcePassword,
                 SourceFileName = c.SourceFileName==null? "": c.SourceFileName,
                 SourceZipPassword = c.SourceZipPassword,
                 SourceFolderPath = c.SourceFolderPath == null ? "" : c.SourceFolderPath,
                 DestFileProtocol = Enum.GetName(c.DestFileProtocol!.Value),
                 DestEncryption = Enum.GetName(c.DestEncryption!.Value),
                 DestHostName = c.DestHostName,
                 DestPortNumber = c.DestPortNumber,
                 DestUserName = c.DestUserName,
                 DestPassword = c.DestPassword,
                 ArchiveDestFolderPath = c.ArchiveDestFolderPath==null?"":c.ArchiveDestFolderPath,
                 CurrentDestFolderPath = c.CurrentDestFolderPath==null?"":c.CurrentDestFolderPath,
                 TransferDate = c?.TransferDate,
                 IsDaily = c?.IsDaily == null ? false : c.IsDaily,
                 IsEDCActive = c?.IsEDCActive == null ? false : c.IsEDCActive,
                 TimeSlot = c?.TimeSlot!=null?convertTimeSlot(timeZone,c.TimeSlot):null,
                 WeekDays = c?.WeekDays,
                 IsDeleteFileAfterTransfer = c?.IsDeleteFileAfterTransfer,
                 CreatedBy = c?.CreatedBy,
                 CreatedDate = c?.CreatedDate!.ToString("dd-MMM-yyyy"),
                 LastModifiedBy = c?.LastModifiedBy,
                 LastModifiedDate = c?.LastModifiedDate!=null? c?.LastModifiedDate.Value.ToString("dd-MMM-yyyy"):null,
                 HasError= !string.IsNullOrEmpty(c?.LastError) ? true : false,
                // ExecuteProgramAfterTransfer = c?.ExecuteProgramAfterTransfer,
                 File = File,
                 Path = c?.Path,
                 Arguments = Arguments,
                 TimeoutInSeconds = TimeoutInSeconds,
                 Description = c?.Description,
                 LastError = c?.LastError!=null? c?.LastError!: "None",
                 LastSASLaunchDateTime = c?.LastSASLaunchDateTime != null ? c?.LastSASLaunchDateTime.Value.ToString("dd-MMM-yyyy") : string.Empty,
                 LastErrorDateTime = c?.LastErrorDateTime!=null?c?.LastErrorDateTime.Value.ToString("dd-MMM-yyyy"):string.Empty
             });
            this.HasErrorCount = edcDetail.Count(x => x.HasError == true && x.IsEDCActive==true);
            return new JsonResult(DataSourceLoader.Load(edcDetail, loadOptions));
        }

        public string convertTimeSlot(string IncomingTimezoneOffset,string timeSlot)
        {
            var currentUtcDateTime = DateTime.UtcNow.AddMinutes(Convert.ToDouble(IncomingTimezoneOffset));
            var utcDate = currentUtcDateTime.ToString("dd-MMM-yyyy") + " " + timeSlot;
            var utcTimeSlot = Convert.ToDateTime(utcDate);
            var localToUtcDateTime = utcTimeSlot.ShiftUtcToLocal(IncomingTimezoneOffset);
            return localToUtcDateTime.ToString("t");
        }
        public async Task<PartialViewResult> OnGetStudyCloneAsync(int key)
        {
            TempData["CloneId"] = key;
            var studyList = await _mediator.Send(new GetStudyListCommandQuery());
            return Partial("_StudiesClone", studyList.ToList());
        }
        public class ReturnMessage
        {
            public bool IsSuccess { get; set; }
            public string? Message { get; set; }
        }

        public async Task<IActionResult> OnPostCloneAsync(long studyId = 0)
        {
            var configId = TempData["CloneId"];
            TempData.Keep();
            string message = string.Empty;
            if (configId == null && studyId == 0)
            {
                return Page();

            }
            var edcdetail = await _mediator.Send(new GetSASAutomationConfigCloneQuery((int)configId!));
            bool IsCloneSuccess = false;
            if (edcdetail != null)
            {
                try
                {
                    SASAutomationConfig model = new()
                    {
                        ConfigName = edcdetail.ConfigName + "(CLONED)",
                        StudyID = studyId,
                        SourceFileProtocol = edcdetail.SourceFileProtocol,
                        SourceFTPSite = edcdetail.SourceFTPSite,
                        SourceEncryption = edcdetail.SourceEncryption,
                        SourceHostName = edcdetail.SourceHostName,
                        SourcePortNumber = edcdetail.SourcePortNumber,
                        SourceUserName = edcdetail.SourceUserName,
                        SourcePassword = edcdetail.SourcePassword,
                        SourceFileName = edcdetail.SourceFileName,
                        SourceZipPassword = edcdetail.SourceZipPassword,
                        SourceFolderPath = edcdetail.SourceFolderPath,
                        DestFileProtocol = edcdetail.DestFileProtocol,
                        DestEncryption = edcdetail.DestEncryption,
                        DestFTPSite = edcdetail.DestFTPSite,
                        DestHostName = edcdetail.DestHostName,
                        DestPortNumber = edcdetail.DestPortNumber,
                        DestUserName = edcdetail.DestUserName,
                        DestPassword = edcdetail.DestPassword,
                        ArchiveDestFolderPath = edcdetail.ArchiveDestFolderPath,
                        CurrentDestFolderPath = edcdetail.CurrentDestFolderPath,
                        IsDeleteFileAfterTransfer = edcdetail.IsDeleteFileAfterTransfer,
                        IsEDCActive = edcdetail.IsEDCActive,
                        WeekDays = edcdetail.WeekDays,
                        IsDaily = edcdetail.IsDaily,
                        TimeSlot = edcdetail.TimeSlot,
                        CanDMRUN = edcdetail.CanDMRUN,
                        CanRunStatistician = edcdetail.CanRunStatistician,
                        ExecuteProgramAfterTransfer = edcdetail.ExecuteProgramAfterTransfer,
                        File= edcdetail.File,
                        Path= edcdetail.Path,
                        ConfigurationType=edcdetail.ConfigurationType,
                    };
                    await _mediator.Send(new CloneSASAutomationConfigCommand(model));
                    message = "Cloned Successfully!";
                    IsCloneSuccess = true;
                    return new JsonResult(new { IsSuccess = IsCloneSuccess, Key = model.Id, Message = message });
                }
                catch (Exception)
                {
                    message = "SAS Automation with same Config Name already exists for the selected study.";
                    IsCloneSuccess = false;
                }
            }

            return new JsonResult(new ReturnMessage { IsSuccess = IsCloneSuccess, Message = message });
        }
    }
}
