using EDCIS.Domain.Enum;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;


namespace EDCIS.UI.Pages.Development_Env
{
    public class ImpersonatePageModel : PageModel
    {

        public string GetCookie(string cookieKey, string defaultValue = "")
        {
            return (Request.Cookies[cookieKey] ?? defaultValue);
        }

        /// <summary>
        /// Sets the cookie cookieKey with cookieValue
        /// </summary>
        /// <param name="cookieKey"></param>
        /// <param name="cookieValue"></param>
        /// <param name="clearFirst">Clear (delete) the cookie before setting it.</param>
        /// <param name="expires">Default is one year from now.</param>
        public void SetCookie(string cookieKey, string cookieValue,
            bool clearFirst = true, DateTime? expires = null)
        {
            if (clearFirst) ClearCookie(cookieKey);
            CookieOptions options = new CookieOptions();
            options.Secure = true;
            options.HttpOnly = true;
            options.Expires = (expires != null) ? expires : DateTime.UtcNow.AddYears(1);
            Response.Cookies.Append(cookieKey, cookieValue, options);
        }
       

        public void ClearCookie(string cookieKey)
        {
            Response.Cookies.Delete(cookieKey);
        }

        private readonly IMediator _mediator;
        private readonly ILogger _logger;
        public string? ImpersonatingUserId { get { return GetCookie(CookieName.ImpersonatingUserId); } set { SetCookie(CookieName.ImpersonatingUserId, value!); } }
        public string LastUrl { get { return GetCookie(CookieName.LastUrl); } set { SetCookie(CookieName.LastUrl, value); } }
        public string ReturnUrl { get { return GetCookie(CookieName.ReturnUrl); } set { SetCookie(CookieName.ReturnUrl, value); } }
        protected string GetCookie(CookieName cookieName, string defaultValue = "")
        {
            return GetCookie(cookieName.ToString(), defaultValue);
        }

        protected void SetCookie(CookieName cookieName, string cookieValue)
        {
            SetCookie(cookieName.ToString(), cookieValue);
        }
        public IEnumerable<Resource> Resources { get; set; } = null!;
        public ImpersonatePageModel(ILogger<ImpersonatePageModel> logger, IMediator mediator)
        {
            _mediator = mediator;
            _logger = logger;
        }

        public async Task<IActionResult> OnGetAsync()
        {
            ReturnUrl =  Request.Path + Request.QueryString;

            if (!string.IsNullOrEmpty(ImpersonatingUserId))
            {
                ViewData["HtmlForTurnOffOption"] =
                    "You are currently impersonating " + ImpersonatingUserId + ".&nbsp;&nbsp;" +
                    "<button name=\"TurnOffImpersonation\" type=\"submit\" value=\"TurnOff\" title=\"Impersonate this user for the next request only.\" >Turn off</button>" +
                    "<hr />" +
                    "OR switch to ..." +
                "<br />" +
                    "<br />";
            }
            var resourceList = await _mediator.Send(new GetResourceListCommandQuery());
            Resources =  resourceList.Where(x => x.IsActive == true);
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(
            string TurnOffImpersonation,
            int impersonatingUserResourceId_Start,
            int impersonatingUserResourceId_OneTime)
        {
          
            if (TurnOffImpersonation == "TurnOff")
            {
                ImpersonatingUserId = "";
            }

            //Note that "impersonatingUserResourceId_..." is the Id of the Resource (table),
            ////but "impersonatingUserId" is the user Id (their email address)
            var resourceList = await _mediator.Send(new GetResourceListCommandQuery());
            var resources = resourceList.Where(x => x.IsActive == true);
            if (impersonatingUserResourceId_Start > 0 && resources!=null)
            {
              
                ImpersonatingUserId = resources.FirstOrDefault(_ => _.Id == impersonatingUserResourceId_Start)?.EmailAddress;
                if (string.IsNullOrEmpty(ReturnUrl))
                {
                    ReturnUrl = "/Studies/Studies";
                }
                return Redirect(ReturnUrl);
            }

            if (impersonatingUserResourceId_OneTime > 0 && resources != null)
            {
                ImpersonatingUserId = ""; //turn off any existing impersonation
                string iuid = resources.FirstOrDefault(_ => _.Id == impersonatingUserResourceId_OneTime)?.EmailAddress!;

                //Added this to strip off any existing iuid in case one as added right after another
                string newReturnUrl = ReturnUrl; //$EXPLAIN$: WHY is newReturnUrl needed? WHY can't just re-assign to ReturnUrl?
                if (ReturnUrl.Contains("iuid=")) newReturnUrl = ReturnUrl.Substring(0, (ReturnUrl.IndexOf("iuid") - 1)); //ALSO strips off the leading '?' OR '&'

                string returnUrlWithIuid = newReturnUrl + (newReturnUrl.Contains("?") ? "&" : "?") + "iuid=" + iuid;
                return Redirect(returnUrlWithIuid);
            }

            //$IMPROVE$: Something went wrong:
            return Redirect(ReturnUrl);
        }

    }
}

    

