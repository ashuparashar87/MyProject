﻿using EDCIS.Application.ClientInfrastructure.Dtos;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Net;

namespace EDCIS.UI
{
    public class ApplicationExceptionMiddleware
    {
        public const int SqlServerViolationOfUniqueIndex = 2601;
        public const int SqlServerViolationOfUniqueConstraint = 2627;
        public const int SqlServerForeignKeyConstraints = 547;
        private readonly RequestDelegate _next;
        private readonly IMediator _mediator;
        private readonly ILogger<ApplicationExceptionMiddleware> _logger;

        public ApplicationExceptionMiddleware(
            RequestDelegate next,
            ILogger<ApplicationExceptionMiddleware> logger,
            IMediator mediator)
        {
            _next = next;
            _logger = logger;
            _mediator = mediator;
        }
        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext);
            }
            catch (Exception exception)
            {
                await HandleExceptionAsync(httpContext, exception);
            }
        }

        private async Task HandleExceptionAsync(HttpContext context, Exception error)
        {
            await SendEmail(error);
            switch (error)
            {
                case NotFoundException ex:
                    // custom application error
                    _logger.LogError($"Something went wrong: {ex}");
                    context.Response.StatusCode = (int)HttpStatusCode.NotFound;
                    await context.Response.WriteAsync(ex.Message);
                    break;

                case DbUpdateException ex:
                    var dbUpdateEx = ex;
                    var sqlEx = dbUpdateEx?.InnerException as SqlException;
                    if (sqlEx != null)
                    {
                        //This is a DbUpdateException on a SQL database
                        if (sqlEx.Number == SqlServerViolationOfUniqueIndex ||
                            sqlEx.Number == SqlServerViolationOfUniqueConstraint)
                        {
                            var message = sqlEx.Errors[0].Message;
                            _logger.LogError($"Key duplicate error: {message}");
                            await context.Response.WriteAsync(message);
                        }
                        if (sqlEx.Number == SqlServerForeignKeyConstraints)
                        {
                            var message = sqlEx.Errors[0].Message;
                            _logger.LogError($"Foreign/Reference Key error: {message}");
                            await context.Response.WriteAsync(message);
                        }
                    }

                    break;
                case BadRequestException ex:
                    // custom application error
                    _logger.LogError(ex.Message);
                    await context.Response.WriteAsync(ex.Message);
                    break;
                case KeyNotFoundException ex:
                    // not found error
                    _logger.LogError($"Something went wrong: {ex}");
                    context.Response.StatusCode = (int)HttpStatusCode.NotFound;
                    await context.Response.WriteAsync(ex.Message);
                    break;

                default:
                    // unhandled error
                    _logger.LogError($"Something went wrong: {error}");
                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    await context.Response.WriteAsync(error.Message);
                    break;
            }
        }

        private async Task SendEmail(Exception error)
        {
            var exceptionMessage = $"<b>For User: {SD.UserId} </b> <b>Exception Error: {error} </b> {error!.StackTrace}";
            await _mediator.Send(new UIEmailSenderCommand(exceptionMessage));
        }
    }
    public abstract class BaseException : Exception
    {
        public BaseException(string message) : base(message)
        {
        }
        public BaseException(string message, Exception innerException) : base(message, innerException)
        {
        }

        public BaseException() : base()
        {
        }
    }


    public class NotFoundException : BaseException
    {
        public NotFoundException(string message) : base(message)
        {
        }

        public NotFoundException(string message, Exception innerException) : base(message, innerException)
        {
        }

        public NotFoundException() : base()
        {
        }
    }
    public class BadRequestException : BaseException
    {
        public BadRequestException(string message) : base(message)
        {
        }

        public BadRequestException(string message, Exception innerException) : base(message, innerException)
        {
        }

        public BadRequestException() : base()
        {
        }
    }

    public class ResourceNotFoundException : BaseException
    {
        public ResourceNotFoundException(string message) : base(message)
        {
        }

        public ResourceNotFoundException(string message, Exception innerException) : base(message, innerException)
        {
        }

        public ResourceNotFoundException() : base()
        {
        }
    }
    public class UnauthorizedException : BaseException
    {
        public UnauthorizedException(string message) : base(message)
        {
        }

        public UnauthorizedException(string message, Exception innerException) : base(message, innerException)
        {
        }

        public UnauthorizedException() : base()
        {
        }
    }
}


