﻿using Microsoft.Graph;
namespace EDCIS.UI
{
    public class UserGroupService
    {
        private readonly GraphServiceClient _graphServiceClient;

        public UserGroupService(GraphServiceClient graphServiceClient)
        {
            _graphServiceClient = graphServiceClient;
        }

        public async Task<IList<string>> GetUserSecurityGroupsAsync(string? userId)
        {
            var user = await _graphServiceClient.Users
            .Request()
            .Filter($"mail eq '{userId}' or userPrincipalName eq '{userId}'")
            .GetAsync();
            if (user == null)
            {
                throw new Exception("User not found.");
            }
            string? id = user?.FirstOrDefault()?.Id;

            var userGroups = await _graphServiceClient.Users[id].MemberOf
                .Request()
                .GetAsync();

            // Filter to include only security groups
            var securityGroups = userGroups.CurrentPage
                .OfType<Group>()
                .Where(g => g.SecurityEnabled == true)
                .Select(g => g.DisplayName)
                .ToList();

            return securityGroups;
        }

        public async Task<Resource?> GetUsersFromAzureAd(string? userId)
        {
            var AdUsers = await _graphServiceClient.Users
            .Request()
           .Filter($"mail eq '{userId}' or userPrincipalName eq '{userId}'")
           .GetAsync();
            if (AdUsers != null && AdUsers.FirstOrDefault()?.Mail != null)
            {
                var resource = new Resource();
                resource.FirstName = AdUsers.FirstOrDefault()?.DisplayName;
                resource.EmailAddress = AdUsers.FirstOrDefault()?.Mail;
                return resource;
            }
            return null;
        }
    }
}

