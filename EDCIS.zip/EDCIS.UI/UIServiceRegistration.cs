﻿using EDCIS.Application.ClientInfrastructure.Dtos;

namespace EDCIS.UI
{
    public static class UIServiceRegistration
    {
        public static IServiceCollection AddUIServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddRazorPages().AddJsonOptions(options => options.JsonSerializerOptions.PropertyNamingPolicy = null);           
            SD.UserName = configuration["MedidataService:UserName"];
            SD.Password = configuration["MedidataService:Password"];
            SD.AuthenticationFeatureToggle = Convert.ToBoolean(configuration["AuthenticationFeatureToggle:IsFeatureEnabled"]);
            return services;
        }
    }
}


