﻿2022-05-11 RMcQ

Taken from https://fonts.google.com/icons
(special thanks to Michael Herron for finding them)