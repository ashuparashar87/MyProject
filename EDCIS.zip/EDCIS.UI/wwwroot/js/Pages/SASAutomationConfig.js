﻿
if ($('#hdStudyStatus').val() == "Closed" || $('#IsEditRunAuthorized').val() == "False") {
    $("#frmSASConfig :input").prop("disabled", true);
    $('[data-toggle=collapse]').prop('disabled', false);
    $('#btnClose').prop('disabled', false);
    $('#btnAddSasAutomation').prop('disabled', true);
}
//if ($("#MainEntity_Id").val() > 0) {
//    $("#MainEntity_ConfigName").prop('disabled', true);
//}
//else {
//    $("#MainEntity_ConfigName").prop('disabled', false);
//}
if ($('#IsProgramAuthorized').val() == "True") {
    $('#MainEntity_ExecuteProgramAfterTransfer').prop('disabled', false);
    $('#MainEntity_File').prop('disabled', false);
    $('#MainEntity_TimeoutInSeconds').prop('disabled', false);
    $('#MainEntity_Description').prop('disabled', false);
    $('#MainEntity_Path').prop('disabled', false);
    $('#MainEntity_Arguments').prop('disabled', false);
    $('#btnSASRun').prop('disabled', false);
    $('#btnSASTest').prop('disabled', false);
    $('#headingSource').hide();
    $('#collapseSource').hide();
    $('#headingTwo').hide();
    $('#collapseDest').hide();
    $('#headingFour').hide();
    $('#collapseRun').hide();
}

if ($('#ConfigurationType').val() == "FileTransfer") {
    $('#headingFour').hide();
    $('#collapseRun').hide();
    $('#headingSource').show();
    $('#collapseSource').show();
    $('#headingTwo').show();
    $('#collapseDest').show();

}
else if ($('#ConfigurationType').val() == "SASProgram") {
    var checkpathvalue = $("#MainEntity_Path").val();
    if (checkpathvalue == null || checkpathvalue == '') {
        $("#btnJobRun").prop('disabled', true);
    } else {
        $("#btnJobRun").prop('disabled', false);
    }
    $('#headingSource').hide();
    $('#collapseSource').hide();
    $('#headingTwo').hide();
    $('#collapseDest').hide();
    $('#headingFour').show();
    $('#collapseRun').show();
}
$(".rdnchange").on('change', function () {
    var configType = $('input[name="FileTransfer1"]:checked').val();
    if (configType == "FileTransfer") {
        $('#headingFour').hide();
        $('#collapseRun').hide();
        $('#headingSource').show();
        $('#collapseSource').show();
        $('#headingTwo').show();
        $('#collapseDest').show();
    }
    else if (configType == "SASProgram") {
        var checkpathvalue = $("#MainEntity_Path").val();
        if (checkpathvalue == null || checkpathvalue=='') {
            $("#btnJobRun").prop('disabled', true);
        } else {
            $("#btnJobRun").prop('disabled', false);
        }
        $('#headingSource').hide();
        $('#collapseSource').hide();
        $('#headingTwo').hide();
        $('#collapseDest').hide();
        $('#headingFour').show();
        $('#collapseRun').show();

    }
    $('#ConfigurationType').val(configType);
});
$('#MainEntity_Path').on("input", function () {
    var dInput = this.value;
    if (dInput == null || dInput == '') {
        $("#btnJobRun").prop('disabled', true);
    } else {
        $("#btnJobRun").prop('disabled', false);
    }
});
var timezoneDetail = new Date().getTimezoneOffset();
$('#hdTimeZone').val(timezoneDetail);

$('#btnTestSource').on('click', ExecuteTestSourceConnection);

function ExecuteTestSourceConnection() {
    var IsFormValid = true;
    var data = {
        ftpSite: $("#MainEntity_SourceFTPSite").val(),
        fileName: $("#SourceFileName").val(),
        folderPath: $("#SourceFolderPath").val()
    }
    if ($('#ConfigurationType').val() == "FileTransfer") {
        if (data.ftpSite == "") {
            setError("MainEntity.SourceFTPSite", "FTP Site field is required.");
            IsFormValid = false;
        } else {
            setError("MainEntity.SourceFTPSite", "");
        }
        if (data.fileName == "") {
            setError("MainEntity.SourceFileName", "File Name field is required.");
            IsFormValid = false;
        } else {
            setError("MainEntity.SourceFileName", "");
        }
        if (data.folderPath == "") {
            setError("MainEntity.SourceFolderPath", "Folder path field is required.");
            IsFormValid = false;
        } else {
            setError("MainEntity.SourceFolderPath", "");
        }
    }
    else {
        if ($("#MainEntity_File").val() == null) {
            setError("MainEntity.File", "SAS Executable File.");
            IsFormValid = false;
        } else {
            setError("MainEntity.File", "");
        }
        if ($("#MainEntity_Description").val() == null) {
            setError("MainEntity.Description", "Description is required.");
            IsFormValid = false;
        } else {
            setError("MainEntity.Description", "");
        }
    }
    if (IsFormValid) {
        $("#loading").show();
        var PostEDCConfigHandlerUrl = "/Home/SASAutomationConfig?handler=SourceTestConnection";
        $.ajaxSetup({
            beforeSend: function (xhr) {
                xhr.setRequestHeader("RequestVerificationToken",
                    $('input:hidden[name="__RequestVerificationToken"]').val());
            }
        });
        $.post(PostEDCConfigHandlerUrl, data, function (data, textStatus, jqXHR) {
            if (data.IsSuccess) {
                $("#loading").hide();
                $("#success-alert").removeClass("d-none");
                var successMsg = $('#success-alert');
                successMsg.find('.successmessage').html(data.Message);
                $("#success-alert").addClass("show");
                $("#success-alert").show();
                window.scrollTo(0, 0);
                $("#success-alert").fadeTo(5000, 500).slideUp(500, function () {
                    window.scrollTo(0, 0);
                });
            }
            else {
                $("#loading").hide();
                $("#failure-alert").removeClass("d-none");
                var failureMsg = $('#failure-alert');
                failureMsg.find('.failuremessage').html(data.Message);
                $("#failure-alert").addClass("show");
                $("#failure-alert").show();
                window.scrollTo(0, 0);
                $("#failure-alert").fadeTo(5000, 500).slideUp(500, function () {
                    window.scrollTo(0, 0);
                });
            }

        }).fail(function (jqXHR, textStatus, errorThrown) {
            $("#loading").hide();
            $("#failure-alert").removeClass("d-none");
            var failureMsg = $('#failure-alert');
            failureMsg.find('.failuremessage').html(data.Message);
            $("#failure-alert").addClass("show");
            $("#failure-alert").show();
            window.scrollTo(0, 0);
            $("#failure-alert").fadeTo(5000, 500).slideUp(500, function () {
                window.scrollTo(0, 0);
            });
        });
    }
    else {
        $('#collapseOne').addClass('show');
        $("html, body").animate({ scrollTop: 0 });
    }
}

$('#btnTestDestination').on('click', ExecuteTestDestinationConnection);

function ExecuteTestDestinationConnection() {
    var IsFormValid = true;
    var data = {
        ftpSite: $("#MainEntity_DestFTPSite").val(),
        archiveDestFolderPath: $("#ArchiveDestFolderPath").val(),
        destUnZippedFolderPath: $("#DestUnZippedFolderPath").val()
    }

    if (data.ftpSite == "0") {
        setError("MainEntity.DestFTPSite", "FTP Site field is required.");
        IsFormValid = false;
    } else {
        setError("MainEntity.DestFTPSite", "");
    }
    if (data.archiveDestFolderPath == "") {
        setError("MainEntity.ArchiveDestFolderPath", "Archive Dest Folder Path field is required.");
        IsFormValid = false;
    } else {
        setError("MainEntity.ArchiveDestFolderPath", "");
    }
    if (data.destUnZippedFolderPath == "") {
        setError("MainEntity.CurrentDestFolderPath", "Current Dest Folder Path field is required.");
        IsFormValid = false;
    } else {
        setError("MainEntity.CurrentDestFolderPath", "");
    }
    if (IsFormValid) {
        $("#loading").show();
        var PostEDCConfigHandlerUrl = " /Home/SASAutomationConfig?handler=DestinationTestConnection";
        $.ajaxSetup({
            beforeSend: function (xhr) {
                xhr.setRequestHeader("RequestVerificationToken",
                    $('input:hidden[name="__RequestVerificationToken"]').val());
            }
        });
        $.post(PostEDCConfigHandlerUrl, data, function (data, textStatus, jqXHR) {
            if (data.IsSuccess) {
                $("#loading").hide();
                $("#success-alert").removeClass("d-none");
                var successMsg = $('#success-alert');
                successMsg.find('.successmessage').html(data.Message);
                $("#success-alert").addClass("show");
                window.scrollTo(0, 0);
                $("#success-alert").show();
                $("#success-alert").fadeTo(5000, 500).slideUp(500, function () {
                    $("#success-alert").slideUp(500);
                    window.scrollTo(0, 0);
                });
            }
            else {
                $("#loading").hide();
                $("#failure-alert").removeClass("d-none");
                var failureMsg = $('#failure-alert');
                failureMsg.find('.failuremessage').html(data.Message);
                $("#failure-alert").addClass("show");
                $("#failure-alert").show();
                window.scrollTo(0, 0);
                $("#failure-alert").fadeTo(5000, 500).slideUp(500, function () {
                    window.scrollTo(0, 0);
                });
            }

        }).fail(function (jqXHR, textStatus, errorThrown) {
            $("#loading").hide();
            $("#failure-alert").removeClass("d-none");
            var failureMsg = $('#failure-alert');
            failureMsg.find('.failuremessage').html(data.Message);
            $("#failure-alert").addClass("show");
            $("#failure-alert").show();
            window.scrollTo(0, 0);
            $("#failure-alert").fadeTo(5000, 500).slideUp(500, function () {
                window.scrollTo(0, 0);
            });

        });
    }
    else {
        $('#collapseOne').addClass('show');
        $("html, body").animate({ scrollTop: 0 });
    }
}

$('#btnSASTest').on('click', ExecuteTestSASConnection);

function ExecuteTestSASConnection() {
    var data = {
        url: 'agdigitalhealthdev27.eastus.cloudapp.azure.com:5002',
    }
    var IsFormValid = true;
    if (IsFormValid) {
        $("#loading").show();
        var PostSASHandlerUrl = " /Home/SASAutomationConfig?handler=SASTestConnection";
        $.ajaxSetup({
            beforeSend: function (xhr) {
                xhr.setRequestHeader("RequestVerificationToken",
                    $('input:hidden[name="__RequestVerificationToken"]').val());
            }
        });
        $.post(PostSASHandlerUrl, data, function (data, textStatus, jqXHR) {
            if (data.IsSuccess) {
                $("#loading").hide();
                $("#success-alert").removeClass("d-none");
                var successMsg = $('#success-alert');
                successMsg.find('.successmessage').html(data.Message);
                $("#success-alert").addClass("show");
                window.scrollTo(0, 0);
                $("#success-alert").show();
                $("#success-alert").fadeTo(5000, 500).slideUp(500, function () {
                    $("#success-alert").slideUp(500);
                    window.scrollTo(0, 0);
                });
            }
            else {
                $("#loading").hide();
                $("#failure-alert").removeClass("d-none");
                var failureMsg = $('#failure-alert');
                failureMsg.find('.failuremessage').html(data.Message);
                $("#failure-alert").addClass("show");
                $("#failure-alert").show();
                window.scrollTo(0, 0);
                $("#failure-alert").fadeTo(5000, 500).slideUp(500, function () {
                    window.scrollTo(0, 0);
                });
            }

        }).fail(function (jqXHR, textStatus, errorThrown) {
            $("#loading").hide();
            $("#failure-alert").removeClass("d-none");
            var failureMsg = $('#failure-alert');
            failureMsg.find('.failuremessage').html(data.Message);
            $("#failure-alert").addClass("show");
            $("#failure-alert").show();
            window.scrollTo(0, 0);
            $("#failure-alert").fadeTo(5000, 500).slideUp(500, function () {
                window.scrollTo(0, 0);
            });

        });
    }
    else {
        $('#collapseOne').addClass('show');
        $("html, body").animate({ scrollTop: 0 });
    }
}

$('#btnSASRun').on('click', RunAgentService);

function RunAgentService() {
    var data = {
        Id: $("#MainEntity_Id").val(),
        args: $("#MainEntity_Arguments").val(),
        description: $("#MainEntity_Description").val(),
        File: $("#MainEntity_File").val(),
        Path: $("#MainEntity_Path").val(),
        timeout: $("#MainEntity_TimeoutInSeconds").val()
    }
    var IsFormValid = true;
    if (IsFormValid) {
        $("#loading").show();
        var PostSASHandlerUrl = " /Home/SASAutomationConfig?handler=RunAgentService";
        $.ajaxSetup({
            beforeSend: function (xhr) {
                xhr.setRequestHeader("RequestVerificationToken",
                    $('input:hidden[name="__RequestVerificationToken"]').val());
            }
        });
        $.post(PostSASHandlerUrl, data, function (data, textStatus, jqXHR) {
            if (data.IsSuccess) {
                $("#MainEntity_LastSASLogFile").val(data.LogFile);
                $("#loading").hide();
                $("#success-alert").removeClass("d-none");
                var successMsg = $('#success-alert');
                successMsg.find('.successmessage').html(data.Message);
                $("#success-alert").addClass("show");
                window.scrollTo(0, 0);
                $("#success-alert").show();
                $("#success-alert").fadeTo(5000, 500).slideUp(500, function () {
                    $("#success-alert").slideUp(500);
                    window.scrollTo(0, 0);
                });
            }
            else {
                $("#loading").hide();
                $("#failure-alert").removeClass("d-none");
                var failureMsg = $('#failure-alert');
                failureMsg.find('.failuremessage').html(data.Message);
                $("#failure-alert").addClass("show");
                window.scrollTo(0, 0);
                $("#failure-alert").show();
                $("#failure-alert").fadeTo(5000, 500).slideUp(500, function () {
                    window.scrollTo(0, 0);
                });
            }

        }).fail(function (jqXHR, textStatus, errorThrown) {
            $("#loading").hide();
            $("#failure-alert").removeClass("d-none");
            var failureMsg = $('#failure-alert');
            failureMsg.find('.failuremessage').html(data.Message);
            $("#failure-alert").addClass("show");
            $("#failure-alert").show();
            window.scrollTo(0, 0);
            $("#failure-alert").fadeTo(5000, 500).slideUp(500, function () {
                window.scrollTo(0, 0);
            });


        });
    }
    else {
        $('#collapseOne').addClass('show');
        $("html, body").animate({ scrollTop: 0 });
    }
}





var IsJobRunning = $("#IsJobRunning").val();
if (IsJobRunning == "1") {
    $('#btnJobRun').prop('disabled', true);
}


$('#btnJobRun').on('click', ExecuteWebJob);

function ExecuteWebJob() {
    $(window).off('beforeunload');
    $(window).unbind('beforeunload');

    var form = $("form");
    $.validator.unobtrusive.parse(form);
    var IsValid = form.validate().form();
    if (IsValid) {
        $("#loading").show();
        $.ajaxSetup({
            beforeSend: function (xhr) {
                xhr.setRequestHeader("RequestVerificationToken",
                    $('input:hidden[name="__RequestVerificationToken"]').val());
            }
        });
        var JobRunHandlerUrl = " /Home/SASAutomationConfig?handler=WebJob";

        $.post(JobRunHandlerUrl, form.serialize(), function (data, textStatus, jqXHR) {

            if (data.IsSuccess) {
                $("#loading").hide();
                $("#success-alert").removeClass("d-none");
                var successMsg = $('#success-alert');
                successMsg.find('.successmessage').html(data.Message);
                $("#success-alert").addClass("show");
                window.scrollTo(0, 0);
                $("#success-alert").show();
                $("#success-alert").fadeTo(5000, 500).slideUp(500, function () {
                    $("#success-alert").slideUp(500);
                    window.scrollTo(0, 0);
                    window.location.href = data.RedirectUrl;
                });
            }
            else {

                $("#loading").hide();
                if (data.modelError != "") {
                    var obj = data.modelError;
                    $.each(obj, function (index, value) {
                        setError(index, value);
                    });
                } else {
                    $("#failure-alert").removeClass("d-none");
                    var failureMsg = $('#failure-alert');
                    failureMsg.find('.failuremessage').html(data.Message);
                    $("#failure-alert").addClass("show");
                    $("#failure-alert").show();
                    window.scrollTo(0, 0);
                    $("#failure-alert").fadeTo(5000, 500).slideUp(500, function () {
                        window.scrollTo(0, 0);
                    });
                }
                window.location.href = data.RedirectUrl;
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            $("#loading").hide();
            data.Message = jqXHR.
                $("#failure-alert").removeClass("d-none");
            var failureMsg = $('#failure-alert');
            failureMsg.find('.failuremessage').html(data.Message);
            $("#failure-alert").addClass("show");
            $("#failure-alert").show();
            window.scrollTo(0, 0);
            $("#failure-alert").fadeTo(5000, 500).slideUp(500, function () {
                window.scrollTo(0, 0);
            });

        });
    }
}

$(document).ready(function () {
    $('#success-alert-close').on('click', function () {
        $('#success-alert').hide();
    });

    $('#failure-alert-close').on('click', function () {
        $('#failure-alert').hide();
    });

    if ($("#DailyChecked:checked").length > 0) {
        $(".weekdayschk").prop('disabled', true);
    }
});


$(".weekdayschk").each(function (index, value) {
    var array = $('#WeekdaysChecked').val().split(",");
    for (i = 0; i < array.length; i++) {
        if (array[i] == $(this).val()) {
            $("#" + array[i]).prop("checked", true);
        }
    }
});

function setError(id, message) {
    var span = $("span[data-valmsg-for=\"" + id + "\"]");
    var elementId = ("#" + id.replaceAll(".", "_"));
    if (span && span.length > 0) {
        $(span).html(message);
        if (message && message != "") {
            $(span).removeClass("field-validation-valid");
            $(span).addClass("field-validation-no-valid");
            $(elementId).addClass("input-validation-error");
        } else {
            $(span).removeClass("field-validation-no-valid");
            $(span).addClass("field-validation-valid");
            $(elementId).removeClass("input-validation-error");
        }
    }
}

function DisplaySuccessResults(data, textStatus, jqXHR) {
    results =
        "SUCCESS: \n\n" +
        "textStatus=" + String(textStatus).substring(0, 200) + "\n\n" +
        "jqXHR=" + JSON.stringify(jqXHR).substring(0, 200) + "\n\n" +
        "data=" + JSON.stringify(data).substring(0, 200);
}

function DisplayFailureResults(jqXHR, textStatus, errorThrown) {
    results =
        "ERROR:\n" +
        JSON.stringify(jqXHR.responseText).substring(0, 400)
    alert(results);
}

$('#DailyChecked').on('change', function () {
    if ($(this).is(":checked")) {
        $('#hdIsDaily').val(true);
        $('#hdIsWeekly').val(false);
        $("#WeekdaysChecked").val(null);
        $('.weekdayschk').prop('checked', false);
        $(".weekdayschk").prop('disabled', true);
    }
});


$('#WeeklyChecked').on('change', function () {
    if ($(this).is(":checked")) {
        $('#hdIsDaily').val(false);
        $('#hdIsWeekly').val(true);
        $("input[type=checkbox]").attr('disabled', false);
    }
});

$(".weekdayschk").on('change', function () {
    if ($(".weekdayschk:checked").length > 0) {
        $('#hdIsDaily').val(false);
    }
});

function gridBox_Source_valueChanged(e) {
    var $dataGrid = $("#SourceConfig-datagrid");
    if ($dataGrid.length) {
        var dataGrid = $dataGrid.dxDataGrid("instance");
        dataGrid.selectRows(e.value, true);
    }

    $(window).on('beforeunload', function () {
        return 'Changes you made may not be saved.';
    });

}
function gridBox_Dest_valueChanged(e) {
    var $dataGrid = $("#DestConfig-datagrid");

    if ($dataGrid.length) {
        var dataGrid = $dataGrid.dxDataGrid("instance");
        dataGrid.selectRows(e.value, false);
    }

    $(window).on('beforeunload', function () {
        return 'Changes you made may not be saved.';
    });
}

function gridBox_displayExpr(item) {
    return item && item.FTPSite;
}

$(document).ready(function () {

    $("#success-message").fadeTo(5000, 500).slideUp(500, function () {
        $("#success-message").slideUp(500);

    });

    $("#failure-message").fadeTo(5000, 500).slideUp(500, function () {
        $("#failure-message").slideUp(500);
    });
    window.scrollTo(0, 0);
});

$(".form-control, .IsFormChanged").on('change', function () {
    $(window).on('beforeunload', function () {
        return 'Changes you made may not be saved.';
    });
});

$("#btnSave").on("click", function (e) {
    e.preventDefault();
    $(window).off('beforeunload');
    var Id = $("#MainEntity_Id").val()
    const newLocal = $('#frmSASConfig');
    var form = newLocal;
    $.validator.unobtrusive.parse(form);
    var IsFormValid = form.validate().form();
    var data = {
        ftpSite: $("#MainEntity_SourceFTPSite").val(),
        fileName: $("#SourceFileName").val(),
        folderPath: $("#SourceFolderPath").val(),
        desftpSite: $("#MainEntity_DestFTPSite").val(),
        archiveDestFolderPath: $("#ArchiveDestFolderPath").val(),
        destUnZippedFolderPath: $("#DestUnZippedFolderPath").val()
    }
    if ($('#ConfigurationType').val() == "FileTransfer") {
        if (data.ftpSite == "") {
            setError("MainEntity.SourceFTPSite", "FTP Site field is required.");
            IsFormValid = false;
        } else {
            setError("MainEntity.SourceFTPSite", "");
        }
        if (data.fileName == "") {
            setError("MainEntity.SourceFileName", "File Name field is required.");
            IsFormValid = false;
        } else {
            setError("MainEntity.SourceFileName", "");
        }
        if (data.folderPath == "") {
            setError("MainEntity.SourceFolderPath", "Folder path field is required.");
            IsFormValid = false;
        } else {
            setError("MainEntity.SourceFolderPath", "");
        }

        if (data.desftpSite == "") {
            setError("MainEntity.DestFTPSite", "FTP Site field is required.");
            IsFormValid = false;
        } else {
            setError("MainEntity.DestFTPSite", "");
        }
        if (data.archiveDestFolderPath == "") {
            setError("MainEntity.ArchiveDestFolderPath", "Archive Dest Folder Path field is required.");
            IsFormValid = false;
        } else {
            setError("MainEntity.ArchiveDestFolderPath", "");
        }
        if (data.destUnZippedFolderPath == "") {
            setError("MainEntity.CurrentDestFolderPath", "Current Dest Folder Path field is required.");
            IsFormValid = false;
        } else {
            setError("MainEntity.CurrentDestFolderPath", "");
        }
    }
    else {
        if ($("#MainEntity_File").val() == null || $("#MainEntity_File").val() == "") {
            setError("MainEntity.File", "SAS Execuable File.");
            IsFormValid = false;
        } else {
            setError("MainEntity.File", "");
        }
        if ($("#MainEntity_Description").val() == null || $("#MainEntity_Description").val() == "") {
            setError("MainEntity.Description", "Description is required.");
            IsFormValid = false;
        } else {
            setError("MainEntity.Description", "");
        }
    }
    if (IsFormValid && Id == 0) {
        var PostVerifyConfigNameHandlerUrl = "/Home/SASAutomationConfig?handler=VerifyConfigName";
        $.ajaxSetup({
            beforeSend: function (xhr) {
                xhr.setRequestHeader("RequestVerificationToken",
                    $('input:hidden[name="__RequestVerificationToken"]').val());
            }
        });
        var dataPost = {
            configName: $("#MainEntity_ConfigName").val()
        }
        $.post(PostVerifyConfigNameHandlerUrl, dataPost, function (data1, textStatus, jqXHR) {
            if (data1.IsSuccess) {
                Postbuttonsubmit();
            }
            else {
                $("#loading").hide();
                $("#failure-alert").removeClass("d-none");
                var failureMsg = $('#failure-alert');
                failureMsg.find('.failuremessage').html(data1.Message);
                $("#failure-alert").addClass("show");
                $("#failure-alert").show();
                window.scrollTo(0, 0);
                $("#failure-alert").fadeTo(5000, 500).slideUp(500, function () {
                    window.scrollTo(0, 0);
                });
                IsFormValid = false;
            }

        }).fail(function (jqXHR, textStatus, errorThrown) {
            $("#loading").hide();
            $("#failure-alert").removeClass("d-none");
            var failureMsg = $('#failure-alert');
            failureMsg.find('.failuremessage').html(data.Message);
            $("#failure-alert").addClass("show");
            $("#failure-alert").show();
            window.scrollTo(0, 0);
            $("#failure-alert").fadeTo(5000, 500).slideUp(500, function () {
                window.scrollTo(0, 0);
            });
            IsFormValid = false;
        });
        return IsFormValid;
    }
    else if (IsFormValid && Id > 0) 
        {
            Postbuttonsubmit();
        }
    });

function Postbuttonsubmit() {
    const newLocal = $('#frmSASConfig');
    var form = newLocal;
    $.validator.unobtrusive.parse(form);
    var IsFormValid = form.validate().form();
    var PostformsubmitHandlerUrl = "/Home/SASAutomationConfig?handler=Create";
    $.ajaxSetup({
        beforeSend: function (xhr) {
            xhr.setRequestHeader("RequestVerificationToken",
                $('input:hidden[name="__RequestVerificationToken"]').val());
        }
    });
    $.post(PostformsubmitHandlerUrl, form.serialize(), function (data, textStatus, jqXHR) {
        if (data.IsSuccess) {
            window.location.href = data.Message;
        }
        else {
            $("#loading").hide();
            $("#failure-alert").removeClass("d-none");
            var failureMsg = $('#failure-alert');
            failureMsg.find('.failuremessage').html(data.Message);
            $("#failure-alert").addClass("show");
            $("#failure-alert").show();
            window.scrollTo(0, 0);
            $("#failure-alert").fadeTo(5000, 500).slideUp(500, function () {
                window.scrollTo(0, 0);
            });
            IsFormValid = false;
        }

    }).fail(function (jqXHR, textStatus, errorThrown) {
        $("#loading").hide();
        $("#failure-alert").removeClass("d-none");
        var failureMsg = $('#failure-alert');
        failureMsg.find('.failuremessage').html(data.Message);
        $("#failure-alert").addClass("show");
        $("#failure-alert").show();
        window.scrollTo(0, 0);
        $("#failure-alert").fadeTo(5000, 500).slideUp(500, function () {
            window.scrollTo(0, 0);
        });
        IsFormValid = false;
    });
}