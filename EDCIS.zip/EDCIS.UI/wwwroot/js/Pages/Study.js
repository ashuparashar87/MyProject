﻿
var timezoneDetail = new Date().getTimezoneOffset();
function configureDataGrid(dgId, offSwitchArray) {
    

    console.log('Entered configureDataGrid: The dgId is ' + dgId);

    var dgIdSelector = "#" + dgId;
    console.log('The dgIdSelector is ' + dgIdSelector);

    $(dgIdSelector).dxDataGrid({

        allowColumnReordering: true,

        allowColumnResizing: true,

        columnChooser: {
            enabled: true,
            search: {
                enabled: true
            },
            mode: "select"
        },

        grouping: {                 
            contextMenuEnabled: true
        },

        groupPanel: {
            visible: true  
        },

        hoverStateEnabled: true,
       
        onExporting: function (e) {
            var workbook = new ExcelJS.Workbook();
            var worksheet = workbook.addWorksheet('EDCISExport');
            DevExpress.excelExporter.exportDataGrid({
                component: e.component,
                worksheet: worksheet,
                autoFilterEnabled: true
            }).then(function () {
                workbook.xlsx.writeBuffer().then(function (buffer) {
                    saveAs(new Blob([buffer], { type: 'application/octet-stream' }), NameOfPluralEntities + '.xlsx');
                });
            });
            e.cancel = true;
        },

        pager: {
            showPageSizeSelector: true,
            allowedPageSizes: [10, 25, 50, 100]
        },

        paging: {
            pageSize: 10
        },

        remoteOperations: false,

        rowAlternationEnabled: true,

        searchPanel: {
            visible: true,
            highlightCaseSensitive: true
        },

        showBorders: true,

        sorting: {
            mode: 'multiple',
        },

    });

    $('#partialModal').on('show.bs.modal', function (event) {   
        lblVal = $('#lblIdOnModal').html();
        console.log("partialModal shown with id = " + lblVal);
    })

}

$(configureDataGrid('dgMain', ['']));

function CloneRowData(Key) {
    $("#mi-modal").modal('show');
    $('#clone-body').load(`/Home/Home?handler=StudyClone&&key=${Key}`)
}


if ($('#IsEditRunAuthorized').val() == "False") {
    $('#btnAddSasAutomation').prop('disabled', true);
}

window.jsPDF = window.jspdf.jsPDF;
applyPlugin(window.jsPDF);

function exportToPDF() {
    var doc = new jsPDF();
    var dataGrid = $("#dgMain").dxDataGrid("instance");
    DevExpress.pdfExporter.exportDataGrid({
        jsPDFDocument: doc,
        component: dataGrid
    }).then(function () {
        doc.save(NameOfPluralEntities + ".pdf");
    });
}


function ResetGridState(dataGridId) {
    //$FIX$/$FINISH$: The datagrid MUST be named "dgMain":
    if (confirm("This will remove all changes to the grid display (sorts, filters, columns, etc.). Are you sure you want to do this?")) {
        var dataGrid = $("#dgMain").dxDataGrid("instance");
        dataGrid.state(null);
    }
}



function DisplayPopupForAdd() {
    console.log("Handler for .click() called.");   
    $.get(GetBlankEntityUrl, function (data, textStatus, jqXHR) {
        DisplaySuccessResults(data, textStatus, jqXHR);       
        $("#partialModal").find(".modal-title").html("(New " + NameOfSingleEntity + ")");
        $("#partialModal").find(".modal-body").html("");  
        $("#partialModal").find(".modal-body").html(data);
        $("#partialModal").find("#lblIdOnModal").text("(creating)");
        $("#partialModal").find("#partialModalCloseButton").show();
        $("#partialModal").find("#partialModalCreateButton").show();
        $("#partialModal").find("#partialModalSaveButton").hide();
        $("#partialModal").find("#partialModalDeleteButton").hide();
        $("#partialModal").modal('show');
    }).fail(function (jqXHR, textStatus, errorThrown) {
        DisplayFailureResults(jqXHR, textStatus, errorThrown);
    });
}



function DisplayPopupForEditAndDelete(key) {
    $('#lblIdOnModal').text(key);

    var Key = String(key);

    $.ajax({
        type: "GET",
        url: GetEntityUrl,
        data: { "key": Key },

        success: function (response) {
            $("#partialModal").find(".modal-title").html(NameOfSingleEntity);
            $("#partialModal").find(".modal-body").html("");  //Clear out for complete reload
            $("#partialModal").find(".modal-body").html(response);
            $("#partialModal").find("#partialModalCloseButton").show();
            $("#partialModal").find("#partialModalCreateButton").hide();
            $("#partialModal").find("#partialModalSaveButton").show();
            $("#partialModal").find("#partialModalDeleteButton").show();
            $("#partialModal").modal('show');
        },

        error: function (qXHR, textStatus, errorThrown) {
            results =
                "ERROR:\n" +
                JSON.stringify(jqXHR.responseText).substring(0, 400)  
            $("#partialModal").find(".modal-body").html(results);
            $("#partialModal").modal('show');
        }
    });
}


function ExecutePartialModalCreateButton() {
    var form = $('form');
    $.validator.unobtrusive.parse(form);
    var IsValid = form.validate().form();    
    if (IsValid) {
        id = $('#lblIdOnModal').html();
        console.log('Starting post with id of ' + id);
        $.ajaxSetup({
            beforeSend: function (xhr) {
                xhr.setRequestHeader("RequestVerificationToken",
                    $('input:hidden[name="__RequestVerificationToken"]').val());
            }
        });
        $.post(PostCreateHandlerUrl, $('form').serialize(), function (data, textStatus, jqXHR) {
            DisplaySuccessResults(data, textStatus, jqXHR);
            if (jqXHR.status == 202) {
                console.log("Closing partialModal");
                $("#partialModal").modal('hide');
                $("#dgMain").dxDataGrid("instance").refresh();
            }
            else {
                $("#partialModal").find(".modal-body").html(data);
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            DisplayFailureResults(jqXHR, textStatus, errorThrown);
        });
    }
}


function ExecutePartialModalSaveButton() {
    var form = $('form');
    $.validator.unobtrusive.parse(form);
    var IsValid = form.validate().form();
    if (IsValid) {
        id = $('#lblIdOnModal').html();
        console.log('Starting post with id of ' + id);
        $.ajaxSetup({
            beforeSend: function (xhr) {
                xhr.setRequestHeader("RequestVerificationToken",
                    $('input:hidden[name="__RequestVerificationToken"]').val());
            }
        });
        $.post(PostEditHandlerUrl, $('form').serialize(), function (data, textStatus, jqXHR) {
            DisplaySuccessResults(data, textStatus, jqXHR);
            if (jqXHR.status == 202) {
                $("#partialModal").modal('hide');
                $("#dgMain").dxDataGrid("instance").refresh();
            }
            else {
                $("#partialModal").find(".modal-body").html(data);
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            DisplayFailureResults(jqXHR, textStatus, errorThrown);
        });
    }
}


function ExecutePartialModalDeleteButton() {
    key = $('#lblIdOnModal').html();    
    console.log('Starting Delete get with id of ' + key);
    if (!confirm('Are you sure you want to delete this record?')) {
        return;
    }
    $.get(PostDeleteHandlerUrl + key, function (data, textStatus, jqXHR) {
        DisplaySuccessResults(data, textStatus, jqXHR);
        if (jqXHR.status == 202) {
            $("#partialModal").modal('hide');
            $("#dgMain").dxDataGrid("instance").refresh();
        }
        else {
            $("#partialModal").find(".modal-body").html(data);
        }
    }).fail(function (jqXHR, textStatus, errorThrown) {
        DisplayFailureResults(jqXHR, textStatus, errorThrown);
    });
}


function OnCellHoverChanged(e) {
    e.component.focus(e.cellElement)
}

function OnRowCloneDblClick(e) {
    var currentRowId = String(e.key);
    const PostCloneHandlerUrl = "/Home/Home?handler=Clone";
   // const PostCloneHandlerUrl = "/Home/Home?handler=Clone&configId=" + edcId + "&studyId" + currentRowId;
   // $.post("/Home/Home?handler=Clone", { "configId": edcId, "studyId": currentRowId }, function (data, textStatus, jqXHR) {
    $.post(PostCloneHandlerUrl, { studyId: currentRowId, __RequestVerificationToken: $('#hfAntiToken').val() }, function (data, textStatus, jqXHR) {
        if (data.IsSuccess) {
            alert(data.Message)
            window.location.href = "/Home/home" + "?studyId=" + currentRowId;
        }
        else { 
            alert(data.Message)
        }
    }).fail(function (jqXHR, textStatus, errorThrown) {
        DisplayFailureResults(jqXHR, textStatus, errorThrown);
    });

}
function DisplaySuccessResults(data, textStatus, jqXHR) {   
    results =
        "SUCCESS: \n\n" +
        "textStatus=" + String(textStatus).substring(0, 200) + "\n\n" +
        "jqXHR=" + JSON.stringify(jqXHR).substring(0, 200) + "\n\n" +
        "data=" + JSON.stringify(data).substring(0, 200);  
}

function DisplayFailureResults(jqXHR, textStatus, errorThrown) {    
    results =
        "ERROR:\n" +
            JSON.stringify(jqXHR.responseText).substring(0, 400)     
    alert(results);
}

function toggleVisibility(selector, animationInterval = 0) {
    var el = $(selector);
    el.is(':visible') ? el.hide(animationInterval) : el.show(animationInterval);
    return false;
}

function onChildContextMenu(e) {
    if (e.target == "\content") {
        if (!e.items) e.items = [];
        e.items.push({
            icon: "copy",
            text: "Clone",
            disabled: ($('#IsEditRunAuthorized').val() == "False")  ? true : false,
            visible: ((typeof ContextMenuCloneCommandVisible === 'undefined') ? true : ContextMenuCloneCommandVisible),
            onItemClick: () => CloneRowData(e.row.key)
        });

    }
}

function grid_SAS_Automation_beforeSend(op, ajax) {
     ajax.data.TimeZone = timezoneDetail;
    ajax.headers = {
        RequestVerificationToken: "@Xsrf.GetAndStoreTokens(Model.HttpContext).RequestToken"
    };
}

$(function () { $('#partialModalCreateButton').on('click', ExecutePartialModalCreateButton) });
$(function () { $('#partialModalSaveButton').on('click', ExecutePartialModalSaveButton) });
$(function () { $('#partialModalDeleteButton').on('click', ExecutePartialModalDeleteButton) });

function selection_Parent_changed(selectedItems) {
    var currentRowStudyId = selectedItems.currentSelectedRowKeys;
    const data = selectedItems.selectedRowsData[0];
    if (data != undefined) {
        if (data.SASAutomation == "Yes" || data.MedidataEDC == "Yes") {
            $("#btnViewLogs").prop('disabled', false);
        }
        else {
            $("#btnViewLogs").prop('disabled', true);
        }
    }

    $("#studId").val(currentRowStudyId);
}
function selection_Clone_changed(selectedItems) {
    var currentRowStudId = selectedItems.currentSelectedRowKeys;
    const data = selectedItems.selectedRowsData[0];
    $("#cloneStudyId").val(currentRowStudId);
}

function selection_Child_changed(selectedItems) {
    var currentRowStudId = selectedItems.currentSelectedRowKeys;
    $("#Id").val(currentRowStudId);
}

function OnRowPrepared(e) {
    if (e.rowType == 'data') {
        $(e.rowElement).attr("title", e.data.ErrorMessage);
        $(e.rowElement).css("cursor", "pointer");
    }
}
function OnRowChildDblClick(e) {
    var currentRowId = String(e.key);
    var currentRow = e.data;
    e.event.stopPropagation();
    var studykey = String(currentRow.StudyID)
    window.location.href = "/Home/SASAutomationConfig" + "?key=" + currentRowId + "&StudyId=" + studykey + "&IsParent=false" + "&timezoneDetail=" + timezoneDetail;
}

$("#btnAddSasAutomation").on("click", function () {
    var studyId = $("#studId").val();
    var id =0;
    if (studyId == 0) { alert("Please select atleast one study record.") }
    else {
        window.location.href = "/Home/SASAutomationConfig" + "?key=" + id + "&StudyId=" + studyId + "&IsParent=true" + "&timezoneDetail=" + timezoneDetail;
 }
});

if ($("#HasErrorCount").val() == 0) {
    $("#SuccessCount").css('display', 'block'); 
    $("#ErrorCount").css('display', 'none'); 
    $("#SuccessCount").html("<i class=\"dx-2x dx-icon-bell\"></i>");
}
else {
    $("#SuccessCount").css('display', 'none');
    $("#ErrorCount").css('display', 'block'); 
    $("#ErrorCount").html("<i class=\"dx-2x dx-icon-bell\"></i> <i class=\"dx-3x\">" + $("#HasErrorCount").val() +"</i>");
}

$("#ErrorCount").on("click", function () {   
    $("#ErrorCountClick").val($("#HasErrorCount").val()); 
    var gridData = $("#dgMain").dxDataGrid("instance");
    gridData.refresh();   
    $("#SuccessCount").css('display', 'block');
    $("#ErrorCount").css('display', 'none');
    $("#SuccessCount").html("<i class=\"dx-2x dx-icon-bell\"></i>");
})

$("#SuccessCount").on("click", function () {
    $("#ErrorCountClick").val(0);
    var gridData = $("#dgMain").dxDataGrid("instance");
    gridData.refresh();    
    $("#SuccessCount").css('display', 'none');
    $("#ErrorCount").css('display', 'block');
    $("#ErrorCount").html("<i class=\"dx-2x dx-icon-bell\"></i> <i class=\"dx-3x\">" + $("#HasErrorCount").val() + "</i>");
})
$("#btnViewLogs").on("click", function () {
    var studyId = $("#studId").val();
    var edcId = $("#Id").val();
    if (studyId == 0 && edcId == 0) { alert("Please select atleast one study or SAS  config record.") }
    else {
        window.location.href = "/Log/Logs" + "?studyId=" + studyId + "&edcId=" + edcId;
    }
});

function grid_dataSource_beforeSend(op, ajaxOptions) {
    ajaxOptions.headers = {
        RequestVerificationToken: "@Xsrf.GetAndStoreTokens(Model.HttpContext).RequestToken"
    };    
    ajaxOptions.data.notificationBell = $("#ErrorCountClick").val();
}