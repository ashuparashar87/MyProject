﻿

function configureDataGrid(dgId, offSwitchArray) {


    console.log('Entered configureDataGrid: The dgId is ' + dgId);

    var dgIdSelector = "#" + dgId;
    console.log('The dgIdSelector is ' + dgIdSelector);

    $(dgIdSelector).dxDataGrid({

        allowColumnReordering: true,

        allowColumnResizing: true,

        columnChooser: {
            enabled: true,
            search: {
                enabled: true
            },
            mode: "select"
        },

        grouping: {
            contextMenuEnabled: true
        },

        groupPanel: {
            visible: true
        },

        hoverStateEnabled: true,

        sorting: {
            mode: 'multiple',
        },

        onContextMenuPreparing: function (e) {
            if (e.target == "\content") {
                if (!e.items) e.items = [];
                e.items.push({
                    icon: "edit",
                    text: "Update",
                    disabled: ((typeof ContextMenuUpdateCommandDisabled === 'undefined') ? false : ContextMenuUpdateCommandDisabled),
                    visible: true,
                    onItemClick: () => DisplayPopupForEditAndDelete(e.row.key)
                });
            }
        },

        pager: {
            showPageSizeSelector: true,
            allowedPageSizes: [10, 25, 50, 100]
        },

        paging: {
            pageSize: 10
        },

        remoteOperations: false,

        rowAlternationEnabled: true,

        searchPanel: {
            visible: true,
            highlightCaseSensitive: true
        },
        onExporting: function (e) {
            var workbook = new ExcelJS.Workbook();
            var worksheet = workbook.addWorksheet('EDCISExport');
            DevExpress.excelExporter.exportDataGrid({
                component: e.component,
                worksheet: worksheet,
                autoFilterEnabled: true
            }).then(function () {
                workbook.xlsx.writeBuffer().then(function (buffer) {
                    saveAs(new Blob([buffer], { type: 'application/octet-stream' }), NameOfPluralEntities + '.xlsx');
                });
            });
            e.cancel = true;
        },
        showBorders: true,

    });

    $('#partialModal').on('show.bs.modal', function (event) {
        lblVal = $('#lblIdOnModal').html();
        console.log("partialModal shown with id = " + lblVal);
    })

}

$(configureDataGrid('dgMain', ['']));

window.jsPDF = window.jspdf.jsPDF;
applyPlugin(window.jsPDF);

function exportToPDF() {
    var doc = new jsPDF();
    var dataGrid = $("#dgMain").dxDataGrid("instance");
    DevExpress.pdfExporter.exportDataGrid({
        jsPDFDocument: doc,
        component: dataGrid
    }).then(function () {
        doc.save(NameOfPluralEntities + ".pdf");
    });
}


function ResetGridState(dataGridId) {
    //$FIX$/$FINISH$: The datagrid MUST be named "dgMain":
    if (confirm("This will remove all changes to the grid display (sorts, filters, columns, etc.). Are you sure you want to do this?")) {
        var dataGrid = $("#dgMain").dxDataGrid("instance");
        dataGrid.state(null);
    }
}
function DisplayPopupForAdd() {
    console.log("Handler for .click() called.");
    $.get(GetBlankEntityUrl, function (data, textStatus, jqXHR) {
        DisplaySuccessResults(data, textStatus, jqXHR);
        $("#partialModal").find(".modal-title").html("(New " + NameOfSingleEntity + ")");
        $("#partialModal").find(".modal-body").html("");
        $("#partialModal").find(".modal-body").html(data);
        $("#partialModal").find("#lblIdOnModal").text("(creating)");
        $("#partialModal").find("#partialModalCloseButton").show();
        $("#partialModal").find("#partialModalCreateButton").show();
        $("#partialModal").find("#partialModalSaveButton").hide();
        $("#partialModal").find("#partialModalDeleteButton").hide();
        $("#partialModal").modal('show');
    }).fail(function (jqXHR, textStatus, errorThrown) {
        DisplayFailureResults(jqXHR, textStatus, errorThrown);
    });
}


function DisplayPopupForEditAndDelete(key) {
    $('#lblIdOnModal').text(key);
    var Key = String(key);
    $.ajax({
        type: "GET",
        url: GetEntityUrl,
        data: { "key": Key },

        success: function (response) {
            $("#partialModal").find(".modal-title").html(NameOfSingleEntity);
            $("#partialModal").find(".modal-body").html("");  //Clear out for complete reload
            $("#partialModal").find(".modal-body").html(response);
            $("#partialModal").find("#partialModalCloseButton").show();
            $("#partialModal").find("#partialModalSaveButton").show();
            $("#partialModal").find("#partialModalDeleteButton").show();
            $("#partialModal").modal('show');
        },

        error: function (qXHR, textStatus, errorThrown) {
            results =
                "ERROR:\n" +
                JSON.stringify(jqXHR.responseText).substring(0, 400)
            $("#partialModal").find(".modal-body").html(results);
            $("#partialModal").modal('show');
        }
    });
}

function DisplayPopupForEditAndDelete(key) {
    $('#lblIdOnModal').text(key);

    var Key = String(key);

    $.ajax({
        type: "GET",
        url: GetEntityUrl,
        data: { "key": Key },

        success: function (response) {
            $("#partialModal").find(".modal-title").html(NameOfSingleEntity);
            $("#partialModal").find(".modal-body").html("");  //Clear out for complete reload
            $("#partialModal").find(".modal-body").html(response);
            $("#partialModal").find("#partialModalCloseButton").show();
            $("#partialModal").find("#partialModalCreateButton").hide();
            $("#partialModal").find("#partialModalSaveButton").show();
            $("#partialModal").find("#partialModalDeleteButton").show();
            $("#partialModal").modal('show');
        },

        error: function (qXHR, textStatus, errorThrown) {
            results =
                "ERROR:\n" +
                JSON.stringify(jqXHR.responseText).substring(0, 400)
            $("#partialModal").find(".modal-body").html(results);
            $("#partialModal").modal('show');
        }
    });
}



function ExecutePartialModalCreateButton() {
    var form = $('form');
    $.validator.unobtrusive.parse(form);
    var IsValid = form.validate().form();
    if (IsValid) {
        id = $('#lblIdOnModal').html();
        console.log('Starting post with id of ' + id);
        $.ajaxSetup({
            beforeSend: function (xhr) {
                xhr.setRequestHeader("RequestVerificationToken",
                    $('input:hidden[name="__RequestVerificationToken"]').val());
            }
        });
        $.post(PostCreateHandlerUrl, $('form').serialize(), function (data, textStatus, jqXHR) {
            DisplaySuccessResults(data, textStatus, jqXHR);
            if (jqXHR.status == 202) {
                console.log("Closing partialModal");
                $("#partialModal").modal('hide');
                $("#dgMain").dxDataGrid("instance").refresh();
            }
            else {
                   alert(data.Message);
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            DisplayFailureResults(jqXHR, textStatus, errorThrown);
        });
    }
}


function ExecutePartialModalSaveButton() {
    var form = $('form');
    $.validator.unobtrusive.parse(form);
    var IsValid = form.validate().form();
    if (IsValid) {
        id = $('#lblIdOnModal').html();
        console.log('Starting post with id of ' + id);
        $.ajaxSetup({
            beforeSend: function (xhr) {
                xhr.setRequestHeader("RequestVerificationToken",
                    $('input:hidden[name="__RequestVerificationToken"]').val());
            }
        });
        $.post(PostEditHandlerUrl, $('form').serialize(), function (data, textStatus, jqXHR) {
            DisplaySuccessResults(data, textStatus, jqXHR);
            if (jqXHR.status == 202) {
                $("#partialModal").modal('hide');
                $("#dgMain").dxDataGrid("instance").refresh();
            }
            else {
                alert(data.Message);
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            DisplayFailureResults(jqXHR, textStatus, errorThrown);
        });
    }
}



function OnRowDblClick(e) {
    DisplayPopupForEditAndDelete(e.key);
}

function OnCellHoverChanged(e) {
    e.component.focus(e.cellElement)
}


function DisplaySuccessResults(data, textStatus, jqXHR) {
    results =
        "SUCCESS: \n\n" +
        "textStatus=" + String(textStatus).substring(0, 200) + "\n\n" +
        "jqXHR=" + JSON.stringify(jqXHR).substring(0, 200) + "\n\n" +
        "data=" + JSON.stringify(data).substring(0, 200);
}

function DisplayFailureResults(jqXHR, textStatus, errorThrown) {
    results =
        "ERROR:\n" +
        JSON.stringify(jqXHR.responseText).substring(0, 400)
    alert(results);
}

function toggleVisibility(selector, animationInterval = 0) {
    var el = $(selector);
    el.is(':visible') ? el.hide(animationInterval) : el.show(animationInterval);
    return false;
}


function grid_dataSource_beforeSend(op, ajax) {
    ajax.headers = {
        RequestVerificationToken: "@Xsrf.GetAndStoreTokens(Model.HttpContext).RequestToken"
    };
}


$(function () { $('#partialModalCreateButton').on('click', ExecutePartialModalCreateButton) });
$(function () { $('#partialModalSaveButton').on('click', ExecutePartialModalSaveButton) });
$(function () { $('#partialModalDeleteButton').on('click', ExecutePartialModalDeleteButton) });

$('#btnTestConnection').on('click', ExecuteTestConnection);

function ExecuteTestConnection() {
    var IsFormValid = true;
    var data = {
        fileProtocol: $('#FileProtocol option:selected').text(),
        encryption: $('#Encryption option:selected').text(),
        hostName: $("#HostName").val(),
        userName: $("#UserName").val(),
        password: $("#Password").val(),
        portNumber: $("#PortNumber").val()
    }
    if (data.hostName == "") {
       
        setError("MainEntity.HostName", "Host Name field is required.");
        IsFormValid = false;
    } else {
        setError("MainEntity.HostName", "");
    }
    if (data.encryption == "") {

        setError("MainEntity.Encryption", "Encryption field is required.");
        IsFormValid = false;
    } else {
        setError("MainEntity.Encryption", "");
    }
    if (data.userName == "") {
        setError("MainEntity.UserName", "User Name field is required.");
        IsFormValid = false;
    } else {
        setError("MainEntity.UserName", "");
    }
    if (data.password == "") {
        setError("MainEntity.Password", "Password field is required.");
        IsFormValid = false;
    } else {
        setError("MainEntity.Password", "");
    }
    if (data.portNumber == "") {
        setError("MainEntity.PortNumber", "Port Number field is required.");
        IsFormValid = false;
    } else {
        setError("MainEntity.PortNumber", "");
    }

   
    if (IsFormValid) {
        $("#loading").show();
        var PostEDCConfigHandlerUrl = "/Admin/FTPSiteConfig?handler=TestConnection";
        $.ajaxSetup({
            beforeSend: function (xhr) {
                xhr.setRequestHeader("RequestVerificationToken",
                    $('input:hidden[name="__RequestVerificationToken"]').val());
            }
        });
        $.post(PostEDCConfigHandlerUrl, data, function (data, textStatus, jqXHR) {
            $("#loading").hide();
            alert(data.Message)
        })
    }
    else {
        $('#collapseOne').addClass('show');
        $("html, body").animate({ scrollTop: 0 });
    }
}

function setError(id, message) {
    var span = $("span[data-valmsg-for=\"" + id + "\"]");
    var elementId = ("#" + id.replaceAll(".", "_"));
    if (span && span.length > 0) {
        $(span).html(message);
        if (message && message != "") {
            $(span).removeClass("field-validation-valid");
            $(span).addClass("field-validation-no-valid");
            $(elementId).addClass("input-validation-error");
        } else {
            $(span).removeClass("field-validation-no-valid");
            $(span).addClass("field-validation-valid");
            $(elementId).removeClass("input-validation-error");
        }
    }
}

function ExecutePartialModalDeleteButton() {
    key = $('#lblIdOnModal').html();
    console.log('Starting Delete get with id of ' + key);
    if (!confirm('Are you sure you want to delete this record?')) {
        return;
    }
    $.get(PostDeleteHandlerUrl + key, function (data, textStatus, jqXHR) {
        DisplaySuccessResults(data, textStatus, jqXHR);
        if (jqXHR.status == 202) {
            $("#partialModal").modal('hide');
            $("#dgMain").dxDataGrid("instance").refresh();
        }
        else {
            if (data.IsSuccess) {
               alert(data.Message);
            }
        }
    }).fail(function (jqXHR, textStatus, errorThrown) {
        DisplayFailureResults(jqXHR, textStatus, errorThrown);
    });
}




$(".closebtn").on("click", function () {
    if (IsFormChanged) {
        if (confirm("Changes you made may not be saved.") == true) {
            $('#partialModal').modal('toggle');           
        } else {
            return;
        }
    } else {
        $('#partialModal').modal('toggle');
    }
})