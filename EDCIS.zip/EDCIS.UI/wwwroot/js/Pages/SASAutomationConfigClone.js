﻿
function configureDataGrid(dgId, offSwitchArray) {
    console.log('Entered configureDataGrid: The dgId is ' + dgId);
    var dgIdSelector = "#" + dgId;
    console.log('The dgIdSelector is ' + dgIdSelector);

    $(dgIdSelector).dxDataGrid({

        allowColumnReordering: true,

        allowColumnResizing: true,

        columnChooser: {
            enabled: true,
            allowSearch: true,
            mode: "select"
        },

        grouping: {                 
            contextMenuEnabled: true
        },

        groupPanel: {
            visible: true  
        },

        hoverStateEnabled: true,
        onContextMenuPreparing: function (e) {
            if (e.target == "\content") {                
                if (!e.items) e.items = [];
            }
        },

        pager: {
            showPageSizeSelector: true,
            allowedPageSizes: [10, 25, 50, 100]
        },

        paging: {
            pageSize: 10
        },

        remoteOperations: false,

        rowAlternationEnabled: true,

        searchPanel: {
            visible: true,
            highlightCaseSensitive: true
        },

        showBorders: true,

    });

    $('#partialModal').on('show.bs.modal', function (event) {   
        lblVal = $('#lblIdOnModal').html();
        console.log("partialModal shown with id = " + lblVal);
    })

}

$(configureDataGrid('dgClone', ['']));
function ResetGridState(dgClone) {
    if (confirm("This will remove all changes to the grid display (sorts, filters, columns, etc.). Are you sure you want to do this?")) {
        var dataGrid = $("#" + dgClone).dxDataGrid("instance");
        dataGrid.state({});
    }
}
$('#btnClone').on('click', configClone);

function configClone() {
    var currentRowId = $("#cloneStudyId").val();
    const PostCloneHandlerUrl = "/Home/Home?handler=Clone";
    $.post(PostCloneHandlerUrl, { studyId: currentRowId, __RequestVerificationToken: $('#hfAntiToken').val() }, function (data, textStatus, jqXHR) {
        if (data.IsSuccess) {
            alert(data.Message)
            window.location.href = "/Home/SASAutomationConfig" + "?key=" + data.Key + "&StudyId=" + currentRowId + "&IsParent=false" + "&timezoneDetail=" + timezoneDetail;                
            
         
        }
        else {
            alert(data.Message)
        }
    }).fail(function (jqXHR, textStatus, errorThrown) {
        DisplayFailureResults(jqXHR, textStatus, errorThrown);
    });
}

function DisplaySuccessResults(data, textStatus, jqXHR) {   
    results =
        "SUCCESS: \n\n" +
        "textStatus=" + String(textStatus).substring(0, 200) + "\n\n" +
        "jqXHR=" + JSON.stringify(jqXHR).substring(0, 200) + "\n\n" +
        "data=" + JSON.stringify(data).substring(0, 200);  
}

function DisplayFailureResults(jqXHR, textStatus, errorThrown) {    
    results =
        "ERROR:\n" +
            JSON.stringify(jqXHR.responseText).substring(0, 400)     
    alert(results);
}

function toggleVisibility(selector, animationInterval = 0) {
    var el = $(selector);
    el.is(':visible') ? el.hide(animationInterval) : el.show(animationInterval);
    return false;
}

function grid_dataSource_beforeSend(op, ajax) {
    ajax.headers = {
        RequestVerificationToken: "@Xsrf.GetAndStoreTokens(Model.HttpContext).RequestToken"
    };
}

