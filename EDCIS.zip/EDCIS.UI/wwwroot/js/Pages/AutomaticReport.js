﻿$(document).ready(function () {
    $("#success-message").fadeTo(5000, 500).slideUp(500, function () {
        $("#success-message").slideUp(500);
        window.scrollTo(0, 0);
    });
    $("#SelectStudy").select2();
    $("#SelectInitialBy").select2();
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth(), now.getDay()-1200);   
    const max = new Date(now);
    const min = new Date(lastDay);
    $("#fromDate").val(formatDate(min));
    $("#toDate").val(formatDate(max));
    $("#dateRangeBox").dxDateRangeBox({
        value: [new Date(min), new Date(max)],
        displayFormat: 'dd-MMM-yyyy',
        onValueChanged: function (e) {
            var startDate = e.value[0];
            var endDate = e.value[1];
            $("#fromDate").val(formatDate(startDate));
            $("#toDate").val(formatDate(endDate));
        }
    });
});

function formatDate(date) {
    if (date != null) {
        let year = date.getFullYear();
        let month = String(date.getMonth() + 1).padStart(2, '0');
        let day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    else {
        return;
    }
}
function configureDataGrid(dgId, offSwitchArray) {


    console.log('Entered configureDataGrid: The dgId is ' + dgId);

    var dgIdSelector = "#" + dgId;
    console.log('The dgIdSelector is ' + dgIdSelector);

    $(dgIdSelector).dxDataGrid({

        allowColumnReordering: true,

        allowColumnResizing: true,

        columnChooser: {
            enabled: true,
            search: {
                enabled: true
            },
            mode: "select"
        },

        grouping: {
            contextMenuEnabled: true
        },

        groupPanel: {
            visible: true
        },

        hoverStateEnabled: true,

        sorting: {
            mode: 'multiple',
        },
        pager: {
            showPageSizeSelector: true,
            allowedPageSizes: [10, 25, 50, 100]
        },

        paging: {
            pageSize: 10
        },

        remoteOperations: false,

        rowAlternationEnabled: true,

        searchPanel: {
            visible: true,
            highlightCaseSensitive: true
        },
        onExporting: function (e) {
            var workbook = new ExcelJS.Workbook();
            var worksheet = workbook.addWorksheet('EDCISExport');
            DevExpress.excelExporter.exportDataGrid({
                component: e.component,
                worksheet: worksheet,
                autoFilterEnabled: true
            }).then(function () {
                workbook.xlsx.writeBuffer().then(function (buffer) {
                    saveAs(new Blob([buffer], { type: 'application/octet-stream' }), 'AutomationReport.xlsx');
                });
            });
            e.cancel = true;
        },
        showBorders: true,

    });

    $('#partialModal').on('show.bs.modal', function (event) {
        lblVal = $('#lblIdOnModal').html();
        console.log("partialModal shown with id = " + lblVal);
    })

}

$(configureDataGrid('dgMain', ['']));

function grid_dataSource_Loaded(op,ajaxOptions)
{
    var gridData = $("#dgMain").dxDataGrid("instance");  
    if (($("#ChgroupByStudy").prop('checked') == true) && ($("#ChgroupByInitiator").prop('checked') == true)) {
        gridData.columnOption(2, "visible", true);
        gridData.columnOption(3, "visible", true);
        gridData.columnOption(4, "visible", true);
    }
    else if ($("#ChgroupByStudy").prop('checked') == true) {
        gridData.columnOption(2, "visible", true);
        gridData.columnOption(3, "visible", true);
        gridData.columnOption(4, "visible", false);
    }
    else if ($("#SelectStudy option:selected").val() != 0) {
        gridData.columnOption(2, "visible", true);
        gridData.columnOption(3, "visible", true);
        gridData.columnOption(4, "visible", false);
    }
    else if ($("#ChgroupByInitiator").prop('checked') == true) {
        gridData.columnOption(2, "visible", false);
        gridData.columnOption(3, "visible", false);
        gridData.columnOption(4, "visible", true);
    }
    else if ($("#SelectInitialBy option:selected").val() != "All") {
        gridData.columnOption(2, "visible", false);
        gridData.columnOption(3, "visible", false);
        gridData.columnOption(4, "visible", true);
    }
    else {
        gridData.columnOption(2, "visible", false);
        gridData.columnOption(3, "visible", false);
        gridData.columnOption(4, "visible", false);
    }
}
function grid_dataSource_beforeSend(op, ajaxOptions) {
    ajaxOptions.headers = {
        RequestVerificationToken: "@Xsrf.GetAndStoreTokens(Model.HttpContext).RequestToken"
    };
    ajaxOptions.data.studyId = $("#SelectStudy option:selected").val();
    ajaxOptions.data.initialBy = $("#SelectInitialBy option:selected").val();
    ajaxOptions.data.fromDate = $("#fromDate").val();
    ajaxOptions.data.thruDate = $("#toDate").val();
    ajaxOptions.data.groupByStudy = $("#ChgroupByStudy").prop('checked');
    ajaxOptions.data.groupByIntitate = $("#ChgroupByInitiator").prop('checked')
}

//$("#SelectStudy").on("change", function () {
//   // $("#dgMain").dxDataGrid("instance").refresh();
//    var gridData = $("#dgMain").dxDataGrid("instance");
//    gridData.refresh();
//    console.log(gridData);
//    gridData.columnOption(2, "visible", false);
//});

//$("#SelectInitialBy").on("change", function () {
//    $("#dgMain").dxDataGrid("instance").refresh();
//});

$("#RefreshBtn").on("click", function () {
        var gridData = $("#dgMain").dxDataGrid("instance");
        gridData.refresh();
    console.log(gridData);
    if (($("#ChgroupByStudy").prop('checked') == true) && ($("#ChgroupByInitiator").prop('checked') == true)) {      
        gridData.columnOption(2, "visible", true);
        gridData.columnOption(3, "visible", true);
        gridData.columnOption(4, "visible", true);
    }
    else if ($("#ChgroupByStudy").prop('checked') == true) {
        gridData.columnOption(2, "visible", true);
        gridData.columnOption(3, "visible", true);
        gridData.columnOption(4, "visible", false);
    }
    else if ($("#SelectStudy option:selected").val()!=0) {
        gridData.columnOption(2, "visible", true);
        gridData.columnOption(3, "visible", true);
        gridData.columnOption(4, "visible", false);
    }
    else if ($("#ChgroupByInitiator").prop('checked') == true) {
        gridData.columnOption(2, "visible", false);
        gridData.columnOption(3, "visible", false);
        gridData.columnOption(4, "visible", true);
    }
    else if ($("#SelectInitialBy option:selected").val() !="All") {
        gridData.columnOption(2, "visible", false);
        gridData.columnOption(3, "visible", false);
        gridData.columnOption(4, "visible", true);
    }
    else {       
        gridData.columnOption(2, "visible", false);
        gridData.columnOption(3, "visible", false);
        gridData.columnOption(4, "visible", false);
    }
    
})

window.jsPDF = window.jspdf.jsPDF;
applyPlugin(window.jsPDF);

function exportToPDF() {
    var doc = new jsPDF();
    var dataGrid = $("#dgMain").dxDataGrid("instance");
    DevExpress.pdfExporter.exportDataGrid({
        jsPDFDocument: doc,
        component: dataGrid
    }).then(function () {
        doc.save("AutomationReport.pdf");
    });
}


function ResetGridState(dataGridId) {
    //$FIX$/$FINISH$: The datagrid MUST be named "dgMain":
    if (confirm("This will remove all changes to the grid display (sorts, filters, columns, etc.). Are you sure you want to do this?")) {
        var dataGrid = $("#dgMain").dxDataGrid("instance");
        dataGrid.state(null);
    }
}

