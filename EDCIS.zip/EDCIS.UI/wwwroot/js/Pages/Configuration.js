﻿
function configureDataGrid(dgId, offSwitchArray) {


    console.log('Entered configureDataGrid: The dgId is ' + dgId);

    var dgIdSelector = "#" + dgId;
    console.log('The dgIdSelector is ' + dgIdSelector);

    $(dgIdSelector).dxDataGrid({

        allowColumnReordering: true,

        allowColumnResizing: true,

        columnChooser: {
            enabled: true,
            allowSearch: true,
            mode: "select"
        },

        grouping: {
            contextMenuEnabled: true
        },

        groupPanel: {
            visible: true
        },

        hoverStateEnabled: true,

        sorting: {
            mode: 'multiple',
        },

        onContextMenuPreparing: function (e) {
            if (e.target == "\content") {
                if (!e.items) e.items = [];

                e.items.push({
                    icon: "edit",
                    text: "Edit",
                    disabled: ((typeof ContextMenuUpdateCommandDisabled === 'undefined') ? false : ContextMenuUpdateCommandDisabled),
                    visible: true,
                    onItemClick: () => DisplayPopupForEditAndDelete(e.row.key)
                });

            }
        },

        pager: {
            showPageSizeSelector: true,
            allowedPageSizes: [10, 25, 50, 100]
        },

        paging: {
            pageSize: 10
        },

        remoteOperations: false,

        rowAlternationEnabled: true,

        searchPanel: {
            visible: true,
            highlightCaseSensitive: true
        },

        showBorders: true,

    });

    $('#partialModal').on('show.bs.modal', function (event) {
        lblVal = $('#lblIdOnModal').html();
        console.log("partialModal shown with id = " + lblVal);
    })

}

$(configureDataGrid('dgMain', ['']));


function exportToExcel(e) {
    //2022-05-18 RMcQ: Used for export to Excel.
    //See https://js.devexpress.com/Documentation/ApiReference/UI_Components/dxDataGrid/Configuration/export/ 
    //for a more comprehensive description: 
    var workbook = new ExcelJS.Workbook();
    var worksheet = workbook.addWorksheet('CTMS Replica Export');
    DevExpress.excelExporter.exportDataGrid({
        component: e.component,
        worksheet: worksheet,
        autoFilterEnabled: true
    }).then(function () {
        workbook.xlsx.writeBuffer().then(function (buffer) {
            saveAs(new Blob([buffer], { type: 'application/octet-stream' }), NameOfPluralEntities + '.xlsx');
        });
    });
    e.cancel = true;
}


window.jsPDF = window.jspdf.jsPDF;
applyPlugin(window.jsPDF);

function exportToPDF() {
    var doc = new jsPDF();
    var dataGrid = $("#dgMain").dxDataGrid("instance");
    DevExpress.pdfExporter.exportDataGrid({
        jsPDFDocument: doc,
        component: dataGrid
    }).then(function () {
        doc.save(NameOfPluralEntities + ".pdf");
    });
}


function ResetGridState(dataGridId) {
    //$FIX$/$FINISH$: The datagrid MUST be named "dgMain":
    if (confirm("This will remove all changes to the grid display (sorts, filters, columns, etc.). Are you sure you want to do this?")) {
        var dataGrid = $("#dgMain").dxDataGrid("instance");
        dataGrid.state(null);
    }
}



function ExecutePartialModalSaveButton() {
    var form = $('form');
    $.validator.unobtrusive.parse(form);
    var IsValid = form.validate().form();
    if (IsValid) {
        id = $('#lblIdOnModal').html();
        console.log('Starting post with id of ' + id);
        $.ajaxSetup({
            beforeSend: function (xhr) {
                xhr.setRequestHeader("RequestVerificationToken",
                    $('input:hidden[name="__RequestVerificationToken"]').val());
            }
        });
        $.post(PostEditHandlerUrl, $('form').serialize(), function (data, textStatus, jqXHR) {
            DisplaySuccessResults(data, textStatus, jqXHR);
            if (jqXHR.status == 202) {
                $("#partialModal").modal('hide');
                $("#dgMain").dxDataGrid("instance").refresh();
            }
            else {
                $("#partialModal").find(".modal-body").html(data);
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            DisplayFailureResults(jqXHR, textStatus, errorThrown);
        });
    }
}




function DisplayPopupForEditAndDelete(key) {
    $('#lblIdOnModal').text(key);
    var Key = String(key);
    $.ajax({
        type: "GET",
        url: GetEntityUrl,
        data: { "key": Key },

        success: function (response) {
            $("#partialModal").find(".modal-title").html(NameOfSingleEntity);
            $("#partialModal").find(".modal-body").html("");  //Clear out for complete reload
            $("#partialModal").find(".modal-body").html(response);
            $("#partialModal").find("#partialModalCloseButton").show();
            $("#partialModal").find("#partialModalCreateButton").hide();
            $("#partialModal").find("#partialModalSaveButton").show();
            $("#partialModal").find("#partialModalDeleteButton").show();
            $("#partialModal").modal('show');
        },

        error: function (qXHR, textStatus, errorThrown) {
            results =
                "ERROR:\n" +
                JSON.stringify(jqXHR.responseText).substring(0, 400)
            $("#partialModal").find(".modal-body").html(results);
            $("#partialModal").modal('show');
        }
    });
}




function OnRowDblClick(e) {
    DisplayPopupForEditAndDelete(e.key);
}

function OnCellHoverChanged(e) {
    e.component.focus(e.cellElement)
}


function DisplaySuccessResults(data, textStatus, jqXHR) {
    results =
        "SUCCESS: \n\n" +
        "textStatus=" + String(textStatus).substring(0, 200) + "\n\n" +
        "jqXHR=" + JSON.stringify(jqXHR).substring(0, 200) + "\n\n" +
        "data=" + JSON.stringify(data).substring(0, 200);
}

function DisplayFailureResults(jqXHR, textStatus, errorThrown) {
    results =
        "ERROR:\n" +
        JSON.stringify(jqXHR.responseText).substring(0, 400)
    alert(results);
}

function toggleVisibility(selector, animationInterval = 0) {
    var el = $(selector);
    el.is(':visible') ? el.hide(animationInterval) : el.show(animationInterval);
    return false;
}




function grid_dataSource_beforeSend(op, ajax) {
    ajax.headers = {
        RequestVerificationToken: "@Xsrf.GetAndStoreTokens(Model.HttpContext).RequestToken"
    };
}

$(function () { $('#partialModalSaveButton').on('click', ExecutePartialModalSaveButton) });