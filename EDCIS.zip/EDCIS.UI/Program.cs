using EDCIS.Application;
using EDCIS.Infrastructure;
using EDCIS.Infrastructure.Persistence;
using EDCIS.UI;
using EDCIS.UI.Pages.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
var isAuthenticationFeatureFlag = Convert.ToBoolean(builder.Configuration["AuthenticationFeatureToggle:IsFeatureEnabled"]);
// Add services to the container.
builder.Services.AddRazorPages().AddJsonOptions(options => options.JsonSerializerOptions.PropertyNamingPolicy = null);
builder.Logging.ClearProviders();
builder.Services.AddApplicationServices(builder.Configuration);
builder.Services.AddIdentityServices(builder.Configuration);
builder.Services.AddInfrastructureServices(builder.Configuration, builder.Environment.IsDevelopment());
builder.Services.AddUIServices(builder.Configuration);



var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var logger = services.GetService<ILogger<EDCISContextSeed>>();
    var context = services.GetRequiredService<EDCISContext>();
    context.Database.SetCommandTimeout(300);
    bool isDatabaseCreated = await context.Database.EnsureCreatedAsync();   
    bool seedDemoData = (builder.Configuration["SeedDemoData"] == "true");
    var message = EDCISContextSeed.UpdateDatabase(context, logger!, isDatabaseCreated);
    if (message.IsSucess == true)
    {
        EDCISContextSeed.SeedAsync(context, logger, seedDemoData).Wait();
    }
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}
app.UseDeveloperExceptionPage();
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();
app.UseMiddleware<UserMiddleware>();
app.UseMiddleware<ApplicationExceptionMiddleware>();
app.MapRazorPages();

app.UseEndpoints(endpoints =>
{
    if (isAuthenticationFeatureFlag)
    {
        // Require Authorization for all your Razor Pages
        endpoints.MapRazorPages().RequireAuthorization();
    }
    else
    {
        endpoints.MapRazorPages().AllowAnonymous();
    }
});

app.Run();

    