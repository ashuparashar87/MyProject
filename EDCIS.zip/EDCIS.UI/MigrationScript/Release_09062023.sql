﻿
BEGIN TRY

IF NOT EXISTS (SELECT 1  FROM [dbo].[EDCISConfiguration]
                WHERE [Key] = 'IsInMaintenanceMode')

BEGIN 
INSERT INTO [dbo].[EDCISConfiguration]
           ([Key]
           ,[Value]
           ,[Description]
           ,[CreatedBy]
           ,[CreatedDate] )
     VALUES
           ('IsInMaintenanceMode'
           ,0
           ,'The EDCIS Web Application is currently in Maintenance Mode. Value “1” indicates Maintenance is going on, replace it with “0” to reset the flag.'
           ,'SystemUser@advancedgroup.com'
           ,GETUTCDATE())

END

END TRY
BEGIN CATCH
  throw  select ERROR_NUMBER() , ERROR_LINE() , ERROR_MESSAGE();
END CATCH;






