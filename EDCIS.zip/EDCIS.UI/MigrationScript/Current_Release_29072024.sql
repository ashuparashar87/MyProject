﻿  
BEGIN TRY

	IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS   WHERE [TABLE_NAME] = 'SASAutomationConfig' AND COLUMN_NAME ='ErrorEmailRecipients')
    BEGIN 
	ALTER TABLE  [dbo].[SASAutomationConfig] ADD ErrorEmailRecipients nvarchar(4000);
    END
	IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS   WHERE [TABLE_NAME] = 'SASAutomationConfig' AND COLUMN_NAME ='SuccessEmailRecipients')
    BEGIN 
	ALTER TABLE  [dbo].[SASAutomationConfig] ADD SuccessEmailRecipients nvarchar(4000);
    END
	IF NOT EXISTS ( SELECT 1  FROM INFORMATION_SCHEMA.COLUMNS
		WHERE [TABLE_NAME] = 'SASAutomationConfig' and  COLUMN_NAME = 'LastSASLaunchDateTime')
		BEGIN		
		ALTER TABLE SASAutomationConfig  ADD LastSASLaunchDateTime [datetime2](7) NULL
  END
  IF NOT EXISTS ( SELECT 1  FROM INFORMATION_SCHEMA.COLUMNS
		WHERE [TABLE_NAME] = 'SASAutomationConfig' and  COLUMN_NAME = 'LastErrorDateTime')
		BEGIN		
		ALTER TABLE SASAutomationConfig  ADD LastErrorDateTime [datetime2](7) NULL
  END
   
  IF NOT EXISTS ( SELECT 1  FROM INFORMATION_SCHEMA.COLUMNS
		WHERE [TABLE_NAME] = 'SASAutomationConfig' and  COLUMN_NAME = 'LastError')
		BEGIN		
		ALTER TABLE SASAutomationConfig  ADD LastError [nvarchar](4000) null
  END
	IF NOT EXISTS ( SELECT 1  FROM INFORMATION_SCHEMA.COLUMNS
		WHERE [TABLE_NAME] = 'SASAutomationConfig' and  COLUMN_NAME = 'CanRunStatistician')
		BEGIN		
		ALTER TABLE SASAutomationConfig  ADD CanRunStatistician BIT not null default 0
  END
  IF NOT EXISTS ( SELECT 1  FROM INFORMATION_SCHEMA.COLUMNS
		WHERE [TABLE_NAME] = 'SASAutomationConfig' and  COLUMN_NAME = 'CanDMRUN')
		BEGIN		
		ALTER TABLE SASAutomationConfig  ADD CanDMRUN BIT not null default 0
  END
  IF NOT EXISTS ( SELECT 1  FROM INFORMATION_SCHEMA.COLUMNS
		WHERE [TABLE_NAME] = 'SASAutomationConfig' and  COLUMN_NAME = 'ExecuteProgramAfterTransfer')
		BEGIN		
		ALTER TABLE SASAutomationConfig  ADD ExecuteProgramAfterTransfer BIT not null default 0
  END
  IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS  
  WHERE [TABLE_NAME] = 'SASAutomationConfig' AND COLUMN_NAME ='Description')
    BEGIN 
	ALTER TABLE  [dbo].[SASAutomationConfig] ADD Description  nvarchar(300);
    END
	 IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS  
  WHERE [TABLE_NAME] = 'SASAutomationConfig' AND COLUMN_NAME ='File')
    BEGIN 
	ALTER TABLE  [dbo].[SASAutomationConfig] ADD [File] nvarchar(300);
    END
	 IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS  
  WHERE [TABLE_NAME] = 'SASAutomationConfig' AND COLUMN_NAME ='Path')
    BEGIN 
	ALTER TABLE  [dbo].[SASAutomationConfig] ADD [Path] nvarchar(300);
    END
	 IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS  
  WHERE [TABLE_NAME] = 'SASAutomationConfig' AND COLUMN_NAME ='Arguments')
    BEGIN 
	ALTER TABLE  [dbo].[SASAutomationConfig] ADD [Arguments] nvarchar(300);
    END
	 IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS  
  WHERE [TABLE_NAME] = 'SASAutomationConfig' AND COLUMN_NAME ='TimeoutInSeconds')
    BEGIN 
	ALTER TABLE  [dbo].[SASAutomationConfig] ADD TimeoutInSeconds int not null default  60
    END
   IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS  
  WHERE [TABLE_NAME] = 'SASAutomationConfig' AND COLUMN_NAME ='LastSASLogFile')
    BEGIN 
	ALTER TABLE  [dbo].[SASAutomationConfig] ADD [LastSASLogFile] nvarchar(300);
    END
	 IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS  
     WHERE [TABLE_NAME] = 'SASAutomationConfig' AND COLUMN_NAME ='ConfigurationType')
    BEGIN 
	ALTER TABLE  [dbo].[SASAutomationConfig] ADD [ConfigurationType] nvarchar(30);
    END
   
	IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS   WHERE [TABLE_NAME] = 'HistoryLog' AND COLUMN_NAME ='InitiatedBy')
    BEGIN 
	ALTER TABLE  [dbo].[HistoryLog] ADD InitiatedBy nvarchar(50);
    END
IF  EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS   WHERE [TABLE_NAME] = 'SASAutomationConfig')
BEGIN 	
	ALTER TABLE  [dbo].[SASAutomationConfig] ALTER COLUMN [SourceFTPSite] nvarchar(max) NULL; 
	ALTER TABLE  [dbo].[SASAutomationConfig] ALTER COLUMN [SourceFileProtocol] nvarchar(10) NULL; 
	ALTER TABLE  [dbo].[SASAutomationConfig] ALTER COLUMN [SourceEncryption] nvarchar(10) NULL; 
	ALTER TABLE  [dbo].[SASAutomationConfig] ALTER COLUMN [SourceHostName] nvarchar(100) NULL; 
	ALTER TABLE  [dbo].[SASAutomationConfig] ALTER COLUMN [SourceUserName] nvarchar(100) NULL; 
	ALTER TABLE  [dbo].[SASAutomationConfig] ALTER COLUMN [SourcePassword] nvarchar(100) NULL; 
	ALTER TABLE  [dbo].[SASAutomationConfig] ALTER COLUMN [SourceFileName] nvarchar(100) NULL; 
	ALTER TABLE  [dbo].[SASAutomationConfig] ALTER COLUMN [SourceFolderPath] nvarchar(max) NULL; 
	ALTER TABLE  [dbo].[SASAutomationConfig] ALTER COLUMN [DestFTPSite] nvarchar(max) NULL; 
	ALTER TABLE  [dbo].[SASAutomationConfig] ALTER COLUMN [DestFileProtocol] nvarchar(100) NULL; 
	ALTER TABLE  [dbo].[SASAutomationConfig] ALTER COLUMN [DestHostName] nvarchar(100) NULL; 
	ALTER TABLE  [dbo].[SASAutomationConfig] ALTER COLUMN [DestUserName] nvarchar(100) NULL; 
	ALTER TABLE  [dbo].[SASAutomationConfig] ALTER COLUMN [ArchiveDestFolderPath] nvarchar(1000) NULL; 
	ALTER TABLE  [dbo].[SASAutomationConfig] ALTER COLUMN [CurrentDestFolderPath] nvarchar(1000) NULL; 
END
	
IF EXISTS ( SELECT 1 FROM [dbo].[HistoryLog])
BEGIN
EXEC( '
UPDATE dbo.HistoryLog SET Process=''ErrorCleaningCurrentFolder''	WHERE LogDetails LIKE ''Error Cleaning Current Folder%''
UPDATE dbo.HistoryLog SET Process=''ErrorConnectingToDestination''	WHERE LogDetails LIKE ''Error Connecting to Destination%''
UPDATE dbo.HistoryLog SET Process=''FileCopied''					WHERE LogDetails LIKE ''Successfully Copied%''
UPDATE dbo.HistoryLog SET Process=''ErrorCopyingFile''				WHERE LogDetails LIKE ''Error Copying%''
UPDATE dbo.HistoryLog SET Process=''FileUnzipStarted''				WHERE LogDetails LIKE ''Starting Unzip of%''
UPDATE dbo.HistoryLog SET Process=''ErrorUnzippingFile''			WHERE LogDetails LIKE ''Error Unzipping%''
UPDATE dbo.HistoryLog SET Process=''PurgeDestArchiveSuccess''		WHERE LogDetails LIKE ''Successfully Purged Destination Archive Folder%''
UPDATE dbo.HistoryLog SET Process=''ErrorPurgingDestArchive''		WHERE LogDetails LIKE ''Error Purging Destination Archive Folder%''
UPDATE dbo.HistoryLog SET Process=''PurgeHistoryLogsSuccess''		WHERE LogDetails LIKE ''Successfully Purged History Logs%''
UPDATE dbo.HistoryLog SET Process=''ConfigurationStart''			WHERE LogDetails LIKE ''Starting Run for Configuration%''
UPDATE dbo.HistoryLog SET Process=''SourceConnection''				WHERE LogDetails LIKE ''Successfully Connected to Source%''
UPDATE dbo.HistoryLog SET Process=''ErrorConnectingToSource''		WHERE LogDetails LIKE ''Error Connecting to Source%''
UPDATE dbo.HistoryLog SET Process=''NewMatchinFileFound''			WHERE LogDetails LIKE ''New Matching File Found:%''
UPDATE dbo.HistoryLog SET Process=''SASAutomationStart''		    WHERE LogDetails LIKE ''Started SAS Automation%''
UPDATE dbo.HistoryLog SET Process=''SourceDeletionNotConfigured''	WHERE LogDetails LIKE ''Source Deletion Not Configured for Source Folder%''
UPDATE dbo.HistoryLog SET Process=''ErrorDeletingSourceFile''		WHERE LogDetails LIKE ''Error Deleting Source File%''
UPDATE dbo.HistoryLog SET Process=''SASProgramLaunching''			WHERE LogDetails LIKE ''Launching SAS Program%''
UPDATE dbo.HistoryLog SET Process=''SASProgramLaunched''			WHERE LogDetails LIKE ''Successfully Launched SAS Program%''
UPDATE dbo.HistoryLog SET Process=''ErrorLaunchingSASProgram''		WHERE LogDetails LIKE ''Error Launching SAS Program%''
');
End



IF NOT EXISTS (SELECT 1  FROM [dbo].[EDCISConfiguration]
                WHERE [Key] = 'SASProgramFile')

BEGIN 
INSERT INTO [dbo].[EDCISConfiguration]
           ([Key]
           ,[Value]
           ,[Description]
           ,[CreatedBy]
           ,[CreatedDate] )
     VALUES
           ('SASProgramFile'
           ,'E:\SASHome\SASFoundation\9.4\Sas.exe'
           ,'The EDCIS SASProgramFile  '
           ,'SystemUser@advancedgroup.com'
           ,GETUTCDATE())

END
IF NOT EXISTS (SELECT 1  FROM [dbo].[EDCISConfiguration]
                WHERE [Key] = 'SASProgramTimeout')

BEGIN 
INSERT INTO [dbo].[EDCISConfiguration]
           ([Key]
           ,[Value]
           ,[Description]
           ,[CreatedBy]
           ,[CreatedDate] )
     VALUES
           ('SASProgramTimeout'
           ,60
           ,'The EDCIS SASProgramTimeout  '
           ,'SystemUser@advancedgroup.com'
           ,GETUTCDATE())

END
IF NOT EXISTS (SELECT 1  FROM [dbo].[EDCISConfiguration]
                WHERE [Key] = 'SASProgramArguments')

BEGIN 
INSERT INTO [dbo].[EDCISConfiguration]
           ([Key]
           ,[Value]
           ,[Description]
           ,[CreatedBy]
           ,[CreatedDate] )
     VALUES
           ('SASProgramArguments'
           ,'-sysin "{0}" -config "E:\SASHome\SASFoundation\9.4\sasv9.cfg" -NOTERMINAL -NOSPLASH -NOSTATUSWIN -NOICON'
           ,'The EDCIS SASProgramArguments  '
           ,'SystemUser@advancedgroup.com'
           ,GETUTCDATE())

END
IF  EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE [TABLE_NAME] = 'SASAutomationConfig' AND COLUMN_NAME ='File')
BEGIN 
    ALTER TABLE [dbo].[SASAutomationConfig]  DROP COLUMN [File];
END
IF  EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS  WHERE [TABLE_NAME] = 'SASAutomationConfig' AND COLUMN_NAME ='Arguments')
BEGIN 
    ALTER TABLE [dbo].[SASAutomationConfig]  DROP COLUMN [Arguments];
END

IF  EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE [TABLE_NAME] = 'SASAutomationConfig' AND COLUMN_NAME ='ConfigurationType')
BEGIN 
    EXEC( ' UPDATE [dbo].[SASAutomationConfig] SET ConfigurationType=''FileTransfer''	WHERE ConfigurationType IS NULL;');
END


IF NOT EXISTS ( SELECT 1 FROM sys.indexes WHERE name = 'IX_HistoryLogComposite')
BEGIN
CREATE INDEX IX_HistoryLogComposite
ON [dbo].[HistoryLog] ([TimeStamp], StudyID,InitiatedBy);

END


IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'GetAutomationReport')  
BEGIN

	EXEC('CREATE OR ALTER   PROCEDURE [dbo].[GetAutomationReport]		
(@fromDate date,
@toDate date,
@studyId bigint=0,
@initiatedBy nvarchar(50)=NULL,
@groupByStudy bit,
@groupByInitiated bit)
AS
BEGIN
IF(@studyId>0 AND (@initiatedBy!='''' AND @initiatedBy!=''All'') AND @groupByStudy=1 AND @groupByInitiated=1)
	BEGIN
	Print ''1''
		SELECT  StudyID,DATEPART(month, TimeStamp)TimeStampMonth,DATEPART(YEAR, TimeStamp)TimeStampYear,InitiatedBy,
		COUNT(CASE WHEN Process=''SASAutomationStart'' THEN 0 END)NumberConfigsRun,
		COUNT(CASE WHEN Process=''FileCopied'' THEN 0 END)NumberFilesTransferred,
		COUNT(CASE WHEN Process=''FileUnzipSuccess'' THEN 0 END)NumberFilesUnzipped,
		COUNT(CASE WHEN Process=''SASProgramLaunched'' THEN 0 END)NumberSasProgramsRun,
		COUNT(CASE WHEN Process like ''Error%'' THEN 0 END)NumberErrors
		FROM dbo.HistoryLog  
			WHERE TimeStamp BETWEEN @fromDate AND @toDate
			AND StudyID=@studyId AND InitiatedBy=@initiatedBy 
			GROUP BY StudyID,DATEPART(month, TimeStamp),DATEPART(YEAR, TimeStamp),InitiatedBy
			ORDER BY 1 DESC
	END
ELSE IF(@studyId>0 AND (@initiatedBy='''' OR @initiatedBy=''All'') AND @groupByStudy=1 AND @groupByInitiated=0)
	BEGIN
	Print ''2''
		SELECT  StudyID,DATEPART(month, TimeStamp)TimeStampMonth,DATEPART(YEAR, TimeStamp)TimeStampYear,''All'' AS InitiatedBy,
		COUNT(CASE WHEN Process=''SASAutomationStart'' THEN 0 END)NumberConfigsRun,
		COUNT(CASE WHEN Process=''FileCopied'' THEN 0 END)NumberFilesTransferred,
		COUNT(CASE WHEN Process=''FileUnzipSuccess'' THEN 0 END)NumberFilesUnzipped,
		COUNT(CASE WHEN Process=''SASProgramLaunched'' THEN 0 END)NumberSasProgramsRun,
		COUNT(CASE WHEN Process like ''Error%'' THEN 0 END)NumberErrors
		FROM dbo.HistoryLog  
			WHERE TimeStamp BETWEEN @fromDate AND @toDate
			AND StudyID=@studyId 
			GROUP BY StudyID,DATEPART(month, TimeStamp),DATEPART(YEAR, TimeStamp)
			ORDER BY 1 DESC
	END
ELSE IF(@studyId=0 AND (@initiatedBy='''' OR @initiatedBy=''All'') AND @groupByStudy=1 AND @groupByInitiated=0)
	BEGIN
	Print ''3''
		SELECT  StudyID,DATEPART(month, TimeStamp)TimeStampMonth,DATEPART(YEAR, TimeStamp)TimeStampYear,''All'' AS InitiatedBy,
		COUNT(CASE WHEN Process=''SASAutomationStart'' THEN 0 END)NumberConfigsRun,
		COUNT(CASE WHEN Process=''FileCopied'' THEN 0 END)NumberFilesTransferred,
		COUNT(CASE WHEN Process=''FileUnzipSuccess'' THEN 0 END)NumberFilesUnzipped,
		COUNT(CASE WHEN Process=''SASProgramLaunched'' THEN 0 END)NumberSasProgramsRun,
		COUNT(CASE WHEN Process like ''Error%'' THEN 0 END)NumberErrors
		FROM dbo.HistoryLog  
			WHERE TimeStamp BETWEEN @fromDate AND @toDate			
			GROUP BY StudyID,DATEPART(month, TimeStamp),DATEPART(YEAR, TimeStamp)
			ORDER BY 1 DESC
	END
ELSE IF(@studyId=0 AND (@initiatedBy!='''' AND @initiatedBy!=''All'') AND @groupByStudy=0 AND @groupByInitiated=1)
	BEGIN
	Print ''4''
		SELECT  CAST(999999999 as bigint)StudyID,DATEPART(month, TimeStamp)TimeStampMonth,DATEPART(YEAR, TimeStamp)TimeStampYear,InitiatedBy,
		COUNT(CASE WHEN Process=''SASAutomationStart'' THEN 0 END)NumberConfigsRun,
		COUNT(CASE WHEN Process=''FileCopied'' THEN 0 END)NumberFilesTransferred,
		COUNT(CASE WHEN Process=''FileUnzipSuccess'' THEN 0 END)NumberFilesUnzipped,
		COUNT(CASE WHEN Process=''SASProgramLaunched'' THEN 0 END)NumberSasProgramsRun,
		COUNT(CASE WHEN Process like ''Error%'' THEN 0 END)NumberErrors
		FROM dbo.HistoryLog  
			WHERE TimeStamp BETWEEN @fromDate AND @toDate
			AND  InitiatedBy=@initiatedBy 
			GROUP BY DATEPART(month, TimeStamp),DATEPART(YEAR, TimeStamp),InitiatedBy
			ORDER BY 1 DESC
	END
ELSE IF(@studyId=0 AND (@initiatedBy='''' OR @initiatedBy=''All'') AND @groupByStudy=0 AND @groupByInitiated=1)
	BEGIN
	 Print ''5''
		SELECT CAST(999999999 as bigint)StudyID,DATEPART(month, TimeStamp)TimeStampMonth,DATEPART(YEAR, TimeStamp)TimeStampYear,InitiatedBy,
		COUNT(CASE WHEN Process=''SASAutomationStart'' THEN 0 END)NumberConfigsRun,
		COUNT(CASE WHEN Process=''FileCopied'' THEN 0 END)NumberFilesTransferred,
		COUNT(CASE WHEN Process=''FileUnzipSuccess'' THEN 0 END)NumberFilesUnzipped,
		COUNT(CASE WHEN Process=''SASProgramLaunched'' THEN 0 END)NumberSasProgramsRun,
		COUNT(CASE WHEN Process like ''Error%'' THEN 0 END)NumberErrors
		FROM dbo.HistoryLog  
			WHERE TimeStamp BETWEEN @fromDate AND @toDate			
			GROUP BY DATEPART(month, TimeStamp),DATEPART(YEAR, TimeStamp),InitiatedBy
			ORDER BY 1 DESC
	END
ELSE IF(@studyId=0 AND (@initiatedBy='''' OR @initiatedBy=''All'') AND @groupByStudy=0 AND @groupByInitiated=0)
	BEGIN
	Print ''6''
		SELECT  CAST(999999999 as bigint)StudyID,DATEPART(month, TimeStamp)TimeStampMonth,DATEPART(YEAR, TimeStamp)TimeStampYear,''All'' AS InitiatedBy,
		COUNT(CASE WHEN Process=''SASAutomationStart'' THEN 0 END)NumberConfigsRun,
		COUNT(CASE WHEN Process=''FileCopied'' THEN 0 END)NumberFilesTransferred,
		COUNT(CASE WHEN Process=''FileUnzipSuccess'' THEN 0 END)NumberFilesUnzipped,
		COUNT(CASE WHEN Process=''SASProgramLaunched'' THEN 0 END)NumberSasProgramsRun,
		COUNT(CASE WHEN Process like ''Error%'' THEN 0 END)NumberErrors
		FROM dbo.HistoryLog  
			WHERE TimeStamp BETWEEN @fromDate AND @toDate
			GROUP BY DATEPART(month, TimeStamp),DATEPART(YEAR, TimeStamp)
			ORDER BY 1 DESC
	END
ELSE IF(@studyId=0 AND (@initiatedBy='''' OR @initiatedBy=''All'') AND @groupByStudy=1 AND @groupByInitiated=1)
	BEGIN
	Print ''7''
		SELECT StudyID,DATEPART(month, TimeStamp)TimeStampMonth,DATEPART(YEAR, TimeStamp)TimeStampYear,InitiatedBy,
		COUNT(CASE WHEN Process=''SASAutomationStart'' THEN 0 END)NumberConfigsRun,
		COUNT(CASE WHEN Process=''FileCopied'' THEN 0 END)NumberFilesTransferred,
		COUNT(CASE WHEN Process=''FileUnzipSuccess'' THEN 0 END)NumberFilesUnzipped,
		COUNT(CASE WHEN Process=''SASProgramLaunched'' THEN 0 END)NumberSasProgramsRun,
		COUNT(CASE WHEN Process like ''Error%'' THEN 0 END)NumberErrors
		FROM dbo.HistoryLog  
			WHERE TimeStamp BETWEEN @fromDate AND @toDate			
			GROUP BY StudyID,DATEPART(month, TimeStamp),DATEPART(YEAR, TimeStamp),InitiatedBy
			ORDER BY 1 DESC
	END
ELSE IF(@studyId=0 AND (@initiatedBy!='''' AND @initiatedBy!=''All'') AND @groupByStudy=1 AND @groupByInitiated=1)
	BEGIN
	Print ''8''
		SELECT  StudyID,DATEPART(month, TimeStamp)TimeStampMonth,DATEPART(YEAR, TimeStamp)TimeStampYear,InitiatedBy,
		COUNT(CASE WHEN Process=''SASAutomationStart'' THEN 0 END)NumberConfigsRun,
		COUNT(CASE WHEN Process=''FileCopied'' THEN 0 END)NumberFilesTransferred,
		COUNT(CASE WHEN Process=''FileUnzipSuccess'' THEN 0 END)NumberFilesUnzipped,
		COUNT(CASE WHEN Process=''SASProgramLaunched'' THEN 0 END)NumberSasProgramsRun,
		COUNT(CASE WHEN Process like ''Error%'' THEN 0 END)NumberErrors
		FROM dbo.HistoryLog  
			WHERE TimeStamp BETWEEN @fromDate AND @toDate
			AND InitiatedBy=@initiatedBy 
			GROUP BY StudyID,DATEPART(month, TimeStamp),DATEPART(YEAR, TimeStamp),InitiatedBy
			ORDER BY 1 DESC
	END
END
	')



END

END TRY
BEGIN CATCH
  throw  select ERROR_NUMBER() , ERROR_LINE() , ERROR_MESSAGE();
END CATCH;
