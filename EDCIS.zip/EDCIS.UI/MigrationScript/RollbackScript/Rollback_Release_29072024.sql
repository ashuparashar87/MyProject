﻿
BEGIN TRY

IF EXISTS (SELECT 1  FROM [dbo].[EDCISConfiguration]
                WHERE [Key] = 'IsInMaintenanceMode')

BEGIN 
delete from  [dbo].[EDCISConfiguration]  WHERE [Key] = 'IsInMaintenanceMode'
END

END TRY
BEGIN CATCH
  throw  select ERROR_NUMBER() , ERROR_LINE() , ERROR_MESSAGE();
END CATCH;


