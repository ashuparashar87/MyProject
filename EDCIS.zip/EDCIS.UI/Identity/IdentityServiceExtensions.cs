﻿using EDCIS.Application.ClientInfrastructure.Dtos;
using EDCIS.Domain.Enum;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using System.Security.Claims;
using Microsoft.Graph;
using Microsoft.Identity.Web;
using EDCIS.Domain;
using System.Net.Http.Headers;


namespace EDCIS.UI.Pages.Identity
{
    public static class IdentityServiceExtensions
    {
        public static void AddIdentityServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<UserServiceHandler>();
            services.AddScoped<GraphServiceClient>();
            services.AddScoped<UserGroupService>();

            string[] permissions = configuration.GetValue<string>("DownstreamApi:Scopes")!.Split(',');
            services.AddAuthentication(OpenIdConnectDefaults.AuthenticationScheme)
            .AddMicrosoftIdentityWebApp(options =>
            {
                configuration.Bind("AzureAd", options);
                // Hook into the OnSignIn event
                options.Events.OnTokenValidated = async context =>
                {

                    var groups = await GetUserGroups(context, permissions);
                    var claimsIdentity = context?.Principal?.Identity as ClaimsIdentity;
                    //var emailAddress = context?.Principal?.FindFirst("emailaddress")?.Value;
                    var emailAddress = claimsIdentity?.FindFirst(ClaimTypes.Email)?.Value;
                    SD.UserId = emailAddress;

                    if (groups != null)
                    {
                        List<Claim> claims = new List<Claim>();
                        var userService = context?.HttpContext.RequestServices.GetRequiredService(typeof(UserServiceHandler)) as UserServiceHandler;
                        var userClaims = await userService!.AddUser(claimsIdentity?.Claims.ToList(), groups);
                        if (userClaims != null)
                        {
                            claims.Add(new Claim(ClaimTypes.Role, userClaims.FirstOrDefault(m => m.Type == ClaimTypes.Role)?.Value!));
                            claims.Add(new Claim("DisplayRoleName", userClaims.FirstOrDefault(m => m.Type == ClaimTypes.Role)?.Value!));
                            claimsIdentity?.AddClaims(claims);
                            context?.HttpContext.User.AddIdentity(claimsIdentity!);
                            context?.HttpContext.Items.Add("UserId", emailAddress);
                        }
                    }
                    await Task.CompletedTask;
                };
                options.Events.OnRemoteFailure = async context =>
                {
                    if (context.Failure != null &&
                     context.Failure.Message != null &&
                        context.Failure.Message.Contains("User is not assigned to the client application"))
                    {
                        context.Response.Redirect("/Account/AccessDenied");
                    }
                    context.HandleResponse();
                    await Task.CompletedTask;
                };
            })
                .EnableTokenAcquisitionToCallDownstreamApi(configuration.GetValue<string>("DownstreamApi:Scopes")?.Split(','))
                .AddMicrosoftGraph(configuration.GetSection("DownstreamApi"))
            .AddInMemoryTokenCaches();

            services.AddAuthorization(options =>
            {
                options.AddPolicy(Permissions.CanModifiedData.ToString(), policy =>
                                             policy.RequireRole(ResourceRole.Admin.ToString()));

                options.AddPolicy(Permissions.CanAdminMenu.ToString(), policy =>
                               policy.RequireRole(ResourceRole.Admin.ToString(), ResourceRole.ITAdmin.ToString()));

                options.AddPolicy(Permissions.CanProgramAutomation.ToString(), policy =>
                               policy.RequireRole(ResourceRole.Statistician.ToString(), ResourceRole.DataManager.ToString()));

            });
        }

        private static async Task<List<AdGroupConfig>> GetUserGroups(TokenValidatedContext context, string[] scopes)
        {
            var userPrincipal = context.Principal;
            var tokenAcquisition = context.HttpContext.RequestServices.GetRequiredService<ITokenAcquisition>();
            var accessToken = await tokenAcquisition.GetAccessTokenForUserAsync(scopes, "", "null", userPrincipal);

            // Create a new GraphServiceClient using the access token
            var graphServiceClient = new GraphServiceClient(new DelegateAuthenticationProvider(requestMessage =>
            {
                requestMessage.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                return Task.CompletedTask;
            }));

            var groups = await GetUserGroupsAsync(graphServiceClient);
            List<AdGroupConfig> adGroups = new List<AdGroupConfig>();

            foreach (var userGroup in groups)
            {
                var group = new AdGroupConfig();
                group.GroupName = userGroup.DisplayName;
                adGroups.Add(group);
            }
            return adGroups;
        }

        private static async Task<List<Group>> GetUserGroupsAsync(GraphServiceClient graphServiceClient)
        {
            var groupList = new List<Group>();
            var memberOf = await graphServiceClient.Me.MemberOf.Request().GetAsync();

            while (memberOf != null)
            {
                if (memberOf.CurrentPage != null)
                {
                    foreach (var directoryObject in memberOf.CurrentPage)
                    {
                        if (directoryObject is Group group)
                        {
                            groupList.Add(group);
                        }
                    }
                }

                // If there is a next page, fetch it
                memberOf = memberOf.NextPageRequest?.GetAsync().Result;
            }
            return groupList;
        }
    }
    //public static class IdentityServiceExtensions
    //{
    //    public static void AddIdentityServices(this IServiceCollection services, IConfiguration configuration)
    //    {
    //        services.AddScoped<UserServiceHandler>();
    //        services.AddScoped<OktaServiceHandler>();

    //        services.AddAuthentication(options =>
    //        {
    //            options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    //            options.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;

    //        })
    //            .AddCookie(options =>
    //            {
    //                options.LoginPath = configuration["Okta:LoginPath"];
    //                options.AccessDeniedPath = configuration["Okta:AccessDeniedPath"];
    //                options.Events = new CookieAuthenticationEvents()
    //                {
    //                    OnSigningIn = async context =>
    //                    {
    //                        var claimsIdentity = context?.Principal?.Identity as ClaimsIdentity;
    //                        var userService = context?.HttpContext.RequestServices.GetRequiredService(typeof(UserServiceHandler)) as UserServiceHandler;
    //                        var eamilAddress = claimsIdentity?.Claims.FirstOrDefault(m => m.Type == ClaimTypes.Email)?.Value;
    //                        var userId = claimsIdentity?.Claims.FirstOrDefault(m => m.Type == ClaimTypes.NameIdentifier)?.Value;

    //                        var oktaService = context?.HttpContext.RequestServices.GetRequiredService(typeof(OktaServiceHandler)) as OktaServiceHandler;

    //                        if (userService != null && eamilAddress != null)
    //                        {
    //                            List<Claim> claims = new List<Claim>();
    //                            if (oktaService != null && claimsIdentity!=null)
    //                            {
    //                                var oktaUserGroups = await oktaService.GetGroupsAsync(userId);
    //                                if (oktaUserGroups != null)
    //                                {
    //                                    SD.UserId = eamilAddress;
    //                                    var userClaims = await userService.AddUser(claimsIdentity.Claims.ToList(), oktaUserGroups!);
    //                                    if (userClaims != null)
    //                                    {
    //                                        claims.Add(new Claim(ClaimTypes.Role, userClaims.FirstOrDefault(m => m.Type == ClaimTypes.Role)?.Value!));
    //                                        claims.Add(new Claim("DisplayRoleName", userClaims.FirstOrDefault(m => m.Type == ClaimTypes.Role)?.Value!));
    //                                        claimsIdentity?.AddClaims(claims);
    //                                        context?.HttpContext.User.AddIdentity(claimsIdentity!);
    //                                        context?.HttpContext.Items.Add("UserId", eamilAddress);
    //                                    }

    //                                }
    //                            }
    //                        }
    //                        await Task.CompletedTask;
    //                    }
    //                };
    //            })
    //            .AddOpenIdConnect(options =>
    //            {
    //                options.Authority = configuration["Okta:Authority"];
    //                options.ClientId = configuration["Okta:ClientId"];
    //                options.ClientSecret = configuration["Okta:ClientSecret"];
    //                options.CallbackPath = "/okta-auth";
    //                options.SignedOutCallbackPath = "/okta-signout";
    //                options.ResponseType = OpenIdConnectResponseType.Code;
    //                options.SaveTokens = true;
    //                options.Scope.Add("openid");
    //                options.Scope.Add("email");
    //                options.Events = new OpenIdConnectEvents
    //                {
    //                    OnRemoteFailure = context =>
    //                    {
    //                        if (context.Failure != null &&
    //                         context.Failure.Message != null &&
    //                            context.Failure.Message.Contains("User is not assigned to the client application"))
    //                        {
    //                            context.Response.Redirect("/Account/AccessDenied");
    //                        }
    //                        context.HandleResponse();
    //                        return Task.CompletedTask;
    //                    }
    //                };
    //            });


    //            services.AddAuthorization(options =>
    //            {

    //                //options.AddPolicy(Permissions.CanViewData.ToString(), policy =>
    //                //                  policy.RequireRole(ResourceRole.Admin.ToString(), ResourceRole.ITAdmin.ToString(),
    //                //                  ResourceRole.ReadOnly.ToString(),));

    //                options.AddPolicy(Permissions.CanModifiedData.ToString(), policy =>
    //                                policy.RequireRole(ResourceRole.Admin.ToString()));

    //                options.AddPolicy(Permissions.CanAdminMenu.ToString(), policy =>
    //                              policy.RequireRole(ResourceRole.Admin.ToString(), ResourceRole.ITAdmin.ToString()));

    //                options.AddPolicy(Permissions.CanProgramAutomation.ToString(), policy =>
    //                              policy.RequireRole(ResourceRole.Statistician.ToString(), ResourceRole.DataManager.ToString()));

    //            });
    //    }
    //}
}
