﻿using EDCIS.Domain.Enum;
using System.ComponentModel.DataAnnotations.Schema;

namespace EDCIS.UI.Model
{
    public class AutomaticReportResponse
    {

        public int Id { get; set; }
        public string? EDCConfigID { get; set; }
        public string? ConfigName { get; set; }
        public DateTime TimeStamp { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public string Process { get; set; }
        public long? StudyID { get; set; }      
        public string? StudyName { get; set; }
        public string? ExceptionMessage { get; set; }
        public string? LogDetails { get; set; }
        public bool? IsError { get; set; }

        public int? Month { get; set; }
        public int? Year { get; set; }
        public string? CTMSProtocolNumber { get; set; }
        public string? InitiatedBy { get; set; }
        public int? NumberConfigsRun { get; set; }
        public int? NumberFilesTransferred { get; set; }
        public int? NumberFilesUnzipped { get; set; }
        public int? NumberSasProgramsRun { get; set; }
        public int? NumberErrors { get; set; }


    }
}
