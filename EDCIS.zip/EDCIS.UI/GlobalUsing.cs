﻿global using DevExtreme.AspNet.Data;
global using DevExtreme.AspNet.Mvc;
global using EDCIS.Application.Handler;
global using MediatR;
global using Microsoft.AspNetCore.Mvc;
global using Microsoft.AspNetCore.Mvc.RazorPages;
global using AutoMapper;
global using EDCIS.Domain.Entities;