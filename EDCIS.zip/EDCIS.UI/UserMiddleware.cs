﻿using Azure.Messaging;
using EDCIS.Application.ClientInfrastructure.Dtos;
using EDCIS.Application.Handler;
using EDCIS.Application.Utility.Constant;
using EDCIS.Domain.Enum;
using System.Security.Claims;

namespace EDCIS.UI
{
    public class UserMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<UserMiddleware> _logger;

        #region "Cookie handling"

        public string GetCookie(HttpContext httpContext, string cookieKey, string defaultValue = "")
        {
            return (httpContext.Request.Cookies[cookieKey] ?? defaultValue);
        }

        /// <summary>
        /// Sets the cookie cookieKey with cookieValue
        /// </summary>
        /// <param name="cookieKey"></param>
        /// <param name="cookieValue"></param>
        /// <param name="clearFirst">Clear (delete) the cookie before setting it.</param>
        /// <param name="expires">Default is one year from now.</param>
        public void SetCookie(HttpContext httpContext, string cookieKey, string cookieValue,
            bool clearFirst = true, DateTime? expires = null)
        {
            if (clearFirst) ClearCookie(httpContext, cookieKey);
            CookieOptions options = new CookieOptions
            {
              Secure = true,
              HttpOnly = true,
              Expires = (expires != null) ? expires : DateTime.UtcNow.AddYears(1)
            };
            httpContext.Response.Cookies.Append(cookieKey, cookieValue, options);
        }


        public void ClearCookie(HttpContext httpContext, string cookieKey)
        {
            httpContext.Response.Cookies.Delete(cookieKey);
        }


        public void ClearAllCookies(HttpContext httpContext)
        {
            foreach (var cookie in httpContext.Request.Cookies)
            {
                httpContext.Response.Cookies.Delete(cookie.Key);
            }
        }


        #endregion

        public UserMiddleware(RequestDelegate next, ILogger<UserMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public string? ImpersonatingUserId;
        public string? emailAddress;
        public async Task Invoke(HttpContext httpContext, IMediator mediator)
        {
            if (Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") != "Development" && SD.AuthenticationFeatureToggle == false)
            {
                throw new UnauthorizedAccessException();
            }

            var configlist = await mediator.Send(new GetEDCISConfigurationListQuery());
            var configvalue = configlist.Where(x => x.Key == "IsInMaintenanceMode").SingleOrDefault();
            // Check if maintenance mode is enabled
            if (configvalue?.Value == "1" && httpContext.Request.Path != "/Maintenance/Maintenance/" && !httpContext.Request.Path.Value!.Contains("/Configuration") && !httpContext.Request.Path.Value.Contains("/Admin/index"))
            {
                httpContext.Response.Redirect("/Maintenance/Maintenance/");
                return;
            }
            var claimsIdentity = httpContext.User.Identity as ClaimsIdentity;
            if (claimsIdentity == null) return;
            var userId = claimsIdentity.Claims.FirstOrDefault(m => m.Type == ClaimTypes.Email)?.Value;

            //$REMOVE$ BEFORE PRODUCTION RELEASE (although not critical): NOT NEEDED: JUST TEMP FOR NON-AUTH'ED SITUATION:
            if (string.IsNullOrEmpty(userId)) userId = MessagesConstants.SystemUserEmail;

            if (Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") != "Production")
            {
                if (SD.AuthenticationFeatureToggle == false)
                {
                    await AddUser(userId, mediator);
                }

                string impersonatingUserid = "";
                ImpersonatingUserId = GetCookie(httpContext, CookieName.ImpersonatingUserId.ToString(), "");
                SetCookie(httpContext, CookieName.ImpersonatingUserId.ToString(), ImpersonatingUserId);
                //Here is the impersonation "pecking order":
                //First try the 'persistent' impersonator (the ImpersonatingUserId cookie):
                if (!string.IsNullOrEmpty(ImpersonatingUserId))
                    impersonatingUserid = ImpersonatingUserId;
                //If that's not there, try the 'one-time' impoersonator (the "iuid" querystring aergument):
                if (string.IsNullOrEmpty(impersonatingUserid)) impersonatingUserid = httpContext.Request.Query["iuid"].ToString();
                //If either was provided, impersonate:
                if (!string.IsNullOrEmpty(impersonatingUserid))
                {
                    //Correct these shorthands (a hack, but no big deal):
                    //&iuid=username only (no "@domain.com")  => username@advancedgroup.com
                    //&iuid=username@ag                       => username@advancedgroup.com
                    //&iuid=username@ac                       => username@advancedclinical.com
                    if (!impersonatingUserid.Contains("@")) impersonatingUserid += "@advancedgroup.com";
                    if (impersonatingUserid.EndsWith("@ag")) impersonatingUserid = impersonatingUserid.Replace("@ag", "@advancedgroup.com");
                    if (impersonatingUserid.EndsWith("@ac")) impersonatingUserid = impersonatingUserid.Replace("@ac", "@advancedclinical.com");
                    emailAddress = impersonatingUserid;
                    //Show the impersonation on the layout URHC (abbreviate email addresses for more concise display):
                    string displayIuid = impersonatingUserid.Replace("@advancedgroup.com", "@ag").Replace("@advancedclinical.com", "@ac");
                    string ImpersonationMarkerHtml = "<span style=\"color:#ed1c24;\" >AS <b>" + displayIuid + "</b></span>";
                    httpContext.Items.Add("ImpersonationMarkerHtml", ImpersonationMarkerHtml);

                    //Set the user to the impersonating userId:
                    userId = emailAddress;

                }
            }

            var toEmails = await mediator.Send(new GetEDCSettingQuery());
            var emails=toEmails.FirstOrDefault()?.SupportEmail;
            SD.Error_ToEmail = emails!=null? emails: SD.CriticalErrorEmail_ToEmail;
            var resourceList = await  mediator.Send(new GetResourceListCommandQuery());
            var appUsers = resourceList.Where(x => x.EmailAddress == userId && x.IsActive == true);
            var appUser = appUsers.FirstOrDefault();
            if (appUser != null && httpContext.User.Identities.Count() == 1)
            {
                List<Claim> claims = new List<Claim>();
                if (httpContext.User.Claims.Count() > 0)
                {
                    var emailClaim = (from c in httpContext.User.Claims
                                      where c.Type == ClaimTypes.Email
                                      select c).Single();
                    claimsIdentity.RemoveClaim(emailClaim);

                    var roleClaim = (from c in httpContext.User.Claims
                                     where c.Type == ClaimTypes.Role
                                     select c).Single();
                    claimsIdentity.RemoveClaim(roleClaim);

                    if (appUser.EmailAddress == null) return;
                    claims.Add(new Claim(ClaimTypes.Email, appUser!.EmailAddress));
                    claims.Add(new Claim(ClaimTypes.Role, appUser.Role.ToString()));
                    claims.Add(new Claim("FullName", appUser.Fullname));
                    claimsIdentity.AddClaims(claims);

                }
                else
                {
                    if (appUser.EmailAddress == null) return;
                    claims.Add(new Claim(ClaimTypes.Email, appUser!.EmailAddress));
                    claims.Add(new Claim(ClaimTypes.Role, appUser.Role.ToString()));
                    claims.Add(new Claim("FullName", appUser.Fullname));
                    claimsIdentity.AddClaims(claims);
                }
                SD.UserId = appUser.EmailAddress;
            }
            httpContext.User.AddIdentity(claimsIdentity);
            await _next(httpContext);
        }


        private async Task AddUser(string userId, IMediator mediator)
        {
            var resourceList = await mediator.Send(new GetResourceListCommandQuery());
            var appUsers = resourceList.Where(x => x.EmailAddress == userId && x.IsActive == true);
            var appUser = appUsers.SingleOrDefault();

            if (appUser == null)
            {
                var resource = new Resource();
                resource.EmailAddress = userId;
                resource.Role = ResourceRole.ITAdmin;
                resource.IsActive = true;
                resource.LastLoginAt = DateTime.UtcNow;
                resource.CreatedDate = DateTime.UtcNow;
                resource.CreatedBy = MessagesConstants.SystemUserEmail;
                resource.FirstName = MessagesConstants.SystemUserFName;
                await mediator.Send(new CreateResourceCommand(resource));               
            }
        }
    }
}
