#!/bin/bash

base="$PWD"
dotnet ef database update --project EDCIS.Infrastructure --startup-project EDCIS.UI
cd $base