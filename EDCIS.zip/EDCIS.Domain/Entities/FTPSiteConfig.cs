﻿using EDCIS.Domain.Enum;
using System.ComponentModel.DataAnnotations;

namespace EDCIS.Domain.Entities
{
    public class FTPSiteConfig : EntityBase
    {
        public int Id { get; set; }

        [Display(Name = "FTP Site")]
        public string FTPSite { get; set; } = null!;


        [Display(Name = "File Protocol")]
        public FileProtocol FileProtocol { get; set; }

        [Display(Name = "Encryption")]
        public EncryptionMode Encryption { get; set; }

        [Display(Name = "Host Name")]
        public string HostName { get; set; } = null!;

        [Display(Name = "Port Number")]
        public int PortNumber { get; set; }

        [Display(Name = "User Name")]
        public string UserName { get; set; } = null!;

        [Display(Name = "Password")]
        public string Password { get; set; } = null!;
    }
}
