﻿using System.ComponentModel.DataAnnotations;

namespace EDCIS.Domain.Entities
{
    public class EDCToSASConfig
    {
        public int Id { get; set; }

        [Display(Name = "Days to Purge Destination Archive Folder")]
        public int? DestArchivePurgePeriod { get; set; }

        [Display(Name = "Days to Purge History Logs")]
        public int? HistoryPurgePeriod { get; set; } 
        [Display(Name = "IT Support Emails (To send email when error occurs )")]
        public string? SupportEmail { get; set; }
        public bool IsAutomationActive { get; set; }
    }
}

