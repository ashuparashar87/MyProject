﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using EDCIS.Domain.Enum;

namespace EDCIS.Domain.Entities
{
    public class Resource 
    {
        public long Id { get; set; }

        [Display(Name = "First Name")]
        public string? FirstName { get; set; }

        [Display(Name = "Last Name")]
        public string? LastName { get; set; }

        [NotMapped]
        public string Fullname { get { return this.FirstName + " " + this.LastName; } }

        [Display(Name = "Email Address")]
        public string? EmailAddress { get; set; }

        [Display(Name = "Is Active")]
        public bool IsActive { get; set; }

        public ResourceRole Role { get; set; }

        [Display(Name = "Days Since Login")]
        public DateTime? LastLoginAt { get; set; }


        [Display(Name = "Days Since Login")]
        [NotMapped]
        public string? DaysSinceLogin { get; set; }

        public string? CreatedBy { get; set; } = string.Empty;
        public DateTime CreatedDate { get; set; }
        public string? LastModifiedBy { get; set; }
        public DateTime? LastModifiedDate { get; set; }
    }
   
}
