﻿using EDCIS.Domain.Enum;
using System.ComponentModel.DataAnnotations.Schema;

namespace EDCIS.Domain.Entities
{
    public class HistoryLog
    {
        public int Id { get; set; }
        public int? EDCConfigID { get; set; }
        public string? ConfigName { get; set; } 
        public DateTime TimeStamp { get; set; }
        public ProcessType Process { get; set; }
        public long? StudyID { get; set; }
        public string? InitiatedBy { get; set; }
        [NotMapped]
        public string? StudyName{ get; set; }

        public string? ExceptionMessage { get; set; }
        public string? LogDetails { get; set; }

        [NotMapped]
        public bool? IsError { get; set; }       
    }
}