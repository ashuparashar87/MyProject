﻿namespace EDCIS.Domain.Entities
{
    public abstract class EntityBase
    {
        public string? CreatedBy { get; set; } = string.Empty;
        public DateTime CreatedDate { get; set; }
        public string? LastModifiedBy { get; set; }
        public DateTime? LastModifiedDate { get; set; }
    }

    public class AutomationReportResult
    {
        //public DateTime TimeStamp { get; set; }
        //public DateTime fromDate { get; set; }
        //public DateTime toDate { get; set; }
        //public string? Process { get; set; }
        public long? StudyID { get; set; }
        //public string? StudyName { get; set; }
        public int? TimeStampMonth { get; set; }
        public int? TimeStampYear { get; set; }
        //public string? CTMSProtocolNumber { get; set; }
        public string? InitiatedBy { get; set; }
        public int? NumberConfigsRun { get; set; }
        public int? NumberFilesTransferred { get; set; }
        public int? NumberFilesUnzipped { get; set; }
        public int? NumberSasProgramsRun { get; set; }
        public int? NumberErrors { get; set; }
    }
}
