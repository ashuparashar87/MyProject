﻿namespace EDCIS.Domain.Entities
{
    public class EDCISStudyView
    {
        public long StudyID { get; set; }
        public string? Medidatastudyid { get; set; }
        public string StudyName { get; set; } = null!;
        public string StudyStatus { get; set; } = null!;
        public string TherapeuticArea { get; set; } = null!;
        public string Indication { get; set; } = null!;
        public string SponsorName { get; set; } = null!;
        public string ProtocolNumber { get; set; } = null!;
        public string? Url { get; set; } 
        public string? Username { get; set; }
    }
}
