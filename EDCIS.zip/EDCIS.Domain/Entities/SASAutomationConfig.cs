﻿using EDCIS.Domain.Enum;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EDCIS.Domain.Entities
{
    public class SASAutomationConfig : EntityBase
    {
        public int Id { get; set; }
        public long StudyID { get; set; }

        [Display(Name = "FTP Site")]
        public string? SourceFTPSite { get; set; } = null;

        [Display(Name = "Last File Transferred")]
        public string? FileName { get; set; }

        [Display(Name = "Config Name")]
        public string ConfigName { get; set; } = null!;

        [Display(Name = "File Protocol")]
        public FileProtocol? SourceFileProtocol { get; set; }

        [Display(Name = "Encryption")]
        public EncryptionMode? SourceEncryption { get; set; }

        [Display(Name = "Host Name")]
        public string? SourceHostName { get; set; } 

        [Display(Name = "Port Number")]
        public int? SourcePortNumber { get; set; }

        [Display(Name = "User Name")]
        public string? SourceUserName { get; set; } 

        [Display(Name = "Password")]
        public string? SourcePassword { get; set; }

        [Display(Name = "File Name")]
        public string? SourceFileName { get; set; } = null!;

        [Display(Name = "Zip Password")]
        public string? SourceZipPassword { get; set; }

        [Display(Name = "Folder Path")]
        public string? SourceFolderPath { get; set; } = null!;

        [Display(Name = "Delete Source File After Transfer")]
        public bool IsDeleteFileAfterTransfer { get; set; } = false;

        [Display(Name = "FTP Site")]
        public string? DestFTPSite { get; set; } = null!;

        [Display(Name = "File Protocol")]
        public FileProtocol? DestFileProtocol { get; set; }

        [Display(Name = "Encryption")]
        public EncryptionMode? DestEncryption { get; set; }

        [Display(Name = "Host Name")]
        public string? DestHostName { get; set; }

        [Display(Name = "Port Number")]
        public int? DestPortNumber { get; set; }

        [Display(Name = "User Name")]
        public string? DestUserName { get; set; } 
        [Display(Name = "Password")]
        public string? DestPassword { get; set; } 
        [Display(Name = "Archive Destination Folder")]
        public string? ArchiveDestFolderPath { get; set; } = null!;
        [Display(Name = "Current Destination Folder")]
        public string? CurrentDestFolderPath { get; set; } = null!;

        [Display(Name = "Last Run")]
        public DateTime? TransferDate { get; set; }
        [Display(Name = "Daily")]
        public bool IsDaily { get; set; }
        [Display(Name = "Configuration Type")]
        public ConfigurationTypeValue? ConfigurationType { get; set; }
        [NotMapped]
        public bool IsWeekly { get; set; }

        [NotMapped]
        public SelectList? TimeIntervalList { get; set; }

        [Display(Name = "Is Active")]
        public bool IsEDCActive { get; set; }
        public string? WeekDays { get; set; }

        [Display(Name = "Time Slot (local time)")]
        public string? TimeSlot { get; set; } 

        [NotMapped]
        [Display(Name = "Last Run")]
        public string? TransferDateString { get; set; }

        [Display(Name = "Error Email Recipients")]
    
        public string? ErrorEmailRecipients { get; set; }

        [Display(Name = "Success Email Recipients")]
        public string? SuccessEmailRecipients { get; set; }
        public bool IsErrorInLastExecution { get; set; } = false;

        [Display(Name = "Statistician Can Run")]

        public bool CanRunStatistician { get; set; } = false;
        [Display(Name = "DM Can Run")]
        public bool CanDMRUN { get; set; } = false;
        [Display(Name = "Last SAS Launch DateTime")]
        public DateTime? LastSASLaunchDateTime { get; set; }
        [Display(Name = "Last Error Date Time")]
        public DateTime? LastErrorDateTime { get; set; }
        [Display(Name = "Last Error")]
        public string? LastError { get; set; }
        [Display(Name = "Execute Program After Transfer")]
        public bool ExecuteProgramAfterTransfer { get; set; }=false;
        [Display(Name = "Description")]
        public string? Description { get; set; }
        [Display(Name = "SAS Executable File")]
        [NotMapped]
        public string? File { get; set; }
        [Display(Name = "Full Path of SAS Program")]
        public string? Path { get; set; }
        [Display(Name = "Arguments")]
        [NotMapped]
        public string? Arguments { get; set; }
        [Display(Name = "Timeout In Seconds")]
        public int TimeoutInSeconds { get; set; } = 60;
        [Display(Name = "Last SAS Log File")]
        public string? LastSASLogFile { get; set; }

        [Display(Name = "HasError")]
        [NotMapped]
        public bool HasError => !string.IsNullOrEmpty(LastError) ? true : false;

        [NotMapped]
        [Display(Name = "EDC SAS Agent URL")]
        public string? EDCSASAgentURL { get; set; }
    }
}
