﻿using System.ComponentModel;

namespace EDCIS.Domain.Enum
{
    public enum EncryptionMode
    {
        None,
        Implicit,
        Explicit,
    }

    public enum ConfigurationTypeValue
    {
        
        FileTransfer,
        SASProgram,
    }
    public enum FileProtocol
    {
        None,
        FTP,
        SFTP
    }
    public enum ResourceRole
    {
        [Description("DMAdmin")] Admin,
        [Description("ITAdmin")] ITAdmin,
        [Description("Statistician")] Statistician,
        [Description("DataManager")] DataManager,
        [Description("ReadOnly")] ReadOnly
    }

    public enum Permissions
    {
        [Description("Can View all the screen")]
        CanViewData,
        [Description("Can Modified Data")]
        CanModifiedData,
        CanAdminMenu,
        CanProgramAutomation

    }

    public enum CookieName
    {
        //Corp-level:
        ImpersonatingUserId,    //If set, the ID of the user being impersonated
        LastUrl,                //The last url visited
        ReturnUrl,              //The url to return to upon completion of a specific operation
    }
    public enum ProcessType
    {
        CurrentFolderCleaning,
        ErrorCleaningCurrentFolder,
        DestinationConnection,
        ErrorConnectingToDestination,
        FileTransfer,
        FileUnzipStarted,
        FileUnzipSuccess,
        ErrorUnzippingFile,
        FileCopied,
        ErrorCopyingFile,
        PurgeDestArchive,
        ErrorPurgingDestArchive,
        PurgeDestArchiveSuccess,
        PurgeHistoryLogs,
        PurgeHistoryLogsSuccess,
        ErrorPurgingHistoryLogs,
        SASAutomation,
        ConfigurationStart,
        SASAutomationStart,
        NewMatchinFileFound,
        NewMatchinFileNotFound,
        ErrorConnectingToSource,
        SourceConnection,
        SourceDeletion,
        ErrorDeletingSourceFile,
        SourceDeletionNotConfigured,
        WebJob,
        SASProgram,
        SASProgramLaunching,
        SASProgramLaunched,
        ErrorLaunchingSASProgram
    }
}
