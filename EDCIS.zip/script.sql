﻿IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230502091720_initialMigration')
BEGIN
    CREATE TABLE [EDCISConfiguration] (
        [Id] bigint NOT NULL IDENTITY,
        [Key] nvarchar(max) NOT NULL,
        [Value] nvarchar(max) NOT NULL,
        [Description] nvarchar(max) NULL,
        [CreatedBy] nvarchar(max) NULL,
        [CreatedDate] datetime2 NOT NULL,
        [LastModifiedBy] nvarchar(max) NULL,
        [LastModifiedDate] datetime2 NULL,
        CONSTRAINT [PK_EDCISConfiguration] PRIMARY KEY ([Id])
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230502091720_initialMigration')
BEGIN
    CREATE TABLE [EDCToSASConfig] (
        [Id] int NOT NULL IDENTITY,
        [DestArchivePurgePeriod] int NULL,
        [HistoryPurgePeriod] int NULL,
        [SupportEmail] nvarchar(max) NULL,
        [IsAutomationActive] bit NOT NULL,
        CONSTRAINT [PK_EDCToSASConfig] PRIMARY KEY ([Id])
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230502091720_initialMigration')
BEGIN
    CREATE TABLE [FTPSiteConfig] (
        [Id] int NOT NULL IDENTITY,
        [FTPSite] nvarchar(100) NOT NULL,
        [FileProtocol] nvarchar(10) NOT NULL,
        [Encryption] nvarchar(max) NOT NULL,
        [HostName] nvarchar(100) NOT NULL,
        [PortNumber] int NOT NULL,
        [UserName] nvarchar(100) NOT NULL,
        [Password] nvarchar(100) NOT NULL,
        [CreatedBy] nvarchar(50) NOT NULL,
        [CreatedDate] datetime2 NOT NULL,
        [LastModifiedBy] nvarchar(50) NULL,
        [LastModifiedDate] datetime2 NULL,
        CONSTRAINT [PK_FTPSiteConfig] PRIMARY KEY ([Id])
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230502091720_initialMigration')
BEGIN
    CREATE TABLE [HistoryLog] (
        [Id] int NOT NULL IDENTITY,
        [EDCConfigID] int NULL,
        [ConfigName] nvarchar(500) NULL,
        [TimeStamp] datetime2 NOT NULL,
        [Process] nvarchar(max) NOT NULL,
        [StudyID] bigint NULL,
        [ExceptionMessage] nvarchar(max) NULL,
        [LogDetails] nvarchar(max) NULL,
        CONSTRAINT [PK_HistoryLog] PRIMARY KEY ([Id])
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230502091720_initialMigration')
BEGIN
    CREATE TABLE [Resource] (
        [Id] bigint NOT NULL IDENTITY,
        [FirstName] nvarchar(100) NOT NULL,
        [LastName] nvarchar(100) NULL,
        [EmailAddress] nvarchar(200) NULL,
        [IsActive] bit NOT NULL,
        [Role] nvarchar(max) NOT NULL,
        [LastLoginAt] datetime2 NULL,
        [CreatedBy] nvarchar(max) NULL,
        [CreatedDate] datetime2 NOT NULL,
        [LastModifiedBy] nvarchar(max) NULL,
        [LastModifiedDate] datetime2 NULL,
        CONSTRAINT [PK_Resource] PRIMARY KEY ([Id])
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230502091720_initialMigration')
BEGIN
    CREATE TABLE [SASAutomationConfig] (
        [Id] int NOT NULL IDENTITY,
        [StudyID] bigint NOT NULL,
        [SourceFTPSite] nvarchar(max) NOT NULL,
        [FileName] nvarchar(500) NULL,
        [ConfigName] nvarchar(100) NOT NULL,
        [SourceFileProtocol] nvarchar(10) NOT NULL,
        [SourceEncryption] nvarchar(max) NOT NULL,
        [SourceHostName] nvarchar(100) NOT NULL,
        [SourcePortNumber] int NULL,
        [SourceUserName] nvarchar(100) NOT NULL,
        [SourcePassword] nvarchar(100) NOT NULL,
        [SourceFileName] nvarchar(100) NOT NULL,
        [SourceZipPassword] nvarchar(100) NULL,
        [SourceFolderPath] nvarchar(max) NOT NULL,
        [IsDeleteFileAfterTransfer] bit NOT NULL,
        [DestFTPSite] nvarchar(max) NOT NULL,
        [DestFileProtocol] nvarchar(100) NOT NULL,
        [DestEncryption] nvarchar(10) NULL,
        [DestHostName] nvarchar(100) NOT NULL,
        [DestPortNumber] int NULL,
        [DestUserName] nvarchar(100) NOT NULL,
        [DestPassword] nvarchar(100) NULL,
        [ArchiveDestFolderPath] nvarchar(1000) NOT NULL,
        [CurrentDestFolderPath] nvarchar(1000) NOT NULL,
        [TransferDate] datetime2 NULL,
        [IsDaily] bit NOT NULL,
        [IsEDCActive] bit NOT NULL,
        [WeekDays] nvarchar(max) NULL,
        [TimeSlot] nvarchar(30) NOT NULL,
        [IsErrorInLastExecution] bit NOT NULL DEFAULT CAST(0 AS bit),
        [CreatedBy] nvarchar(50) NOT NULL,
        [CreatedDate] datetime2 NOT NULL,
        [LastModifiedBy] nvarchar(50) NULL,
        [LastModifiedDate] datetime2 NULL,
        CONSTRAINT [PK_SASAutomationConfig] PRIMARY KEY ([Id])
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230502091720_initialMigration')
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'CreatedBy', N'CreatedDate', N'Description', N'Key', N'LastModifiedBy', N'LastModifiedDate', N'Value') AND [object_id] = OBJECT_ID(N'[EDCISConfiguration]'))
        SET IDENTITY_INSERT [EDCISConfiguration] ON;
    EXEC(N'INSERT INTO [EDCISConfiguration] ([Id], [CreatedBy], [CreatedDate], [Description], [Key], [LastModifiedBy], [LastModifiedDate], [Value])
    VALUES (CAST(1 AS bigint), N''SystemUser@advancedgroup.com'', ''2023-05-02T09:17:19.8846916Z'', N''If any issue occurs while the SAS Automation process is ongoing and needs to be retriggered. Value “1” indicates job is still running, replace it with “0” to reset the flag.'', N''IsSASAutomationJobRunning'', NULL, NULL, N''0'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'CreatedBy', N'CreatedDate', N'Description', N'Key', N'LastModifiedBy', N'LastModifiedDate', N'Value') AND [object_id] = OBJECT_ID(N'[EDCISConfiguration]'))
        SET IDENTITY_INSERT [EDCISConfiguration] OFF;
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230502091720_initialMigration')
BEGIN
    CREATE UNIQUE INDEX [UniqueFTPSite] ON [FTPSiteConfig] ([FTPSite]);
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230502091720_initialMigration')
BEGIN
    EXEC(N'CREATE UNIQUE INDEX [IX_ResourceEmail] ON [Resource] ([EmailAddress]) WHERE [EmailAddress] IS NOT NULL');
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230502091720_initialMigration')
BEGIN
    CREATE UNIQUE INDEX [UniqueConfigName] ON [SASAutomationConfig] ([ConfigName]);
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230502091720_initialMigration')
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20230502091720_initialMigration', N'7.0.2');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230502092035_CreateReplicaView')
BEGIN
     IF  DB_ID('CTMSReplica') IS NOT NULL
     BEGIN
     EXECUTE('CREATE OR ALTER VIEW [dbo].[StudyView]
     AS
     SELECT s.Study_Id as StudyID,s.studyname,s.medidatastudyid,s.protocolnumber,s.studystatus,
     s.studyphase,th.therapeuticarea,ind.indication,sp.sponsorname, 
     wsc.Url,wsc.Username 
     FROM [CTMSReplica].[dbo].[Study] s 
     INNER JOIN [CTMSReplica].[dbo].[TherapeuticArea] th ON  
     s.TherapeuticId=th.Therapeutic_Id 
     inner join [CTMSReplica].[dbo].[Indication] ind on 
     s.IndicationId=ind.Indication_Id 
     inner join [CTMSReplica].[dbo].[Sponsor] sp on 
     s.SponsorId=sp.Sponsor_Id
    left join [CTMSReplica].[dbo].[WebserviceCredentials] wsc on 
     sp.sponsorname=wsc.Name')
     END
     ELSE
     BEGIN
     print 'Database not Exist'
     END

END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230502092035_CreateReplicaView')
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20230502092035_CreateReplicaView', N'7.0.2');
END;
GO

COMMIT;
GO

