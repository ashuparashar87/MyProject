﻿using AutoMapper;
using EDCIS.Application.Handler;
using EDCIS.Application.Persistence;
using EDCIS.Application.Profiles;
using EDCIS.Domain.Entities;
using EDCIS.Domain.Enum;
using Moq;
using Shouldly;

namespace EDCIS.Application.UnitTests
{
    public class CreateHistoryLogsCommandTest
    {
        private readonly IMapper _mapper;
        private readonly Mock<IAsyncRepository<HistoryLog>> _mockHistoryRepository;

        public CreateHistoryLogsCommandTest()
        {
            _mockHistoryRepository = RepositoryMocks.GetHistoryRepository();
            var configurationProvider = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<MappingProfile>();
            });

            _mapper = configurationProvider.CreateMapper();
        }

        [Fact]
        public async Task Handle_ValidLog_AddedToHistoriesRepo()
        {
            var handler = new CreateHistoryLogsCommandHandler(_mockHistoryRepository.Object);
            HistoryLog obj = new HistoryLog();
            obj.Process = ProcessType.WebJob;
            obj.TimeStamp = DateTime.UtcNow;
            obj.StudyName = "Study";
            obj.StudyID = 14355223812246160;
            obj.LogDetails = "This is log";
            await handler.Handle(new CreateHistoryLogsCommand(obj), CancellationToken.None);
            var allCategories = await _mockHistoryRepository.Object.GetAllAsync();
            allCategories.Count.ShouldBe(3);
        }
    }

    public class RepositoryMocks
    {
        public static Mock<IAsyncRepository<HistoryLog>> GetHistoryRepository()
        {

            var historyLogs = new List<HistoryLog>
            {
                new HistoryLog
                {
                    Id = 1,
                     StudyName= "Study1"
                },
                new HistoryLog
                {
                    Id = 1,
                     StudyName= "Study2"
                },
            };

            var mockLogRepository = new Mock<IAsyncRepository<HistoryLog>>();
            mockLogRepository.Setup(repo => repo.GetAllAsync()).ReturnsAsync(historyLogs);

            mockLogRepository.Setup(repo => repo.AddAsync(It.IsAny<HistoryLog>())).ReturnsAsync(
                (HistoryLog historyLog) =>
                {
                    historyLogs.Add(historyLog);
                    return historyLog;
                });

            return mockLogRepository;
        }
    }

}
