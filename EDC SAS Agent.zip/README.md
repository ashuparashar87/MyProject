# EDCIS v2 Developer ReadMe

## Helpful Hints

### Developers:  Run your Visual Studio AS AN ADMINISTRATOR


### Installing the SAS Agent as a Service

- The "Misc Files\InstallService.bat" file creates, installs and configures the "AC EDCIS SAS Agent" Windows Service
- The "Misc Files\UninstallService.bat" uninstalls and deletes the service
- You need to run these batch files "As and Administrator"


### Ports

- Default configuration ports:  HTTP=5002;  HTTPS=5003
- When installing or testing on a VM, the API ports must be manually opened:
  - Always on the server's Windows Firewall
  - Also on the Azure VM's Network Security Group, if it is not part of VPN
- In Production, you would to disable the non-secure port, by setting "EnableHttp": "N"


### Swagger UI:
The Swagger UI is installed and available at:
- http://localhost:5002/swagger/index.html
- https://localhost:5003/swagger/index.html

- Be sure to change the port numbers in the URL if appropriate


### API Results

Calling the "Run" API will launch a new Thread that will run the requested command as a Process on the API host server.  
The API Results reflect the results of the Thread Launch, and **not** the results of the Process launch or the 
actual command execution:
```	
{
  "launchSuccess": true,
  "resultCode": 0,
  "message": "Process 'IPConfig' Launched Successfully",
  "exceptionMsg": ""
  "logFile": "C:\\temp\\EDC-SAS_Agent\\IPConfig_2024-07-18-03-59-56.txt"
}
```
- If the API Request Body is not valid, the API will return HttpStatusCode.BadRequest, and the message will name the invalid parameter.
- If the API launched the Thread successfully (launchSuccess=true) the API will return HttpStatusCode.OK
- Else the API will return will return HttpStatusCode.InternalServerError
  - If an exception occurs during Launch but before the log file name has been created, the logFile parameter will return as "Undetermined".

The results of the actual command execution are contained in the Log File named in the API Results object.  Note that long-running commands may not yet 
have finished writing to that log file.  After the command process has finished, the last line of the log file will read like:
```
[16:15:24 INF] ********
[16:15:24 INF] ******** END Command 'IPConfig Error' StdOutput and Logs
[16:15:24 INF] ********
```

### Certificates

- The default certificate found in the source code was created by running the "Misc Files\CreateCert.bat" file:
  - It creates a certificate file named "AutoTesting.pfx", with a Common Name of "AutoTesting DEV Cert"
  - The certificate will contain the "Alt" DNS and IPs for "localhost" and the AutoTesting01 and AutoTesting02 VM server names
    - NOTE The DNS and IP for SAS Test Server (which is also an Azure VM) is included for reference but commented out 
  - It copies the certificate into the "EDCIS.Service.Client" folder, which is then and then Published with the application
  - This configuration was imported into the Azure DEV Key Vault and named "AutoTestingDev"
  - The default configuration is for the Agent to obtain and use the "AutoTestingDev" certificate from the Azure DEV Key Vault
  - If you un-comment the "Kestrel" section in the appsettings.json:
    - The Agent will instead use the certificate file specified in the appsettings.json
    - By default this is the published "AutoTesting.pfx" file
  - NOTE: If we ever need to create a the certificate, the process would be to:
    - Run the "Misc Files\CreateCert.bat" file
    - Import the new certificate into the Azure DEV Key Vault as a new version of the "AutoTestingDev" certificate

- The certificate and the above batch file process creates a self-signed certificate, untrusted by default
  - Any machine (localhost or any VM) calling the Agent API or Swagger UI must import the certificate into the Machine's "Trusted Root Certification Authorities" node

- Any Azure VM that wants to use this (or any) Azure Key Vault certificate:
  - That VM must have a System Assigned Managed Identity
  - With "Key Vault Certificate User" Role assigned to the certificate's Key Vault
  - See [Azure Key Vault Configuration](https://dev.azure.com/advancedgroup/Digital%20Health%20Sandbox/_wiki/wikis/Digital-Health-Sandbox.wiki/102/Azure-Key-Vault-Configuration) for more details

- To use this certificate with an Agent API running on a different test machine:
  - The certificate .conf file should edited to contain the DNS name(s) and IP of the machine or VM where the Agent will be running
  - The new certificate must be imported as a trusted certificate on all machines calling the Agent
  - The new certificate can be used either:
   - Locally, by changing the appsettings.json file to refer to the new .pfx file
   - By importing it into the Azure Key Vault and then changing the appsettings.json file to refer to the new Azure certificate name


## The SAS Agent "Big Picture" (for Herbert, revised)

We need a way to remotely execute SAS programs on the SAS VM, using a local "EDC SAS Agent" in the form of a Windows Service. This Agent service will need to: 
- Host an API that can run program locally, with elevated permissions
- Execute SAS programs, by either running a DOS Batch File or by directly executing a SAS command-line utility. 
- Pass additional process parameters (working folder, command line parameters, etc) as part of the execution
- Capture and log the 'stdout' and 'stderr' streams during the program execution 

The current EDCIS Web Job will be modified to launch a specified program on a remote server, by calling the EDC SAS Agent API on that server.

### Initial "EDC SAS Agent" POC 
As an initial POC, I would like you to create the SAS Agent and have it use a timer to run a series of programs that will be specified in a local JSON file. 
Please complete the following tasks in order of priority:

- Create a new "EDC SAS Windows Service" repository in the [Digital Health Sandbox](https://dev.azure.com/advancedgroup/Digital%20Health%20Sandbox) Azure DevOps project. 
- Create a new "EDC SAS Windows Service" solution and project, following the instruction at [Create Windows Service using BackgroundService](https://learn.microsoft.com/en-us/dotnet/core/extensions/windows-service#delete-the-windows-service):
  - Create a daily log in the folder specified in the 'appsettings.json' file
    - On startup, the service should check for this folder and create if needed
  - Make sure you can publish, install, start, stop, and delete the Windows Service as described in this web page on your local machine
  - Then, be able to do the same on the AutoTesting02 VM (autotesting02.eastus.cloudapp.azure.com)
- Replace the functionality of this shell service with the following features:
  - Add the parameter "RunFrequencyInMinutes" to the 'appsettings.json' file.
  If this value is not numeric, default to 15 minutes
  - On startup, read and parse a JSON file (a full path specified as "CommandFileToRun" in the 'appsettings.json' file) containing a list of command to run when the timer fires, in the following format:
    - Command Description (a short string describing the command being ran)
    - File To Execute
    - Working Directory
    - Argument List (an array of strings)
  - Come up with a list of applications to run and use them populate the above JSON file.
  They should either be "shell" commands or Windows executable utilities that would work in a standard Windows environment.
  Examples:
    - "Check Valid Disk" :  'chkdsk d:'
    - "Check Invalid Disk" :  'chkdsk r:' (which should throw an error and provide an opportunity to test our error handling and reporting later)
    - "Gather File Attributes" : 'attrib C:\temp\*.* /s'
    - "Copy JSON Files" : 'copy *.json C:\temp'
  - Note:  In this milestone do not yet write code to execute these commands

- Add comprehensive logging, as we did for the RBQM Console App
  - Log the Service start, stop and pause command
  - Log the reading of the 'appsettings.json' parameters, including if a default value was used
  - Log success or failure of reading the 'CommandFileToRun', and all potential I/O errors (file not found, invalid permissions, invalid format. etc)
  - Log timer firing and worker finished (which at this point still prints out a joke)

- Add the ability to actually execute the commands contained in the JSON file:
  - Use the [Process.Start Method](https://learn.microsoft.com/en-us/dotnet/api/system.diagnostics.process.start?view=net-8.0) and 
[ProcessStartInfo Class](https://learn.microsoft.com/en-us/dotnet/api/system.diagnostics.processstartinfo?view=net-8.0) to execute the commands
  - Set the [ProcessStartInfo.CreateNoWindow](https://learn.microsoft.com/en-us/dotnet/api/system.diagnostics.processstartinfo.createnowindow?view=net-8.0#system-diagnostics-processstartinfo-createnowindow) 
property to 'FALSE'
  - Launch each process on a separate Thread, so that the API does not need to wait until a long-running process is finished.  API "Success" simply 
indicates that the process was launched successfully.
  - Log the 'stdout' and 'stderr' streams for each command into a file in the SAS Agent Log folder, using the pattern '{Command Name from JSON}_{YYYY-MMM-DD-hh-mm-ss}.txt'
  - NOTE:  You will probably needs to ensure that the SAS Agent Windows Service is installed with the correct credentials / permissions to run commands 
from the 'C:\Windows' system folder

The Agent should be able to execute the JSON file commands on startup, and also when the timer fires, with both options configurable from the appsettings.json file.


### End Goal - "EDC SAS Agent" API

The final step  is to implement an HTTP API Endpoint in the SAS Agent that can receive individual commands from the Swagger UI and execute those commands, 
using the "minimal API" framework and approach that the HCL team is currently implementing as part of SpecTrain.  Realize that when the EDC SAS Agent is in 
Production, the Agent will only be executing commands from the API, and not running commands from the "CommandFileToRun" at startup or on a timer.  We 
will leave the "commandFileToRun" features in the Agent, as a means to be able to troubleshoot any issues that may occur in Production.

When this POC is complete, we will have:
- A working EDC SAS Agent Service
- That exposed an API that can execute a variety of commands and programs on the server
- With elevated permissions
- With a high level of logging, at the both the Agent and individual Process levels
- With a high level of error handling, so that unexpected errors do not cause the service does not abort 

