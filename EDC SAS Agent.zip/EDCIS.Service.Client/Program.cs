using Microsoft.Extensions.Hosting.WindowsServices;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Builder;
using Serilog;
using System.Security.Cryptography.X509Certificates;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Serilog.Events;
using Microsoft.Extensions.Configuration;
using EDCIS.Service.Client.Email;

namespace EDCIS.Service.Client
{
	public class Program
	{
		public static string LogFolder = @"C:\temp";

		public static void Main(string[] args)
		{
            var builder = WebApplication.CreateBuilder();

			LogFolder = builder.Configuration.GetValue<string>("LogFolder") ?? LogFolder;
			if (!Directory.Exists(LogFolder)) Directory.CreateDirectory(LogFolder);

			string serilogPath = Path.Combine(LogFolder, "EDC SAS Agent_.txt");
            string logLevel = builder.Configuration.GetValue<string>("SerilogLogLevel") ?? "Debuf";

            int daysToRetain = 30;
            string days = builder.Configuration.GetValue<string>("DaysToRetainLogs") ?? "30";
            if (!int.TryParse(days, out daysToRetain)) daysToRetain = 30;

            var logger = new LoggerConfiguration()
				.WriteTo.Console(outputTemplate: "[{Timestamp:HH:mm:ss} {Level:u3}] {Message:lj}{NewLine}{Exception}", restrictedToMinimumLevel: GetLogLevel(logLevel))
				.WriteTo.File(path: serilogPath, rollingInterval: RollingInterval.Day, restrictedToMinimumLevel: GetLogLevel(logLevel),
					outputTemplate: "[{Timestamp:HH:mm:ss} {Level:u3}] {Message:lj}{NewLine}{Exception}", retainedFileTimeLimit: new TimeSpan(daysToRetain, 0, 0, 0))
				.MinimumLevel.Verbose()
                // see https://github.com/serilog/serilog-aspnetcore?tab=readme-ov-file#request-logging
                .MinimumLevel.Override("Microsoft.AspNetCore.Hosting", GetLogLevel(logLevel))
                .MinimumLevel.Override("Microsoft.AspNetCore.Mvc", GetLogLevel(logLevel))
				.MinimumLevel.Override("Microsoft.AspNetCore.Routing", GetLogLevel(logLevel))
                .CreateLogger();


            logger.Information($"SeriLog logger Created, file path = '{serilogPath}'");
            logger.Information($"Log Level = '{logLevel}'");

            try
            {
                builder.Logging.ClearProviders();
                builder.Services.AddSerilog(logger);

                builder.Host.UseWindowsService();
                logger.Information($"Running as Service? '{WindowsServiceHelpers.IsWindowsService()}'");
                logger.Information($"AppContext.BaseDirectory = '{AppContext.BaseDirectory}'");
                logger.Information($"ContentRootPath = '{builder.Environment.ContentRootPath}'");
                logger.Information($"WebRootPath = '{builder.Environment.WebRootPath}'");

                builder.Host.ConfigureServices((hostContext, services) =>
				{
                    builder.Services.AddApplicationServices(builder.Configuration);

                    services.AddControllers().AddNewtonsoftJson();

					services.AddEndpointsApiExplorer();
					services.AddSwaggerGen(C=>C.AddSwaggerApiKeySecurity());

					services.AddSingleton<AgentService>();
					services.AddHostedService<WindowsBackgroundService>();
                    var emailConfig = builder.Configuration
                .GetSection("EmailConfiguration")
                .Get<EmailConfiguration>();
                    services.AddSingleton(emailConfig!);
                });

                var kestrelSection = builder.Configuration.GetSection("Kestrel");
                bool kestrelConfigExists = kestrelSection.Exists();
                string portString = builder.Configuration.GetValue<string>("HttpsPort") ?? string.Empty;
                int httpsPort = 0;
                if (kestrelSection.Exists())
                {
                    logger.Information($"Kestrel section found in appsettings, uaing as API port configuration");
                }
                else if (int.TryParse(portString, out httpsPort))
                {
                    logger.Information($"Valid HTTPS Port Found in appsettings: '{httpsPort}'");
                    builder.WebHost.ConfigureKestrel((context, serverOptions) =>
                    {
                        string enableHttp = builder.Configuration.GetValue<string>("EnableHttp") ?? "N";
                        if ((!string.IsNullOrEmpty(enableHttp)) && (enableHttp.Substring(0, 1).ToUpper() == "Y"))
                        {
                            logger.Information($"Will configure Kesterl for HTTP:{httpsPort - 1}");
                            serverOptions.ListenAnyIP(httpsPort - 1);
                        }
                        else
                        {
                            logger.Information($"HTTP Port will not be enabled");
                        }
                        X509Certificate2? httpsCert = GetKeyVaultCertificate(builder);
                        if (httpsCert != null)
                        {
                            logger.Information($"Certificate found in Azure Key Vault, will configure Kesterl for HTTPS:{httpsPort}");
                            serverOptions.ListenAnyIP(httpsPort, listenOptions =>
                            {
                                listenOptions.UseHttps(httpsCert);
                            });
                        }
                    });
                }
                else
                {
                    logger.Information($"Configuration value '{portString}' for 'HttpsPort' is not parseable; using Kestrel defaults");
                }

                var app = builder.Build();
                app.UseApiKey();
                app.UseSerilogRequestLogging();  // TODO:  remove me ???
                logger.Information($"ContentRootPath = '{app.Environment.ContentRootPath}'");
                logger.Information($"WebRootPath = '{app.Environment.WebRootPath}'");

                app.MapControllers(); // logs the "Registered model binderproviders" message
				if (!app.Environment.IsProduction())
				{
					app.UseDeveloperExceptionPage();
                    app.UseSwagger();
                    //app.UseSwaggerUI();
                    app.UseSwaggerUI(c =>
                    {
                        c.SwaggerEndpoint("/swagger/v1/swagger.json", "EDCIS API V1");
                    });
                }
                app.UseAuthorization();
                app.UseMiddleware<ApplicationExceptionMiddleware>();

                try
                {
					app.Run();
				}
				catch (Exception ex)
				{
                    logger.Fatal("Exception executing app.Run(): " + ex.ToString());
                    throw;  // Note:  do not use ex, see https://learn.microsoft.com/en-us/dotnet/fundamentals/code-analysis/quality-rules/ca2200
                }
			}
			catch (Exception ex)
			{
				logger.Fatal("Exception in Program.cs: " + ex.ToString());
                throw;
            }
        }

		private static LogEventLevel GetLogLevel(string level)
		{
			if (level.ToUpper() == "VERBOSE") return LogEventLevel.Verbose;
            if (level.ToUpper() == "DEBUG") return LogEventLevel.Debug;
            if (level.ToUpper() == "INFORMATION") return LogEventLevel.Information;
            if (level.ToUpper() == "WARNING") return LogEventLevel.Warning;
            if (level.ToUpper() == "ERROR") return LogEventLevel.Error;
            return LogEventLevel.Information;
		}

		private static X509Certificate2 GetKeyVaultCertificate(WebApplicationBuilder builder)
        {
            string azureKeyVaultUri = builder.Configuration.GetValue<string>("AzureKeyVaultUri") ?? string.Empty;
            string azureKeyVaultCertName = builder.Configuration.GetValue<string>("AzureKeyVaultCertName") ?? string.Empty;

            DefaultAzureCredentialOptions credOptions = new DefaultAzureCredentialOptions()
            {
                ExcludeEnvironmentCredential = false,
                ExcludeManagedIdentityCredential = System.Diagnostics.Debugger.IsAttached, // exclude if debugging locally
                ExcludeSharedTokenCacheCredential = true,
                ExcludeVisualStudioCredential = !System.Diagnostics.Debugger.IsAttached, // do NOT exclude if debugging locally
                ExcludeVisualStudioCodeCredential = true,
                ExcludeAzureCliCredential = true,
                ExcludeAzurePowerShellCredential = true,
                ExcludeInteractiveBrowserCredential = true,
                ExcludeAzureDeveloperCliCredential = true,
                ExcludeWorkloadIdentityCredential = true
            };
            var defaultCreds = new DefaultAzureCredential(credOptions);
    
	        var uri = new System.Uri(azureKeyVaultUri);
			var client = new SecretClient(uri, defaultCreds);
            KeyVaultSecret secret = client.GetSecret(azureKeyVaultCertName);
			var flags = X509KeyStorageFlags.MachineKeySet;
            var cert = new X509Certificate2(Convert.FromBase64String(secret.Value), string.Empty, flags);
            return cert;
        }

    }
}