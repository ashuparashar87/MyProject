﻿using Newtonsoft.Json;

namespace EDCIS.Service.Client
{

	public class AgentService
	{
		private readonly IConfiguration _config;
		private readonly ILogger<AgentService> _logger;
		public readonly string CommandFileToRun;
        public readonly int RunFrequencyInMinutes;
		public readonly bool RunCommandFileOnStart = false;
		public readonly bool EnableHostedTimer = false;

		public AgentService(IConfiguration config, ILogger<AgentService> logger)
		{
			_logger = logger;
			_config = config;
			int RunFrequencyInMinutes = 30;
			string freq = _config.GetValue<string>("RunFrequencyInMinutes") ?? "30";
			if (!int.TryParse(freq, out RunFrequencyInMinutes)) RunFrequencyInMinutes = 30;
            CommandFileToRun = _config["CommandFileToRun"] ?? string.Empty;
            _logger.LogInformation($"CommandFileToRun File Path: '{CommandFileToRun}'");
            bool.TryParse(_config["RunCommandFileOnStart"], out RunCommandFileOnStart);
			bool.TryParse(_config["EnableHostedTimer"], out EnableHostedTimer);
		}

        private void LogError(Exception ex, string message)
        {
            _logger.LogError(ex, message);
            if (ex.InnerException != null) _logger.LogError(ex.InnerException, "Inner Exception");
        }

        public void ProcessFileFromApi()
		{
            _logger.LogInformation("CreateNewAndRunAgentService API called, will try to execute CommandFileToRun");
            ProcessFile();
		}

        public void ProcessFile()
		{
			try
			{
				if (!File.Exists(CommandFileToRun))
				{
                    _logger.LogError($"CommandFileToRun '{CommandFileToRun}' Does Not Exist, cannot process commands");
                    return;
				}
				_logger.LogInformation($"Reading CommandFileToRun '{CommandFileToRun}'");
				string json = File.ReadAllText(CommandFileToRun);
				_logger.LogInformation("Deserializing JSON from CommandToRun");
                List<AgentCommand> commands = JsonConvert.DeserializeObject<List<AgentCommand>>(json) ?? new List<AgentCommand>();
                if ((commands == null) || (commands.Count == 0))
                {
                    _logger.LogInformation("JSON is null or contains no items, nothing to execute");
                    return;
                }
                _logger.LogInformation($"Starting Processing of {commands.Count} JSON commands");
                ProcessCommands(commands);
                _logger.LogInformation($"Finished Processing of {commands.Count} JSON commands");
            }
            catch (Exception ex)
			{
				LogError(ex, "Exception thrown in AgentService.ProcessFile()");
            }
		}

		public void ProcessCommands(List<AgentCommand> commands)
		{
			int i = 0;
            int cmdNumber;
			foreach (AgentCommand cmd in commands)
			{
				try
				{
                    cmdNumber = i + 1;
                    _logger.LogInformation($"Validating Command #{cmdNumber}, '{cmd.Description}'");
                    (bool isValid, string ErrorMsg) = ValidateCommand(cmd);
					if (isValid)
					{
                        _logger.LogInformation($"Command #{cmdNumber}, '{cmd.Description}', is Valid, will execute");
                        ApiResponse results = LaunchCommand(cmd);
                    }
                    else
                    {
                        _logger.LogError($"Validation failed, cannot execute Command #{cmdNumber}, '{cmd.Description}', Error={ErrorMsg}");
                    }
                    i++;
                }
                catch (Exception ex)
                {
                    LogError(ex, "Exception thrown in AgentService.ProcessCommands()");
                }
            }
        }

        public (bool isValid, string ErrorMsg) ValidateCommand(AgentCommand command)
		{
			if (string.IsNullOrWhiteSpace(command.Description))
			{
				return (false, "Parameter 'Description ' is missing");
			}
			if (string.IsNullOrWhiteSpace(command.File))
			{
				return (false, "Parameter 'File ' is missing");
			}
			if ((string.IsNullOrEmpty(command.Path) == false) && Directory.Exists(command.Path) == false) {
				return (false, $"Parameter 'Path' is invalid, path '{command.Path}' not found");
			}
            return (true, string.Empty);
		}

		public ApiResponse ExecuteCommandFromApi(AgentCommand command) {
            _logger.LogInformation("Executing Command from API");
            return LaunchCommand(command);
		}


        private ApiResponse LaunchCommand(AgentCommand commandToExecute)
		{
			string processLogFileName = "Undetermined";
            try
			{
				if (commandToExecute.Timeout == 0)
				{
					commandToExecute.Timeout = 60000; //60 secs if 0
				}
				else if (commandToExecute.Timeout < -1)
				{
					commandToExecute.Timeout = -1;
				}
				else
				{
					commandToExecute.Timeout = commandToExecute.Timeout * 1000;
                }
                if (commandToExecute.File == "cmd.exe")
                {
                    _logger.LogInformation("Command to execute = cmd.exe, Adding /C parameter");
                    commandToExecute.Args?.Insert(0, "/C"); //  '/C'  carries out the command specified by string and then terminates
                }

				string descr = string.Concat(commandToExecute.Description.Split(Path.GetInvalidFileNameChars()));
				descr = descr.Substring(0, Math.Min(descr.Length, 20));
				processLogFileName = $"{descr}_{DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss")}.txt";
                processLogFileName = Path.Combine(Program.LogFolder, processLogFileName);

                _logger.LogInformation($"Launching New Process to Execute Command '{commandToExecute.Description}'");
                RunAsProcess runner = new RunAsProcess(processLogFileName, _logger);
                Thread myThread = new Thread(new ParameterizedThreadStart(runner.LogAndExecute));
                myThread.Start(commandToExecute);
                _logger.LogInformation($"New Process Launched for '{commandToExecute.Description}'");

				return new ApiResponse { Message = $"Process '{commandToExecute.Description}' Launched Successfully", 
					LaunchSuccess = true, LogFile = processLogFileName };

            }
            catch (Exception ex)
			{
				LogError(ex, "Exception thrown in AgentService.ExecuteCommand()"); //only the app logs lengthy exception string
				return new ApiResponse { Message = "Exception Occured in AgentService.ExecuteCommand()", LaunchSuccess = false,
                    LogFile = processLogFileName, ExceptionMsg = ex.ToString(), ResultCode = -101 };
			}
		}

    }
}