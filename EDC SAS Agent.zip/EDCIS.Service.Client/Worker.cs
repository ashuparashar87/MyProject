using System.Security.Principal;

namespace EDCIS.Service.Client
{
	public sealed class WindowsBackgroundService : BackgroundService
	{
		private readonly ILogger<WindowsBackgroundService> _logger;
		private readonly AgentService _appService;


        public WindowsBackgroundService(AgentService appService, ILogger<WindowsBackgroundService> logger)
		{
            _logger = logger;
			_appService = appService;
        }

        private void LogError(Exception ex, string message)
        {
            _logger.LogError(ex, message);
            if (ex.InnerException != null) _logger.LogError(ex.InnerException, "Inner Exception");
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
		{
            if (_appService.RunCommandFileOnStart)
            {
                _logger.LogInformation($"RunCommandFileOnStart=true, Processing CommandFileToRun on startup");
                ProcessCommandFile();
            }
            else
            {
                _logger.LogInformation($"RunCommandFileOnStart=FALSE, ignoring CommandFileToRun on startup");
            }

            if (_appService.EnableHostedTimer == false)
            {
                _logger.LogInformation($"Timed service will not be used; EnableHostedTimer is false");
                return;
            }
            if (_appService.RunFrequencyInMinutes == 0)
            {
                _logger.LogInformation($"Timed service will not be used; RunFrequencyInMinutes=0");
                return;
            }
            if (string.IsNullOrEmpty(_appService.CommandFileToRun))
            {
                _logger.LogInformation($"Timed service will not be used; CommandFileToRun is blank");
                return;
            }

            // hosted timer
            _logger.LogInformation($"Timed service will execute every {_appService.RunFrequencyInMinutes} minutes");
            stoppingToken.Register(() => _logger.LogInformation("Service application is stopping"));
            try
            {
                while (!stoppingToken.IsCancellationRequested)
                {
                    _logger.LogInformation($"Going to sleep for {_appService.RunFrequencyInMinutes} minutes");
                    await Task.Delay(TimeSpan.FromMinutes(_appService.RunFrequencyInMinutes), stoppingToken);
                    _logger.LogInformation("Timer fired, will try to execute CommandFileToRun");
                    ProcessCommandFile();
                }
            }
            catch (OperationCanceledException) // this is expected if user Stops the service or presses Ctrl-C from console
            {
                if (stoppingToken.IsCancellationRequested)
                    _logger.LogInformation("Service Application shutting down gracefully due to user cancellation request");
            }
            catch (Exception ex)
            {
                LogError(ex, "Exception thrown in Worker.ExecuteAsync(), Service Application is aborting");
            }
        }
        private void ProcessCommandFile()
        {
            try
            {
                WindowsIdentity user = WindowsIdentity.GetCurrent();
                WindowsPrincipal principal = new WindowsPrincipal(user);
                bool isAdmin = principal.IsInRole(WindowsBuiltInRole.Administrator);
                _logger.LogInformation($"Windows User: '{user.Name}'; Is Admin? {isAdmin.ToString().ToUpper()}");
                if (isAdmin == false)
                {
                    _logger.LogWarning("This application requires elevated credentials in order to operate correctly, but will continue without Admin permissions");
                }
                _appService.ProcessFile();
                _logger.LogInformation("CommandToRun has been processed");
            }
            catch (Exception ex)
            {
                LogError(ex, "Exception thrown in Worker.ProcessCommandFile()");

                // TODO:  Do I need this ????
                //// Terminates this process and returns an exit code to the operating system.
                //// This is required to avoid the 'BackgroundServiceExceptionBehavior', which
                //// performs one of two scenarios:
                //// 1. When set to "Ignore": will do nothing at all, errors cause zombie services.
                //// 2. When set to "StopHost": will cleanly stop the host, and log errors.
                ////
                //// In order for the Windows Service Management system to leverage configured
                //// recovery options, we need to terminate the process with a non-zero exit code.
                //Environment.Exit(1);
            }
        }

    }
}