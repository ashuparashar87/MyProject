﻿
namespace EDCIS.Service.Client
{
    public class AgentCommand
    {
        public string Description = string.Empty;
        public string File = string.Empty;
        public string Path = string.Empty;
        public int Timeout = 60000;
        public List<string>? Args = null;
    }

    public class ApiResponse
    {
        public bool LaunchSuccess = false;
        public int ResultCode = 0;
        public string Message = string.Empty;
        public string ExceptionMsg = string.Empty;
        public string LogFile = string.Empty;
    }

    public class ProcessResults
    {
        public bool IsSuccess = false;
        public int ExitCode = 0;
        public bool TimeoutOccurred = false;
        public string Message = string.Empty;
        public string StdOutput = string.Empty;
        public string StdError = string.Empty;
        public string ExceptionMsg = string.Empty;
    }

}

