﻿using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Microsoft.Extensions.Caching.Memory;
using System.Security.Cryptography.X509Certificates;

namespace EDCIS.Service.Client
{
    public static class AzureKeyVault
    {
        private static readonly MemoryCache _cache = new MemoryCache(new MemoryCacheOptions());

        public static X509Certificate2 GetKeyVaultCertificate()
        {
            var cachedKey = 300;
            if (_cache.TryGetValue(cachedKey, out X509Certificate2? cachedCertificate))
            {
                return cachedCertificate!;
            }
            else
            {
                DefaultAzureCredentialOptions credOptions = new DefaultAzureCredentialOptions()
                {
                    ExcludeEnvironmentCredential = false,
                    ExcludeManagedIdentityCredential = System.Diagnostics.Debugger.IsAttached, // exclude if debugging locally
                    ExcludeSharedTokenCacheCredential = true,
                    ExcludeVisualStudioCredential = !System.Diagnostics.Debugger.IsAttached, // do NOT exclude if debugging locally
                    ExcludeVisualStudioCodeCredential = true,
                    ExcludeAzureCliCredential = true,
                    ExcludeAzurePowerShellCredential = true,
                    ExcludeInteractiveBrowserCredential = true,
                    ExcludeAzureDeveloperCliCredential = true,
                    ExcludeWorkloadIdentityCredential = true
                };
                var defaultCreds = new DefaultAzureCredential(credOptions);

                var uri = new System.Uri(ConfigManager.AzureKeyVaultUri);
                var client = new SecretClient(uri, defaultCreds);
                KeyVaultSecret secret = client.GetSecret(ConfigManager.AzureKeyVaultCertName);
                var flags = X509KeyStorageFlags.MachineKeySet;
                var cert = new X509Certificate2(Convert.FromBase64String(secret.Value), string.Empty, flags);
                _cache.Set(cachedKey, cert, TimeSpan.FromMinutes(300));
                return cert;
            }
        }
    }
}
