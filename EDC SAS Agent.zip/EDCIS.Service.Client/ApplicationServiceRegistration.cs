﻿using EDCIS.Service.Client.Email;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDCIS.Service.Client
{
    public static class ApplicationServiceRegistration
    {
        public static IServiceCollection AddApplicationServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IEmailSender, EmailSender>();
            SetEmailParam(configuration);
            SetSharePointParam(configuration);
            SetAzureKeyVaultParam(configuration);
            SetCriticalErrorEmailParam(configuration);
            return services;
        }

        private static void SetEmailParam(IConfiguration configuration)
        {
            ConfigManager.EmailFrom = configuration["EmailConfiguration:From"]!;
            ConfigManager.EmailPort = configuration["EmailConfiguration:Port"]!;
            ConfigManager.EmailSmtpServer = configuration["EmailConfiguration:SmtpServer"]!;
            ConfigManager.EmailUsername = configuration["EmailConfiguration:Username"]!;
            ConfigManager.OfficeURL = configuration["EmailConfiguration:OfficeURL"]!;

        }
        private static void SetSharePointParam(IConfiguration configuration)
        {
            ConfigManager.SharePointClientId = configuration["SharePointConfig:SharePointClientId"]!;
            ConfigManager.SharePointTenantId = configuration["SharePointConfig:SharePointTenantId"]!;

        }
        private static void SetAzureKeyVaultParam(IConfiguration configuration)
        {
            ConfigManager.AzureKeyVaultUri = configuration["AzureKeyVault:AzureKeyVaultUri"]!;
            ConfigManager.AzureKeyVaultCertName = configuration["AzureKeyVault:AzureKeyVaultCertName"]!;
        }
        private static void SetCriticalErrorEmailParam(IConfiguration configuration)
        {
            ConfigManager.CriticalErrorEmail_ToEmail = configuration["CriticalErrorEmailConfiguration:ToEmail"];
            ConfigManager.CriticalErrorEmail_Subject = configuration["CriticalErrorEmailConfiguration:Subject"];
            ConfigManager.CriticalErrorEmail_BodyTemplate = configuration["CriticalErrorEmailConfiguration:BodyTemplate"];
        }
    }
}
