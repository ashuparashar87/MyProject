﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDCIS.Service.Client
{
    public static class ConfigManager
    {
        //Email configuration Params
        public static string EmailFrom { get; set; } = null!;
        public static string EmailSmtpServer { get; set; } = null!;
        public static string EmailPort { get; set; } = null!;
        public static string EmailUsername { get; set; } = null!;
        public static string OfficeURL { get; set; } = null!;

        //Share Point configuration Params
        public static string SharePointClientId { get; set; } = null!;
        public static string SharePointTenantId { get; set; } = null!;

        //Azure KeyVault configuration Params
        public static string AzureKeyVaultUri { get; set; } = null!;
        public static string AzureKeyVaultCertName { get; set; } = null!;

        public static string? CriticalErrorEmail_ToEmail { get; set; }
        public static string? CriticalErrorEmail_Subject { get; set; }
        public static string? CriticalErrorEmail_BodyTemplate { get; set; }

    }
}