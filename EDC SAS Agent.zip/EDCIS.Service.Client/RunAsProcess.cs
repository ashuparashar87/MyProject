﻿using System.Diagnostics;
using System.Text;
using Serilog;
using Serilog.Core;

namespace EDCIS.Service.Client
{
    internal class RunAsProcess : IDisposable
    {
        private readonly Logger _seriLogger;
        private readonly ILogger<AgentService> _mainLogger;
        private bool disposedValue;

        public RunAsProcess(string processLogFileName, ILogger<AgentService> logger)
        {
            _mainLogger = logger;
            _seriLogger = new LoggerConfiguration()
                .MinimumLevel.Debug()
                .WriteTo.File(processLogFileName, outputTemplate: "[{Timestamp:HH:mm:ss} {Level:u3}] {Message:lj}{NewLine}{Exception}")
                .CreateLogger();
        }

        private void LogInfo(string msg)
        {
            _mainLogger.LogInformation(msg);
            _seriLogger.Information(msg);
        }

        private void LogError(string msg)
        {
            _mainLogger.LogError(msg);
            _seriLogger.Error(msg);
        }

        private void LogError(Exception ex, string msg)
        {
            _mainLogger.LogError(ex, msg);
            _seriLogger.Error(ex, msg);
            if (ex.InnerException != null)
            {
                _mainLogger.LogError(ex.InnerException, "Inner Exception");
                _seriLogger.Error(ex.InnerException, "Inner Exception");
            }
        }

        private ProcessStartInfo SetupStartInfo(AgentCommand command)
        {
            ProcessStartInfo info = new ProcessStartInfo();
            if (!string.IsNullOrWhiteSpace(command.Path))
            {
                info.WorkingDirectory = command.Path;
            }
            info.FileName = command.File;
            info.CreateNoWindow = true;
            info.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            info.RedirectStandardError = true;
            info.RedirectStandardOutput = true;
            info.RedirectStandardInput = false;
            info.LoadUserProfile = true;
            info.UseShellExecute = false; // need to capture stdout and stderr, see https://stackoverflow.com/a/5255335/11057678
            info.Verb = "RunAs"; // use elevated permissions
            if (command.Args != null)
            {
                foreach (string arg in command.Args)
                {
                    info.ArgumentList.Add(arg);
                }
            }
            return info;
        }

        public void LogAndExecute(object? value)
        {
            if (value == null)
            {
                throw new Exception("Command object is NULL in RunAsProcess.LogAndExecute()");
            }
            AgentCommand cmd = (AgentCommand)value;
            LogProcessStart(cmd);
            ProcessResults results = LaunchProcess(cmd);
            LogProcessResults(cmd, results);
        }

        /*  See https://stackoverflow.com/a/7608823/11057678 for the solution below; I could not get the TPL approach below it to work  */
        private ProcessResults LaunchProcess(AgentCommand command)
        {
            ProcessResults processResult = new ProcessResults();
            StringBuilder output = new StringBuilder();
            StringBuilder error = new StringBuilder();
            try
            {
                using (Process myProcess = new Process() { EnableRaisingEvents = true })
                {
                    myProcess.StartInfo = SetupStartInfo(command);

                    using (AutoResetEvent outputWaitHandle = new AutoResetEvent(false))
                    using (AutoResetEvent errorWaitHandle = new AutoResetEvent(false))
                    {
                        myProcess.OutputDataReceived += (sender, e) =>{
                            if (e.Data == null) {
                                outputWaitHandle.Set();
                            }
                            else {
                                output.AppendLine(e.Data);
                            }
                        };
                        myProcess.ErrorDataReceived += (sender, e) => {
                            if (e.Data == null) {
                                errorWaitHandle.Set();
                            }
                            else {
                                error.AppendLine(e.Data);
                            }
                        };

                        LogInfo($"********  Process '{command.Description}' starting Now!");
                        myProcess.Start();

                        myProcess.BeginOutputReadLine();
                        myProcess.BeginErrorReadLine();

                        if ((myProcess.WaitForExit(command.Timeout) && outputWaitHandle.WaitOne(command.Timeout) && errorWaitHandle.WaitOne(command.Timeout)))
                        {
                            processResult.StdOutput = output.ToString();
                            processResult.StdError = error.ToString();
                            processResult.ExitCode = myProcess.ExitCode;
                            processResult.IsSuccess = ((processResult.ExitCode == 0) && string.IsNullOrWhiteSpace(processResult.StdError));

                            myProcess.CloseMainWindow();  // Just in case
                            myProcess.Close();  // Free resources associated with process

                            return processResult;
                        }
                        else
                        {
                            myProcess.Kill(true);
                            return new ProcessResults
                            {
                                Message = $"Application failed to return a response before {command.Timeout} MS timeout, process Killed",
                                IsSuccess = false,
                                TimeoutOccurred = true,
                                ExitCode = -103
                            };
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string msg = "Exception Thrown in RunAsProcess.ExecuteCommand()";
                LogError(ex, Environment.NewLine + msg);
                return new ProcessResults { Message = msg, ExceptionMsg = ex.Message, IsSuccess = false, ExitCode = -104 };
            }
        }

        private void LogProcessStart(AgentCommand cmd)
        {
            LogInfo("********");
            LogInfo($"********  Starting new system process: {cmd.Description}");
            LogInfo("********");
            LogInfo($"Command to Execute: {cmd.File}");
            LogInfo($"    Current Folder: {Directory.GetCurrentDirectory()}");
            LogInfo($"    Working Folder: {cmd.Path}");
            LogInfo($"           Timeout: {cmd.Timeout} MS");
            string parms = (cmd.Args == null) ? "<none>" : string.Join(", ", cmd.Args);
            LogInfo($"        Parameters: {parms}");
        }


        private void LogProcessResults(AgentCommand cmd, ProcessResults results)
        {
            LogInfo("********");
            LogInfo($"********  Process '{cmd.Description}' completed, IsSuccess={results.IsSuccess}");
            if (!results.IsSuccess)
            {
                LogError($"    **** ERRORS for Command '{cmd.Description}'");
                LogError($"    **** Process Exit Code: {results.ExitCode}");
                if (string.IsNullOrWhiteSpace(results.Message) == false)
                {
                    LogError($"    **** Message from Agent: {results.Message}");
                }
                if (string.IsNullOrWhiteSpace(results.ExceptionMsg) == false)
                {
                    LogError($"    **** Exception Thrown: {results.ExceptionMsg}");
                }
                if ((results.TimeoutOccurred))
                {
                    LogError($"    **** Process Timed Out, Configured timeout = {cmd.Timeout}");
                }
                if (string.IsNullOrWhiteSpace(results.StdError) == false)
                {
                    LogError($"    **** stdError= {results.StdError}");
                }
                else
                {
                    LogError($"    **** stdError stream was empty");
                }
            }
            LogInfo("********");
            LogInfo($"******** Command stdout for '{cmd.Description}'");
            if (string.IsNullOrEmpty(results.StdOutput))
            {
                LogInfo("<.. stdout was empty ..>");

            }
            else
            {
                LogInfo($"{results.StdOutput}");
            }
            LogInfo("********");
            LogInfo($"******** END Command '{cmd.Description}' StdOutput and Logs");
            LogInfo("********");
        }

#region Dispose

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    _seriLogger.Dispose();
                }
                disposedValue = true;
            }
        }

        // // TODO: override finalizer only if 'Dispose(bool disposing)' has code to free unmanaged resources
        // ~RunAsProcess()
        // {
        //     // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
        //     Dispose(disposing: false);
        // }

        public void Dispose()
        {
            // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

#endregion Dispose

    }
}
