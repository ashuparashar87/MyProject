using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace EDCIS.Service.Client.API.Controllers
{
	[ApiController]
	[Microsoft.AspNetCore.Mvc.Route("[controller]/[action]")]
	public class AgentServiceController : ControllerBase
	{
		private readonly ILogger<AgentServiceController> _logger;
		private readonly AgentService _service;


		public AgentServiceController(ILogger<AgentServiceController> logger, AgentService service)
		{
			_logger = logger;
			_service = service;
		}
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [Microsoft.AspNetCore.Mvc.HttpGet(Name = "PingAgentService")]
		public IActionResult Get()
		{
			return new OkResult();
		}

		[ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status200OK)]

        [Microsoft.AspNetCore.Mvc.HttpPost(Name = "RunAgentService")]
		public IActionResult Run([Microsoft.AspNetCore.Mvc.FromBody] AgentCommand command)
		{
			(bool isValid, string errorMsg) = _service.ValidateCommand(command);
			if (isValid) {
				ApiResponse results = _service.ExecuteCommandFromApi(command);
				if (!results.LaunchSuccess) Response.StatusCode = (int)HttpStatusCode.InternalServerError;
				return new JsonResult(results);
			}
			else
			{
                Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return new JsonResult(new ApiResponse { LaunchSuccess = false, Message = errorMsg, ResultCode = -102 });
			}
		}

	}
}
