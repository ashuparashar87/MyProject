﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDCIS.Service.Client.Email
{
    public interface IEmailSender
    {
        Task SendEmailAsync(string _body, string _emailTo, string? _emailCC, string _subject, string? userEmail);
    }
}
