﻿using Microsoft.Identity.Client;
using MimeKit;
using System.Diagnostics;

namespace EDCIS.Service.Client.Email
{
    public class EmailSender : IEmailSender
    {

        private ILogger _logger;
        public EmailSender(ILogger<EmailSender> logger)
        {
            _logger = logger;
        }
        public async Task SendEmailAsync(string _body, string _emailTo, string? _emailCC, string _subject, string? _userEmail)
        {
            try
            {
                var mailMessage = CreateEmailMessage(_body, _emailTo, _emailCC, _subject, _userEmail);
                await SendAsync(mailMessage);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message + " : " + ex.InnerException);
            }
        }

        private MimeMessage CreateEmailMessage(string _body, string _emailTo, string? _emailCC, string _subject, string? _userEmail)
        {
            var emailMessage = new MimeMessage();
            if (_emailTo != null)
            {
                var ToAddressList = new List<MailboxAddress>();
                var emailTo = _emailTo.Split(new Char[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
                ToAddressList.AddRange(emailTo.Select(x => new MailboxAddress("email", x.Trim(' '))));
                emailMessage.To.AddRange(ToAddressList);
            }
            if (_emailCC != null)
            {
                var CcAddressList = new List<MailboxAddress>();
                var emailCc = _emailCC.Split(new Char[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
                CcAddressList.AddRange(emailCc.Select(x => new MailboxAddress("email", x.Trim(' '))));
                emailMessage.Cc.AddRange(CcAddressList);
            }
            if (!string.IsNullOrEmpty(_userEmail))
            {
                var replyTo = new List<MailboxAddress>()
                {
                    new MailboxAddress("email",_userEmail)
                };
                emailMessage.ReplyTo.AddRange(replyTo);
            }

            emailMessage.From.Add(new MailboxAddress("email", ConfigManager.EmailFrom));
            var env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

            if (Debugger.IsAttached)
            {
                emailMessage.Subject = env == "Production" ? _subject : "Local: " + _subject;
            }
            else
            {
                emailMessage.Subject = env == "Production" ? _subject : env?.ToUpper() + ": " + _subject;
            }
            emailMessage.Body = new TextPart(MimeKit.Text.TextFormat.Html) { Text = _body };
            return emailMessage;
        }


        private async Task SendAsync(MimeMessage mailMessage)
        {
            var scopes = new string[] { ConfigManager.OfficeURL };
            var confidentialClientApp = ConfidentialClientApplicationBuilder.Create(ConfigManager.SharePointClientId)
                .WithAuthority(AzureCloudInstance.AzurePublic, ConfigManager.SharePointTenantId)
                .WithCertificate(AzureKeyVault.GetKeyVaultCertificate())
                .Build();
            AuthenticationResult tokenResult = await confidentialClientApp
                .AcquireTokenForClient(scopes)
                .ExecuteAsync();
            var micToken = tokenResult.AccessToken;
            var oauth2 = new MailKit.Security.SaslMechanismOAuth2(ConfigManager.EmailUsername, micToken);
            using (var client = new MailKit.Net.Smtp.SmtpClient())
            {
                try
                {
                    await client.ConnectAsync(ConfigManager.EmailSmtpServer, Convert.ToInt32(ConfigManager.EmailPort), false);
                    await client.AuthenticateAsync(oauth2);
                    await client.SendAsync(mailMessage);

                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    await client.DisconnectAsync(true);
                    client.Dispose();
                }
            }
        }
    }
}
